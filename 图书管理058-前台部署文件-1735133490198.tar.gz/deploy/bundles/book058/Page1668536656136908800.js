var Page1668536656136908800 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1668536656136908800: () => Page1668536656136908800
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1668536656136908800 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1668536656136908800",
            pageName: "\u5E94\u7528\u7EA7\u4E2A\u4EBA\u4EFB\u52A1\u4E2D\u5FC3",
            apiMeta: {
              bis_api_1686908447992: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.remark": {
                    title: "\u5907\u6CE8\u63CF\u8FF0",
                    __key: "remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.output_file_param": {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "output_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.input_file_param": {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "input_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.progress": {
                    title: "\u8FDB\u5EA6",
                    __key: "progress",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.result": {
                    title: "\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.end_exec_time": {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6",
                    __key: "end_exec_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.exec_cost_time": {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F",
                    __key: "exec_cost_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.start_exec_time": {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4",
                    __key: "start_exec_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_des": {
                    title: "\u72B6\u6001\u63CF\u8FF0",
                    __key: "status_des",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u4EFB\u52A1\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_name": {
                    title: "\u4EFB\u52A1\u540D\u79F0",
                    __key: "task_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_type": {
                    title: "\u4EFB\u52A1\u7C7B\u578B",
                    __key: "task_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u53F7",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.less_code": {
                    title: "\u79DF\u6237\u53F7",
                    __key: "less_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  remark: {
                    title: "\u5907\u6CE8\u63CF\u8FF0"
                  },
                  output_file_param: {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  input_file_param: {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  progress: {
                    title: "\u8FDB\u5EA6"
                  },
                  result: {
                    title: "\u7ED3\u679C"
                  },
                  end_exec_time: {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6"
                  },
                  exec_cost_time: {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F"
                  },
                  start_exec_time: {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4"
                  },
                  status_des: {
                    title: "\u72B6\u6001\u63CF\u8FF0"
                  },
                  status: {
                    title: "\u4EFB\u52A1\u72B6\u6001"
                  },
                  task_name: {
                    title: "\u4EFB\u52A1\u540D\u79F0"
                  },
                  task_type: {
                    title: "\u4EFB\u52A1\u7C7B\u578B"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u53F7"
                  },
                  less_code: {
                    title: "\u79DF\u6237\u53F7"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_user: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  }
                }
              },
              bis_api_1687177151712: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.id": {
                    title: "id",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {
                  remark: {
                    title: "\u5907\u6CE8\u63CF\u8FF0"
                  },
                  output_file_param: {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  input_file_param: {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  progress: {
                    title: "\u8FDB\u5EA6"
                  },
                  result: {
                    title: "\u7ED3\u679C"
                  },
                  end_exec_time: {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6"
                  },
                  exec_cost_time: {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F"
                  },
                  start_exec_time: {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4"
                  },
                  status_des: {
                    title: "\u72B6\u6001\u63CF\u8FF0"
                  },
                  status: {
                    title: "\u4EFB\u52A1\u72B6\u6001"
                  },
                  task_name: {
                    title: "\u4EFB\u52A1\u540D\u79F0"
                  },
                  task_type: {
                    title: "\u4EFB\u52A1\u7C7B\u578B"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u53F7"
                  },
                  less_code: {
                    title: "\u79DF\u6237\u53F7"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_user: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  }
                }
              },
              FileDownload: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.": {
                    title: void 0,
                    __key: "",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.fileIdentifier": {
                    title: "fileIdentifier",
                    __key: "fileIdentifier",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.fileName": {
                    title: "fileName",
                    __key: "fileName",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.fileSize": {
                    title: "fileSize",
                    __key: "fileSize",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.fileType": {
                    title: "fileType",
                    __key: "fileType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.name": {
                    title: "name",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.parentPath": {
                    title: "parentPath",
                    __key: "parentPath",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.status": {
                    title: "status",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.storageStrategy": {
                    title: "storageStrategy",
                    __key: "storageStrategy",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.uid": {
                    title: "uid",
                    __key: "uid",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.url": {
                    title: "url",
                    __key: "url",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1687177166425: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.id": {
                    title: "id",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {
                  remark: {
                    title: "\u5907\u6CE8\u63CF\u8FF0"
                  },
                  output_file_param: {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  input_file_param: {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  progress: {
                    title: "\u8FDB\u5EA6"
                  },
                  result: {
                    title: "\u7ED3\u679C"
                  },
                  end_exec_time: {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6"
                  },
                  exec_cost_time: {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F"
                  },
                  start_exec_time: {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4"
                  },
                  status_des: {
                    title: "\u72B6\u6001\u63CF\u8FF0"
                  },
                  status: {
                    title: "\u4EFB\u52A1\u72B6\u6001"
                  },
                  task_name: {
                    title: "\u4EFB\u52A1\u540D\u79F0"
                  },
                  task_type: {
                    title: "\u4EFB\u52A1\u7C7B\u578B"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u53F7"
                  },
                  less_code: {
                    title: "\u79DF\u6237\u53F7"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_user: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  }
                }
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent", padding: "0px" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u5E94\u7528\u7EA7\u4E2A\u4EBA\u4EFB\u52A1\u4E2D\u5FC3",
              eventMode: { onPageLoad: "serial" }
            },
            ssQbHaxy: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "ssQbHaxy",
              title: "\u6805\u683C\u5E03\u5C40",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [[{ span: "24", locked: false, id: "pRcLBSxQ" }]],
              style: { width: "100%", height: "100%" },
              visible: true,
              widgetCode: "FlexLayoutContainer$5"
            },
            pRcLBSxQ: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "pRcLBSxQ",
              span: "24",
              title: "\u6805\u683C1",
              style: { height: "100%" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            zRBlLxjq: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "zRBlLxjq",
              title: "\u4FE1\u606F\u63D0\u793A\u5BB9\u5668",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [[{ span: "24", locked: false, id: "rGMTJqhR" }]],
              style: { width: "100%", height: "72px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$3"
            },
            rGMTJqhR: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "rGMTJqhR",
              span: "24",
              title: "\u6805\u683C1",
              style: {
                height: "60px",
                backgroundColor: "rgba(247,248,250,1)",
                padding: "16px",
                overflow: "unset",
                minHeight: "60px"
              },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            VmZaLFIQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              id: "VmZaLFIQ",
              labelList: [],
              style: { padding: "0px" },
              titleWeight: 400,
              vGutter: 0,
              titleAlign: "left",
              iconType: "",
              visible: true,
              showTitleEffective: true,
              labelColor: "rgba(126,140,168,1)",
              fontStyle: { color: "rgba(126,140,168,1)", fontSize: 16 },
              title: "\u5F02\u6B65\u4EFB\u52A1\u8BB0\u5F55\u4EC5\u4FDD\u75597\u5929\uFF0C\u8FC7\u671F\u5C06\u81EA\u52A8\u5220\u9664",
              widgetCode: "TextLabel$1",
              titleSize: 14
            },
            xIRMciba: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "xIRMciba",
              title: "\u4EFB\u52A1\u5217\u8868\u5BB9\u5668",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [[{ span: "24", locked: false, id: "RkMXHKXm" }]],
              style: {
                width: "100%",
                height: "100%",
                padding: "0px 16px 16px 16px"
              },
              visible: true,
              widgetCode: "FlexLayoutContainer$2"
            },
            RkMXHKXm: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "RkMXHKXm",
              span: "24",
              title: "\u6805\u683C1",
              style: { height: "100%", overflow: "unset" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            dYWwHZsO: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "dYWwHZsO",
              title: "\u6805\u683C\u5E03\u5C40",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [
                [
                  { span: "22", locked: false, id: "DGNYSLUN" },
                  { span: "2", locked: false, id: "sHvvwDPB" }
                ]
              ],
              style: { width: "100%", height: "auto", minHeight: "40px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$6"
            },
            DGNYSLUN: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "DGNYSLUN",
              span: "22",
              title: "\u6805\u683C1",
              style: { height: "auto", minHeight: "40px" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            DRPUGUXC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "DRPUGUXC",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727", fontWeight: 400 },
              title: "\u4EFB\u52A1\u540D\u79F0\u641C\u7D22\u6846",
              checkByExp: [],
              visible: true,
              showTitleEffective: false,
              required: false,
              style: { padding: "0px 0px 8px 0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$1",
              placeholder: "\u8BF7\u8F93\u5165\u4EFB\u52A1\u540D\u79F0",
              inputSuffix: "FiSearch",
              inputSuffixType: "icon"
            },
            sHvvwDPB: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "sHvvwDPB",
              span: "2",
              title: "\u6805\u683C2",
              style: {
                height: "auto",
                minHeight: "40px",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "flex-end",
                margin: "0px 0px 0px 0px"
              },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            YDrAfAei: {
              varMap: {},
              widgetRef: "Icons",
              eventAttr: ["onClick"],
              group: "actionControl",
              id: "YDrAfAei",
              style: {},
              iconSize: "16px",
              titleAlign: "left",
              iconsType: "FiRotateCw",
              visible: true,
              showTitleEffective: false,
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u5237\u65B0\u56FE\u6807",
              iconSpin: false,
              angle: 0,
              fontStyle: { color: "rgba(24,144,255,1)" },
              widgetCode: "Icons$4",
              iconsTooltip: "\u5237\u65B0",
              eventTypesWithTags: []
            },
            hSZNTvkO: {
              varMap: {
                total: { type: "number" },
                searchRange: { type: "object" },
                selectedRowKeys: { type: "array" },
                selectedRows: { type: "array" },
                currentRowKey: { type: "string" },
                currentRow: { type: "object" }
              },
              widgetRef: "Loop",
              eventAttr: ["onRowClick", "onRowSelect", "onRowUnSelect"],
              isContainer: true,
              group: "listDisplay",
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: [
                  "NormalTable",
                  "SubformContainer",
                  "NavPanel",
                  "EditableSheet",
                  "Carousel",
                  "MenuComp"
                ]
              },
              reloadEvents: ["onQuery"],
              id: "hSZNTvkO",
              title: "\u4EFB\u52A1\u5217\u8868",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              visible: true,
              showTitleEffective: false,
              hGutter: 16,
              vGutter: 0,
              rowSelection: { type: "no", checkedStyle: "activeRow" },
              pagination: { pageSize: 10, current: 1 },
              style: { height: "100%", padding: "8px 0px 16px 0px" },
              loopConfigRatio: {
                type: "width",
                width: "100%",
                countByWidth: 1,
                scale: { xs: 24, sm: 12, md: 8, lg: 6, xl: 4, xxl: 3 },
                countByScale: { xs: 1, sm: 2, md: 3, lg: 4, xl: 6, xxl: 8 }
              },
              performance: false,
              widgetCode: "Loop$1",
              columns: [{ widgetId: "eGDhpSfU", title: "\u6805\u683C\u5E03\u5C40" }],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              conditions: [
                {
                  varAlias: 1,
                  field: "task_name",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 2,
                  field: "less_code",
                  paramAmount: 1,
                  method: "equ"
                },
                { varAlias: 3, field: "app_code", paramAmount: 1, method: "equ" },
                {
                  varAlias: 4,
                  field: "create_user_id",
                  paramAmount: 1,
                  method: "equ"
                }
              ],
              formula: "1 and 2 and 3 and 4",
              ds: "bis_api_1686908447992",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "progress",
                "result",
                "end_exec_time",
                "exec_cost_time",
                "start_exec_time",
                "status_des",
                "status",
                "task_name",
                "last_update_time",
                "create_time",
                "create_user_name"
              ],
              loopBodyWidgetIdList: ["eGDhpSfU"],
              childMap: {
                eGDhpSfU: { id: "eGDhpSfU" },
                HlRTpEzq: { id: "HlRTpEzq" },
                zeSiEiNY: { id: "zeSiEiNY" },
                hcDrvHlT: { id: "hcDrvHlT" },
                SGGULtVc: { id: "SGGULtVc" },
                DfXGtDhP: { id: "DfXGtDhP" },
                mGWhTYJc: { id: "mGWhTYJc" },
                adDIyOFF: { id: "adDIyOFF" },
                yXNMnRYz: { id: "yXNMnRYz" },
                YaxeIcyn: { id: "YaxeIcyn" },
                yPCUpjhs: { id: "yPCUpjhs" },
                OytMmxkZ: { id: "OytMmxkZ" },
                BaOtJLcn: { id: "BaOtJLcn" },
                NTyPmobX: { id: "NTyPmobX" }
              },
              bodyFields: {
                zeSiEiNY: "task_name",
                hcDrvHlT: "create_time",
                SGGULtVc: "result",
                OytMmxkZ: "status"
              },
              bodyPaths: {
                undefined: [
                  "eGDhpSfU",
                  "HlRTpEzq",
                  "DfXGtDhP",
                  "mGWhTYJc",
                  "adDIyOFF",
                  "yXNMnRYz",
                  "YaxeIcyn",
                  "yPCUpjhs",
                  "BaOtJLcn",
                  "NTyPmobX"
                ],
                task_name: ["zeSiEiNY"],
                create_time: ["hcDrvHlT"],
                result: ["SGGULtVc"],
                status: ["OytMmxkZ"]
              },
              visibleCols: [true]
            },
            eGDhpSfU: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "eGDhpSfU",
              title: "\u5355\u4E2A\u4EFB\u52A1\u5217\u5BB9\u5668",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [
                [
                  { span: "20", locked: false, id: "HlRTpEzq" },
                  { span: "4", locked: false, id: "yPCUpjhs" }
                ],
                [{ span: "24", locked: false, id: "BaOtJLcn" }]
              ],
              style: { width: "100%", height: "100%", margin: "8px 0px 0px 0px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1"
            },
            HlRTpEzq: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "HlRTpEzq",
              span: "20",
              title: "\u6805\u683C1",
              style: { height: "100%" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            zeSiEiNY: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "zeSiEiNY",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727", fontSize: 16, fontWeight: 700 },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: false,
              required: false,
              style: {
                padding: "0px 0px 0px",
                width: "100%",
                overflow: "hidden",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis"
              },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$3",
              field: "task_name",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" }
            },
            hcDrvHlT: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "hcDrvHlT",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u63D0\u4EA4\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: false,
              style: { padding: "4px 0px 4px 0px" },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$1",
              field: "create_time",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" }
            },
            SGGULtVc: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "SGGULtVc",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
              checkByExp: [],
              visible: true,
              showTitleEffective: false,
              required: false,
              style: {
                width: "100%",
                overflow: "hidden",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                padding: "0px 0px 0px"
              },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$4",
              field: "result",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "result", title: "\u7ED3\u679C" },
              showValColorEffective: false,
              linkage: null
            },
            DfXGtDhP: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "DfXGtDhP",
              title: "\u64CD\u4F5C\u6309\u94AE\u5BB9\u5668",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [[{ span: "24", locked: false, id: "mGWhTYJc" }]],
              style: { width: "100%", height: "22px", minHeight: "22px" },
              visible: false,
              widgetCode: "FlexLayoutContainer$4"
            },
            mGWhTYJc: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "mGWhTYJc",
              span: "24",
              title: "\u6805\u683C1",
              style: { height: "22px", display: "flex", minHeight: "22px" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            adDIyOFF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              id: "adDIyOFF",
              labelList: ["\u4E0B\u8F7D\u7ED3\u679C"],
              style: { padding: "0px 0px 0px", margin: "0px 4px 0px 4px" },
              titleWeight: 400,
              vGutter: 0,
              titleAlign: "left",
              iconType: "FiDownloadCloud",
              visible: false,
              showTitleEffective: false,
              labelColor: "#272727",
              fontStyle: { color: "rgba(0,102,244,1)" },
              title: "\u4E0B\u8F7D\u7ED3\u679C\u6309\u94AE-\u6709\u51FA\u53C2\u503C\u624D\u663E\u793A",
              widgetCode: "TextLabel$2",
              eventTypesWithTags: []
            },
            yXNMnRYz: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              id: "yXNMnRYz",
              labelList: ["\u91CD\u8BD5"],
              style: { padding: "0px 0px 0px", margin: "0px 4px 0px 4px" },
              titleWeight: 400,
              vGutter: 2,
              titleAlign: "left",
              iconType: "FiRotateCw",
              visible: false,
              showTitleEffective: false,
              labelColor: "#272727",
              fontStyle: { color: "rgba(0,102,244,1)" },
              title: "\u91CD\u8BD5\u7ED3\u679C\u6309\u94AE-\u90E8\u5206\u5931\u8D25\u3001\u5931\u8D25\u3001\u5DF2\u7EC8\u6B62\u72B6\u6001\u4E0B\u624D\u652F\u6301\u91CD\u8BD5",
              widgetCode: "TextLabel$4",
              eventTypesWithTags: []
            },
            YaxeIcyn: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              id: "YaxeIcyn",
              labelList: ["\u7EC8\u6B62"],
              style: { padding: "0px 0px 0px", margin: "0px 4px 0px 4px" },
              titleWeight: 400,
              vGutter: 0,
              titleAlign: "left",
              iconType: "FiMinusCircle",
              visible: false,
              showTitleEffective: false,
              labelColor: "#272727",
              fontStyle: { color: "rgba(245,63,63,1)" },
              title: "\u7EC8\u6B62\u4EFB\u52A1\u6309\u94AE",
              widgetCode: "TextLabel$3",
              eventTypesWithTags: []
            },
            yPCUpjhs: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "yPCUpjhs",
              title: "\u6805\u683C3",
              span: "4",
              visible: true,
              style: {
                display: "inline-flex",
                minHeight: "28px",
                height: "28px",
                justifyContent: "flex-end"
              },
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            OytMmxkZ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "OytMmxkZ",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "rgba(32,45,65,1)" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: false,
              required: false,
              titleAlign: "left",
              style: { padding: "0px 0px 0px" },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "transparent"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$1",
              field: "status",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              showValColor: "rgba(32,45,65,1)",
              readOnlyBackColorEffective: false,
              showValColorEffective: false
            },
            BaOtJLcn: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "BaOtJLcn",
              title: "\u6805\u683C3",
              span: "24",
              visible: true,
              style: { height: "32px", minHeight: "24px" },
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            NTyPmobX: {
              varMap: {},
              widgetRef: "FormDivider",
              group: "actionControl",
              id: "NTyPmobX",
              title: "\u5206\u5272\u7EBF",
              titleWeight: 400,
              labelColor: "#272727",
              visible: true,
              showTitleEffective: false,
              lineType: "solid",
              lineWidth: 1,
              type: "horizontalTitleTop",
              titleAlign: "left",
              showValColor: "rgba(237,240,244,1)",
              style: { width: "100%" },
              widgetCode: "FormDivider$4"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            YDrAfAei: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "hSZNTvkO",
                                      eventType: "onQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u5FAA\u73AF\u7EC4\u4EF6 | \u6807\u9898: \u4EFB\u52A1\u5217\u8868"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            adDIyOFF: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_sphGFKhZ" },
                                    { expId: "exp_ptLuoang" },
                                    { expId: "exp_etLTpike" },
                                    { expId: "exp_EWFKRMsT" },
                                    { expId: "exp_DhDBQJEJ" }
                                  ],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.downloadFileStream) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  downloadType: "api",
                                  api: "FileDownload",
                                  input: [
                                    {
                                      "__root.fileIdentifier": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_sphGFKhZ",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.fileName": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ptLuoang",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.fileSize": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_etLTpike",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.fileType": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_EWFKRMsT",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  fileName: yield pageCtx.getExpResult({
                                    id: "exp_DhDBQJEJ",
                                    source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                  })
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4E0B\u8F7D\u4EFB\u52A1\u7ED3\u679C" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            yXNMnRYz: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "hSZNTvkO",
                                      path: ["currentRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: true
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.updateDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1687177166425",
                                  updateType: "submitWholeForm",
                                  input: [],
                                  conditionBasis: [
                                    {
                                      "__root.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "hSZNTvkO",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["currentRowKey"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: true,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u91CD\u8BD5\u5E94\u7528\u4EFB\u52A1\u4E2D\u5FC3" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            YaxeIcyn: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "hSZNTvkO",
                                      path: ["currentRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "\u5373\u5C06\u7EC8\u6B62\u6267\u884C\u4E2D\u7684\u4EFB\u52A1\uFF0C\u4F46\u5DF2\u53D8\u66F4\u7684\u6570\u636E\u53EF\u80FD\u4E0D\u53EF\u6062\u590D\uFF0C\u8BF7\u786E\u8BA4\u662F\u5426\u7EE7\u7EED\u64CD\u4F5C\uFF1F",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1687177151712",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "YaxeIcyn"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "hSZNTvkO",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "hSZNTvkO",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["currentRowKey"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: true
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u7EC8\u6B62\u5E94\u7528\u4EFB\u52A1\u4E2D\u5FC3" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "ssQbHaxy",
                  children: [
                    {
                      id: "pRcLBSxQ",
                      children: [
                        {
                          id: "zRBlLxjq",
                          children: [
                            {
                              id: "rGMTJqhR",
                              children: [
                                {
                                  id: "VmZaLFIQ",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        },
                        {
                          id: "xIRMciba",
                          children: [
                            {
                              id: "RkMXHKXm",
                              children: [
                                {
                                  id: "dYWwHZsO",
                                  children: [
                                    {
                                      id: "DGNYSLUN",
                                      children: [
                                        {
                                          id: "DRPUGUXC",
                                          children: [],
                                          parentToChild: "1:1",
                                          type: "node"
                                        }
                                      ],
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "sHvvwDPB",
                                      children: [
                                        {
                                          id: "YDrAfAei",
                                          children: [],
                                          parentToChild: "1:1",
                                          type: "node"
                                        }
                                      ],
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "hSZNTvkO",
                                  children: [
                                    {
                                      id: "hSZNTvkO_subFormBody",
                                      type: "renderProp",
                                      children: [
                                        {
                                          id: "eGDhpSfU",
                                          parentToChild: "1:n",
                                          type: "node",
                                          children: [
                                            {
                                              id: "HlRTpEzq",
                                              children: [
                                                {
                                                  id: "zeSiEiNY",
                                                  children: [],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "hcDrvHlT",
                                                  children: [],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "SGGULtVc",
                                                  children: [],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "DfXGtDhP",
                                                  children: [
                                                    {
                                                      id: "mGWhTYJc",
                                                      children: [
                                                        {
                                                          id: "adDIyOFF",
                                                          children: [],
                                                          parentToChild: "1:1",
                                                          type: "node"
                                                        },
                                                        {
                                                          id: "yXNMnRYz",
                                                          children: [],
                                                          parentToChild: "1:1",
                                                          type: "node"
                                                        },
                                                        {
                                                          id: "YaxeIcyn",
                                                          children: [],
                                                          parentToChild: "1:1",
                                                          type: "node"
                                                        }
                                                      ],
                                                      parentToChild: "1:1",
                                                      type: "node"
                                                    }
                                                  ],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ],
                                              parentToChild: "1:1",
                                              type: "node"
                                            },
                                            {
                                              id: "yPCUpjhs",
                                              children: [
                                                {
                                                  id: "OytMmxkZ",
                                                  children: [],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ],
                                              parentToChild: "1:1",
                                              type: "node"
                                            },
                                            {
                                              id: "BaOtJLcn",
                                              children: [
                                                {
                                                  id: "NTyPmobX",
                                                  children: [],
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ],
                                              parentToChild: "1:1",
                                              type: "node"
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_DOnVGdKr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  zeSiEiNY: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "zeSiEiNY",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_oCoMyXmh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hcDrvHlT: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "hcDrvHlT",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_MNYNPyTV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SGGULtVc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "SGGULtVc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cmiZKXhk: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Includes(["0", "1", "7"], param == null ? void 0 : param.$0) ? "#0066F4" : platform_exp_default.Includes(["2", "3", "5", "8"], param == null ? void 0 : param.$0) ? "#F53F3F" : "#7E8CA8";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SGGULtVc: [
                    {
                      path: "showValColorEffective",
                      defaultValue: false,
                      id: "SGGULtVc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: { "currentRow.status.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_sDyaXHJk: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SGGULtVc: [
                    { path: "saveValV2", id: "SGGULtVc", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { SGGULtVc: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_RBlbwzWn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !platform_exp_default.HasEmpty(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  adDIyOFF: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "adDIyOFF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_sphGFKhZ: {
              method: (param, pageCtx) => {
                var _a, _b;
                let _expRes = void 0;
                try {
                  _expRes = (_b = (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a[0]) == null ? void 0 : _b.fileIdentifier;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "adDIyOFF" }] },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_ptLuoang: {
              method: (param, pageCtx) => {
                var _a, _b;
                let _expRes = void 0;
                try {
                  _expRes = (_b = (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a[0]) == null ? void 0 : _b.fileName;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "adDIyOFF" }] },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_etLTpike: {
              method: (param, pageCtx) => {
                var _a, _b;
                let _expRes = void 0;
                try {
                  _expRes = (_b = (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a[0]) == null ? void 0 : _b.fileSize;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "adDIyOFF" }] },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_EWFKRMsT: {
              method: (param, pageCtx) => {
                var _a, _b;
                let _expRes = void 0;
                try {
                  _expRes = (_b = (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a[0]) == null ? void 0 : _b.fileType;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "adDIyOFF" }] },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_DhDBQJEJ: {
              method: (param, pageCtx) => {
                var _a, _b;
                let _expRes = void 0;
                try {
                  _expRes = (_b = (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a[0]) == null ? void 0 : _b.fileName;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "adDIyOFF" }] },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_qusSFlxX: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Includes(["2", "3", "5", "6"], param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  yXNMnRYz: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "yXNMnRYz",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: { "currentRow.status.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_atLmXSkO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Includes(["0", "1"], param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  YaxeIcyn: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "YaxeIcyn",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: { "currentRow.status.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_NETuIzok: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !platform_exp_default.HasEmpty(param == null ? void 0 : param.$0) || platform_exp_default.Includes(["2", "3", "5", "6"], param == null ? void 0 : param.$1) || platform_exp_default.Includes(["0", "1"], param == null ? void 0 : param.$1);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  DfXGtDhP: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "DfXGtDhP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: {
                    "currentRow.output_file_param.saveValV2": { paramKey: "$0" },
                    "currentRow.status.saveValV2": { paramKey: "$1" }
                  }
                }
              }
            },
            exp_nAPbgkFX: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  OytMmxkZ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "OytMmxkZ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cNoVjmxN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Includes(["2", "3", "5", "8"], param == null ? void 0 : param.$0) ? "#FFF7F7" : platform_exp_default.Includes(["4"], param == null ? void 0 : param.$0) ? "#E9FFF2" : platform_exp_default.Includes(["6"], param == null ? void 0 : param.$0) ? "#FFF7E7" : "transparent";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  OytMmxkZ: [
                    {
                      path: "readOnlyBackColorEffective",
                      defaultValue: false,
                      id: "OytMmxkZ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: { "currentRow.status.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_JOoIvBQN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Includes(["0"], param == null ? void 0 : param.$0) ? "#7E8CA8" : platform_exp_default.Includes(["1", "7"], param == null ? void 0 : param.$0) ? "#0066F4" : "#202D41";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  OytMmxkZ: [
                    {
                      path: "showValColorEffective",
                      defaultValue: false,
                      id: "OytMmxkZ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  hSZNTvkO: { "currentRow.status.saveValV2": { paramKey: "$0" } }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            user: {
              LESSEE: [
                {
                  id: "hSZNTvkO",
                  type: "widget",
                  path: "conditions.1.value",
                  action: "changeConditions"
                }
              ],
              APP_CODE: [
                {
                  id: "hSZNTvkO",
                  type: "widget",
                  path: "conditions.2.value",
                  action: "changeConditions"
                }
              ],
              UID: [
                {
                  id: "hSZNTvkO",
                  type: "widget",
                  path: "conditions.3.value",
                  action: "changeConditions"
                }
              ]
            },
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_DOnVGdKr", type: "exp" },
                { id: "exp_oCoMyXmh", type: "exp" },
                { id: "exp_MNYNPyTV", type: "exp" },
                { id: "exp_nAPbgkFX", type: "exp" }
              ]
            },
            widget: {
              DRPUGUXC: {
                saveValV2: [
                  {
                    id: "hSZNTvkO",
                    type: "widget",
                    path: "conditions.0.value",
                    action: "changeConditions"
                  }
                ]
              },
              hSZNTvkO: {
                "currentRow.status.saveValV2": [
                  { id: "exp_cmiZKXhk", type: "exp" },
                  { id: "exp_qusSFlxX", type: "exp" },
                  { id: "exp_atLmXSkO", type: "exp" },
                  { id: "exp_NETuIzok", type: "exp" },
                  { id: "exp_cNoVjmxN", type: "exp" },
                  { id: "exp_JOoIvBQN", type: "exp" }
                ],
                "currentRow.output_file_param.saveValV2": [
                  { id: "exp_RBlbwzWn", type: "exp" },
                  { id: "exp_NETuIzok", type: "exp" }
                ]
              },
              SGGULtVc: { saveValV2: [{ id: "exp_sDyaXHJk", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$ssQbHaxy`,
            key: `PC$$ssQbHaxy`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$ssQbHaxy$$pRcLBSxQ`,
              key: `PC$$ssQbHaxy$$pRcLBSxQ`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq`,
                key: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq`,
                pageCtx,
                widgetRef: "FlexLayoutContainer"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq$$rGMTJqhR`,
                  key: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq$$rGMTJqhR`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq$$rGMTJqhR$$VmZaLFIQ`,
                    key: `PC$$ssQbHaxy$$pRcLBSxQ$$zRBlLxjq$$rGMTJqhR$$VmZaLFIQ`,
                    pageCtx,
                    widgetRef: "TextLabel"
                  }
                )
              )
            ),
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba`,
                key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba`,
                pageCtx,
                widgetRef: "FlexLayoutContainer"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm`,
                  key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO`,
                    key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO`,
                    pageCtx,
                    widgetRef: "FlexLayoutContainer"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$DGNYSLUN`,
                      key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$DGNYSLUN`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$DGNYSLUN$$DRPUGUXC`,
                        key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$DGNYSLUN$$DRPUGUXC`,
                        pageCtx,
                        widgetRef: "FormInput"
                      }
                    )
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$sHvvwDPB`,
                      key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$sHvvwDPB`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$sHvvwDPB$$YDrAfAei`,
                        key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$dYWwHZsO$$sHvvwDPB$$YDrAfAei`,
                        pageCtx,
                        widgetRef: "Icons"
                      }
                    )
                  )
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO`,
                    key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO`,
                    pageCtx,
                    widgetRef: "Loop",
                    bodyRenderer: ({
                      index: hSZNTvkO_indexFromSubform,
                      rowIndex: hSZNTvkO_rowIndexFromSubform
                    }) => [
                      /* @__PURE__ */ react_default.createElement(
                        COMPCONTROL.CompEntry,
                        {
                          path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU`,
                          key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU`,
                          pageCtx,
                          widgetRef: "FlexLayoutContainer"
                        },
                        /* @__PURE__ */ react_default.createElement(
                          COMPCONTROL.CompEntry,
                          {
                            path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq`,
                            key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq`,
                            pageCtx,
                            widgetRef: "FlexLayout"
                          },
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$zeSiEiNY`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$zeSiEiNY`,
                              pageCtx,
                              widgetRef: "FormInput"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$hcDrvHlT`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$hcDrvHlT`,
                              pageCtx,
                              widgetRef: "FormDateTimePicker"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$SGGULtVc`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$SGGULtVc`,
                              pageCtx,
                              widgetRef: "FormInput"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP`,
                              pageCtx,
                              widgetRef: "FlexLayoutContainer"
                            },
                            /* @__PURE__ */ react_default.createElement(
                              COMPCONTROL.CompEntry,
                              {
                                path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc`,
                                key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc`,
                                pageCtx,
                                widgetRef: "FlexLayout"
                              },
                              /* @__PURE__ */ react_default.createElement(
                                COMPCONTROL.CompEntry,
                                {
                                  path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$adDIyOFF`,
                                  key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$adDIyOFF`,
                                  pageCtx,
                                  widgetRef: "TextLabel"
                                }
                              ),
                              /* @__PURE__ */ react_default.createElement(
                                COMPCONTROL.CompEntry,
                                {
                                  path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$yXNMnRYz`,
                                  key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$yXNMnRYz`,
                                  pageCtx,
                                  widgetRef: "TextLabel"
                                }
                              ),
                              /* @__PURE__ */ react_default.createElement(
                                COMPCONTROL.CompEntry,
                                {
                                  path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$YaxeIcyn`,
                                  key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$HlRTpEzq$$DfXGtDhP$$mGWhTYJc$$YaxeIcyn`,
                                  pageCtx,
                                  widgetRef: "TextLabel"
                                }
                              )
                            )
                          )
                        ),
                        /* @__PURE__ */ react_default.createElement(
                          COMPCONTROL.CompEntry,
                          {
                            path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$yPCUpjhs`,
                            key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$yPCUpjhs`,
                            pageCtx,
                            widgetRef: "FlexLayout"
                          },
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$yPCUpjhs$$OytMmxkZ`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$yPCUpjhs$$OytMmxkZ`,
                              pageCtx,
                              widgetRef: "DropdownSelector"
                            }
                          )
                        ),
                        /* @__PURE__ */ react_default.createElement(
                          COMPCONTROL.CompEntry,
                          {
                            path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$BaOtJLcn`,
                            key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$BaOtJLcn`,
                            pageCtx,
                            widgetRef: "FlexLayout"
                          },
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$BaOtJLcn$$NTyPmobX`,
                              key: `PC$$ssQbHaxy$$pRcLBSxQ$$xIRMciba$$RkMXHKXm$$hSZNTvkO$$%${hSZNTvkO_indexFromSubform}%$$eGDhpSfU$$BaOtJLcn$$NTyPmobX`,
                              pageCtx,
                              widgetRef: "FormDivider"
                            }
                          )
                        )
                      )
                    ]
                  }
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1668536656136908800, "pageName", "\u5E94\u7528\u7EA7\u4E2A\u4EBA\u4EFB\u52A1\u4E2D\u5FC3");
  __publicField(Page1668536656136908800, "$pageKey", "pbbnahuv");
  __publicField(Page1668536656136908800, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
