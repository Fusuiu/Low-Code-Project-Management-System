var Page1548855937488531456 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1548855937488531456: () => Page1548855937488531456
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1548855937488531456 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1548855937488531456",
            pageName: "\u64CD\u4F5C\u65E5\u5FD7\u8868\u5355",
            apiMeta: {
              "1535094014561366016_detail_1658110241272": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.error_msg": {
                    title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F",
                    __key: "error_msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_module": {
                    title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
                    __key: "business_module",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_code": {
                    title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
                    __key: "hr_member_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_name": {
                    title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
                    __key: "hr_member_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.ip_address": {
                    title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740",
                    __key: "ip_address",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.log_date": {
                    title: "\u65E5\u5FD7\u65F6\u95F4",
                    __key: "log_date",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_behavior": {
                    title: "\u4F5C\u4E1A\u884C\u4E3A",
                    __key: "object_behavior",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_message": {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
                    __key: "object_message",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_name": {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
                    __key: "object_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_result": {
                    title: "\u4F5C\u4E1A\u7ED3\u679C",
                    __key: "object_result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_code": {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u7F16\u53F7",
                    __key: "org_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_name": {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
                    __key: "org_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.page_name": {
                    title: "\u64CD\u4F5C\u9875\u9762",
                    __key: "page_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.user_account_name": {
                    title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
                    __key: "user_account_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.username": {
                    title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D",
                    __key: "username",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.data_status": {
                    title: "\u6570\u636E\u72B6\u6001",
                    __key: "data_status",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.enable_disable": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001",
                    __key: "enable_disable",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              showBottomBar: true,
              style: { backgroundColor: "transparent" },
              title: "\u64CD\u4F5C\u65E5\u5FD7\u8868\u5355",
              sockets: [],
              dss: ["1535094014561366016_detail_1658110241272"],
              requests: {
                "1535094014561366016_detail_1658110241272": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              }
            },
            aooWtato: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "aooWtato",
              contentAlign: "right",
              style: { padding: "16px 0px 0px 0px" },
              widgetCode: "FloatBar$1"
            },
            raWWgWWr: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "raWWgWWr",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$1"
            },
            tgirWemt: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "tgirWemt",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              eventTypesWithTags: [],
              widgetCode: "FormButton$2"
            },
            EAfhfdZQ: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "EAfhfdZQ",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$1",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "XxhHHqqX", visible: true, widgetRef: "FormInput" },
                { id: "tsYsgzKV", visible: true, widgetRef: "FormInput" }
              ]
            },
            XxhHHqqX: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "XxhHHqqX",
              title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$2",
              field: "username",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.username"
              },
              readOnly: false,
              stringLength: 32
            },
            tsYsgzKV: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "tsYsgzKV",
              title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$3",
              field: "user_account_name",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.user_account_name"
              },
              readOnly: false,
              stringLength: 32
            },
            NVFdcZqP: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "NVFdcZqP",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$4",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "qCQANUvi", visible: true, widgetRef: "FormInput" },
                { id: "PsLVEnBY", visible: true, widgetRef: "FormInput" }
              ]
            },
            qCQANUvi: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "qCQANUvi",
              title: "\u4F5C\u4E1A\u884C\u4E3A",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$10",
              field: "object_behavior",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.object_behavior"
              },
              readOnly: false,
              stringLength: 256
            },
            PsLVEnBY: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "PsLVEnBY",
              title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$11",
              field: "object_name",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.object_name"
              },
              readOnly: false
            },
            ywjnegwZ: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "ywjnegwZ",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$3",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "XvYZHmTw", visible: true, widgetRef: "FormInput" },
                { id: "GdaSuJqg", visible: true, widgetRef: "FormInput" }
              ]
            },
            XvYZHmTw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "XvYZHmTw",
              title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$12",
              field: "object_message",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.object_message"
              },
              readOnly: false
            },
            GdaSuJqg: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "GdaSuJqg",
              title: "\u4F5C\u4E1A\u7ED3\u679C",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$13",
              field: "object_result",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.object_result"
              },
              readOnly: false
            },
            PhTQAoEu: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "PhTQAoEu",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$2",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "EdrWPFhf", visible: true, widgetRef: "FormInput" },
                { id: "KUaABemH", visible: true, widgetRef: "FormInput" }
              ]
            },
            EdrWPFhf: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "EdrWPFhf",
              title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$16",
              field: "business_module",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.business_module"
              },
              readOnly: false
            },
            KUaABemH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "KUaABemH",
              title: "\u64CD\u4F5C\u9875\u9762",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$17",
              field: "page_name",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.page_name"
              },
              readOnly: false
            },
            zEUinfzp: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "zEUinfzp",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$6",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                {
                  id: "EosOievw",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                { id: "IXTQoUVZ", visible: true, widgetRef: "FormInput" }
              ]
            },
            EosOievw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "EosOievw",
              title: "\u65E5\u5FD7\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              widgetCode: "FormDateTimePicker$2",
              field: "log_date",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.log_date"
              },
              readOnly: false
            },
            IXTQoUVZ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "IXTQoUVZ",
              title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$18",
              field: "org_name",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.org_name"
              },
              readOnly: false
            },
            ybCjJfQk: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "ybCjJfQk",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$5",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "jyQRgXhK", visible: true, widgetRef: "FormInput" },
                { id: "FKRYgDiG", visible: true, widgetRef: "FormInput" }
              ]
            },
            jyQRgXhK: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "jyQRgXhK",
              title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$19",
              field: "hr_member_name",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.hr_member_name"
              },
              readOnly: false
            },
            FKRYgDiG: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "FKRYgDiG",
              title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$20",
              field: "hr_member_code",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.hr_member_code"
              },
              readOnly: false
            },
            qZpCnzZU: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "qZpCnzZU",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$8",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "GxwInqJg", visible: true, widgetRef: "FormInput" },
                { id: "ZbvFRdIw", visible: true, widgetRef: "FormInput" }
              ]
            },
            GxwInqJg: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "GxwInqJg",
              title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u7F16\u53F7",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$21",
              field: "org_code",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.org_code"
              },
              readOnly: false,
              stringLength: 20
            },
            ZbvFRdIw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "ZbvFRdIw",
              title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$22",
              field: "ip_address",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.ip_address"
              },
              readOnly: false
            },
            wrzxTTPr: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "wrzxTTPr",
              colCounts: 1,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: { width: "100%" },
              widgetCode: "GridLayout$9",
              title: "\u5217\u5E03\u5C401",
              bodyInfo: [
                { id: "QBOFCefg", visible: true, widgetRef: "Textarea" }
              ]
            },
            QBOFCefg: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Textarea",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              parseInReadOnly: true,
              id: "QBOFCefg",
              titleAlign: "left",
              title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F",
              visible: true,
              showTitleEffective: true,
              checkByExp: [],
              rows: 3,
              style: {},
              required: false,
              widgetCode: "Textarea$1",
              field: "error_msg",
              fieldInfo: {
                ds: "1535094014561366016_detail_1658110241272",
                path: "__root.result.data.error_msg"
              },
              readOnly: false,
              stringLength: 65535
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1535094014561366016_detail_1658110241272",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1535094014561366016_detail_1658110241272",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            tgirWemt: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "aooWtato",
                  children: [
                    {
                      id: "raWWgWWr",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "tgirWemt",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "EAfhfdZQ",
                  children: [
                    {
                      id: "XxhHHqqX",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "tsYsgzKV",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "NVFdcZqP",
                  children: [
                    {
                      id: "qCQANUvi",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "PsLVEnBY",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "ywjnegwZ",
                  children: [
                    {
                      id: "XvYZHmTw",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "GdaSuJqg",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "PhTQAoEu",
                  children: [
                    {
                      id: "EdrWPFhf",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "KUaABemH",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "zEUinfzp",
                  children: [
                    {
                      id: "EosOievw",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "IXTQoUVZ",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "ybCjJfQk",
                  children: [
                    {
                      id: "jyQRgXhK",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "FKRYgDiG",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "qZpCnzZU",
                  children: [
                    {
                      id: "GxwInqJg",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "ZbvFRdIw",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "wrzxTTPr",
                  children: [
                    {
                      id: "QBOFCefg",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_mlgolegl: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  raWWgWWr: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "raWWgWWr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_liprTdCj: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  XxhHHqqX: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "XxhHHqqX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zcTQhKzd: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  tsYsgzKV: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "tsYsgzKV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_natDBjBP: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  qCQANUvi: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "qCQANUvi",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_gjvuAuoI: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  PsLVEnBY: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "PsLVEnBY",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_CbAwAsyZ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  XvYZHmTw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "XvYZHmTw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_BqVgFlUC: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  GdaSuJqg: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "GdaSuJqg",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_BVancxGV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EdrWPFhf: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EdrWPFhf",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ydBcslJL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  KUaABemH: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "KUaABemH",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_quErmsgr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EosOievw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EosOievw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_PQiodmLf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  IXTQoUVZ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "IXTQoUVZ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zSITzwuo: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  jyQRgXhK: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "jyQRgXhK",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_bQeARvCs: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FKRYgDiG: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "FKRYgDiG",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_blGIxmdw: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  GxwInqJg: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "GxwInqJg",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_hmWjjFYL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ZbvFRdIw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ZbvFRdIw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_IpgbQzDB: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  QBOFCefg: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "QBOFCefg",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_mlgolegl", type: "exp" },
                { id: "exp_liprTdCj", type: "exp" },
                { id: "exp_zcTQhKzd", type: "exp" },
                { id: "exp_natDBjBP", type: "exp" },
                { id: "exp_gjvuAuoI", type: "exp" },
                { id: "exp_CbAwAsyZ", type: "exp" },
                { id: "exp_BqVgFlUC", type: "exp" },
                { id: "exp_BVancxGV", type: "exp" },
                { id: "exp_ydBcslJL", type: "exp" },
                { id: "exp_quErmsgr", type: "exp" },
                { id: "exp_PQiodmLf", type: "exp" },
                { id: "exp_zSITzwuo", type: "exp" },
                { id: "exp_bQeARvCs", type: "exp" },
                { id: "exp_blGIxmdw", type: "exp" },
                { id: "exp_hmWjjFYL", type: "exp" },
                { id: "exp_IpgbQzDB", type: "exp" }
              ]
            },
            widget: {}
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$aooWtato`,
            key: `PC$$aooWtato`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$aooWtato$$raWWgWWr`,
              key: `PC$$aooWtato$$raWWgWWr`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$aooWtato$$tgirWemt`,
              key: `PC$$aooWtato$$tgirWemt`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$EAfhfdZQ`,
            key: `PC$$EAfhfdZQ`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$EAfhfdZQ$$XxhHHqqX`,
              key: `PC$$EAfhfdZQ$$XxhHHqqX`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$EAfhfdZQ$$tsYsgzKV`,
              key: `PC$$EAfhfdZQ$$tsYsgzKV`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$NVFdcZqP`,
            key: `PC$$NVFdcZqP`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$NVFdcZqP$$qCQANUvi`,
              key: `PC$$NVFdcZqP$$qCQANUvi`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$NVFdcZqP$$PsLVEnBY`,
              key: `PC$$NVFdcZqP$$PsLVEnBY`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$ywjnegwZ`,
            key: `PC$$ywjnegwZ`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$ywjnegwZ$$XvYZHmTw`,
              key: `PC$$ywjnegwZ$$XvYZHmTw`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$ywjnegwZ$$GdaSuJqg`,
              key: `PC$$ywjnegwZ$$GdaSuJqg`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$PhTQAoEu`,
            key: `PC$$PhTQAoEu`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$PhTQAoEu$$EdrWPFhf`,
              key: `PC$$PhTQAoEu$$EdrWPFhf`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$PhTQAoEu$$KUaABemH`,
              key: `PC$$PhTQAoEu$$KUaABemH`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$zEUinfzp`,
            key: `PC$$zEUinfzp`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$zEUinfzp$$EosOievw`,
              key: `PC$$zEUinfzp$$EosOievw`,
              pageCtx,
              widgetRef: "FormDateTimePicker"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$zEUinfzp$$IXTQoUVZ`,
              key: `PC$$zEUinfzp$$IXTQoUVZ`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$ybCjJfQk`,
            key: `PC$$ybCjJfQk`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$ybCjJfQk$$jyQRgXhK`,
              key: `PC$$ybCjJfQk$$jyQRgXhK`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$ybCjJfQk$$FKRYgDiG`,
              key: `PC$$ybCjJfQk$$FKRYgDiG`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$qZpCnzZU`,
            key: `PC$$qZpCnzZU`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qZpCnzZU$$GxwInqJg`,
              key: `PC$$qZpCnzZU$$GxwInqJg`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qZpCnzZU$$ZbvFRdIw`,
              key: `PC$$qZpCnzZU$$ZbvFRdIw`,
              pageCtx,
              widgetRef: "FormInput"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$wrzxTTPr`,
            key: `PC$$wrzxTTPr`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$wrzxTTPr$$QBOFCefg`,
              key: `PC$$wrzxTTPr$$QBOFCefg`,
              pageCtx,
              widgetRef: "Textarea"
            }
          )
        )
      );
    }
  };
  __publicField(Page1548855937488531456, "pageName", "\u64CD\u4F5C\u65E5\u5FD7\u8868\u5355");
  __publicField(Page1548855937488531456, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
