var Page1668504044102103040 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1668504044102103040: () => Page1668504044102103040
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1668504044102103040 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1668504044102103040",
            pageName: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u4E2D\u5FC3",
            apiMeta: {
              bis_api_1686908447992: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.remark": {
                    title: "\u5907\u6CE8\u63CF\u8FF0",
                    __key: "remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.output_file_param": {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "output_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.input_file_param": {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "input_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.progress": {
                    title: "\u8FDB\u5EA6",
                    __key: "progress",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.result": {
                    title: "\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.end_exec_time": {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6",
                    __key: "end_exec_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.exec_cost_time": {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F",
                    __key: "exec_cost_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.start_exec_time": {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4",
                    __key: "start_exec_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_des": {
                    title: "\u72B6\u6001\u63CF\u8FF0",
                    __key: "status_des",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u4EFB\u52A1\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_name": {
                    title: "\u4EFB\u52A1\u540D\u79F0",
                    __key: "task_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_type": {
                    title: "\u4EFB\u52A1\u7C7B\u578B",
                    __key: "task_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u53F7",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.less_code": {
                    title: "\u79DF\u6237\u53F7",
                    __key: "less_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  remark: {
                    title: "\u5907\u6CE8\u63CF\u8FF0"
                  },
                  output_file_param: {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  input_file_param: {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  progress: {
                    title: "\u8FDB\u5EA6"
                  },
                  result: {
                    title: "\u7ED3\u679C"
                  },
                  end_exec_time: {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6"
                  },
                  exec_cost_time: {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F"
                  },
                  start_exec_time: {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4"
                  },
                  status_des: {
                    title: "\u72B6\u6001\u63CF\u8FF0"
                  },
                  status: {
                    title: "\u4EFB\u52A1\u72B6\u6001"
                  },
                  task_name: {
                    title: "\u4EFB\u52A1\u540D\u79F0"
                  },
                  task_type: {
                    title: "\u4EFB\u52A1\u7C7B\u578B"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u53F7"
                  },
                  less_code: {
                    title: "\u79DF\u6237\u53F7"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_user: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  }
                }
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u4E2D\u5FC3"
            },
            WkMFjWwG: {
              varMap: { curTab: { type: "string" }, tapTab: { type: "string" } },
              widgetRef: "TabContainer",
              eventAttr: ["onTabChange", "onTabClick"],
              id: "WkMFjWwG",
              title: "\u6807\u7B7E\u9875",
              visible: true,
              showTitleEffective: false,
              titleAlign: "left",
              tabsVisibleList: [true, false],
              curTab: "",
              tabsList: [
                {
                  title: "\u5F02\u6B65\u4EFB\u52A1",
                  icon: "",
                  id: "QtRppnay",
                  style: { height: "auto" },
                  widgetCode: "Tab$1"
                },
                {
                  title: "\u5168\u90E8",
                  icon: "",
                  id: "UtqOSUVt",
                  style: { height: "auto" },
                  widgetCode: "Tab$1"
                }
              ],
              titleWeight: 400,
              labelColor: "#272727",
              style: { width: "100%", height: "100%" },
              widgetCode: "TabContainer$1",
              tabType: "card",
              tabBarGutter: 12
            },
            QtRppnay: {
              varMap: {},
              widgetRef: "PureFlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "QtRppnay",
              span: 24,
              title: "\u6807\u7B7E1\u5BB9\u5668",
              style: { height: "100%", border: "0px solid #D6D7DA" },
              visible: true,
              widgetCode: "PureFlexLayout$1"
            },
            ozEHSGbl: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "ozEHSGbl",
              title: "\u5F02\u6B65\u4EFB\u52A1\u5217\u8868",
              titleAlign: "left",
              tableColumnHeaderStyle: { borderTheme: "divisionLine" },
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              fullscreen: true,
              searchExpandCollapse: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              btnsGroups: [
                { title: "\u66F4\u591A", id: "RVeDrbwS", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "CTriSVak", type: "inlineBtns" }
              ],
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "ZnQoZeoe",
                  show: "visible",
                  type: "detail",
                  groupId: "CTriSVak"
                }
              ],
              widgetCode: "NormalTable$5",
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  columnName: "task_name",
                  widgetId: "nHiqoiiU"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA",
                  columnName: "create_user_name",
                  widgetId: "SZNSFQuF"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  columnName: "create_time",
                  widgetId: "mNfdmKXh"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  columnName: "status",
                  widgetId: "kvlPqMzj"
                }
              ],
              columns: [
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "task_name",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  fixed: "left",
                  widgetId: "EmqDxDGR",
                  widgetRef: "FormInput",
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "status",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "xhJlmGvk",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "create_user_name",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  widgetId: "KNRgVMea",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  align: "left",
                  dataIndex: "_hy_ppVLUeiB",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  configShow: true,
                  showSortBtn: false,
                  sortEditable: false,
                  width: "150px",
                  display: true,
                  title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
                  expId: "exp_GLYyuhlr",
                  widgetId: "ppVLUeiB",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  color: "#272727"
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "exec_cost_time",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  widgetId: "BUbFpJnW",
                  widgetRef: "FormInput",
                  title: "\u7ED3\u679C\u8017\u65F6",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "create_time",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  widgetId: "Bjmtkniy",
                  widgetRef: "FormDateTimePicker",
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "start_exec_time",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  widgetId: "EebcEYOw",
                  widgetRef: "FormDateTimePicker",
                  title: "\u5F00\u59CB\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "end_exec_time",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  showSortBtn: true,
                  sortEditable: true,
                  width: "150px",
                  widgetId: "iogJtmJl",
                  widgetRef: "FormDateTimePicker",
                  title: "\u7ED3\u675F\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              conditions: [
                {
                  varAlias: 1,
                  field: "task_type",
                  paramAmount: 1,
                  method: "equ",
                  value: ["1"]
                }
              ],
              formula: "1",
              tagKey: "",
              keyshow: false,
              ds: "bis_api_1686908447992",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "progress",
                "result",
                "end_exec_time",
                "exec_cost_time",
                "start_exec_time",
                "status_des",
                "status",
                "task_name",
                "last_update_time",
                "create_time",
                "create_user_name"
              ],
              relatedAppPage: {
                pageNameCn: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355",
                pageId: "1668512181710368768"
              }
            },
            fkbytLmQ: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "fkbytLmQ",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsProps: {
                nHiqoiiU: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                SZNSFQuF: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                mNfdmKXh: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                kvlPqMzj: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: ["nHiqoiiU", "kvlPqMzj", "SZNSFQuF", "mNfdmKXh"],
              bodyInfo: [
                { id: "nHiqoiiU", visible: true, widgetRef: "FormInput" },
                { id: "kvlPqMzj", visible: true, widgetRef: "DropdownSelector" },
                { id: "SZNSFQuF", visible: true, widgetRef: "FormInput" },
                {
                  id: "mNfdmKXh",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                }
              ]
            },
            nHiqoiiU: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "nHiqoiiU",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              field: "task_name",
              searchMethod: "like",
              widgetCode: "FormInput$48",
              columnName: "task_name"
            },
            kvlPqMzj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "kvlPqMzj",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$20",
              field: "status",
              fieldInfo: null,
              fieldSearch: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              fieldColumn: null,
              searchMethod: "in",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              }
            },
            SZNSFQuF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "SZNSFQuF",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u64CD\u4F5C\u4EBA",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              field: "create_user_name",
              searchMethod: "like",
              widgetCode: "FormInput$50",
              columnName: "create_user_name"
            },
            mNfdmKXh: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "mNfdmKXh",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u63D0\u4EA4\u65F6\u95F4",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              field: "create_time",
              searchMethod: "like",
              widgetCode: "FormInput$51",
              timeMode: "datetime",
              timeType: "string",
              columnName: "create_time"
            },
            RVeDrbwS: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "RVeDrbwS",
              visible: true,
              customId: "ozEHSGbl_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            CTriSVak: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "CTriSVak",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "ozEHSGbl_inlineBtns",
              btnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "ZnQoZeoe",
                  show: "visible",
                  type: "detail",
                  groupId: "CTriSVak"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            ZnQoZeoe: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "ZnQoZeoe",
              title: "\u4EFB\u52A1\u8BE6\u60C5",
              visible: true,
              disabled: false,
              iconType: "",
              style: { borderRadius: "0px", padding: "2px 4px", width: "auto" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              $lazyload: false,
              type: "link"
            },
            EmqDxDGR: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "EmqDxDGR",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$52",
              field: "task_name",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              $lazyload: false
            },
            xhJlmGvk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "xhJlmGvk",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                2: "\u90E8\u5206\u6210\u529F",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$19",
              field: "status",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              $lazyload: false,
              bodyContainer: true
            },
            KNRgVMea: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "KNRgVMea",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$53",
              field: "create_user_name",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              $lazyload: false
            },
            ppVLUeiB: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "ppVLUeiB",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$54",
              field: null,
              fieldInfo: null,
              fieldSearch: null,
              linkage: null,
              $lazyload: false
            },
            BUbFpJnW: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "BUbFpJnW",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$55",
              field: "exec_cost_time",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "exec_cost_time", title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F" },
              $lazyload: false
            },
            Bjmtkniy: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "Bjmtkniy",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$17",
              field: "create_time",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              $lazyload: false
            },
            EebcEYOw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "EebcEYOw",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$18",
              field: "start_exec_time",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "start_exec_time", title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4" },
              $lazyload: false
            },
            iogJtmJl: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "iogJtmJl",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$19",
              field: "end_exec_time",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "end_exec_time", title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6" },
              $lazyload: false
            },
            UtqOSUVt: {
              varMap: {},
              widgetRef: "PureFlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "UtqOSUVt",
              span: 24,
              title: "\u6807\u7B7E3\u5BB9\u5668",
              style: { height: "100%", border: "0px solid #D6D7DA" },
              visible: true,
              widgetCode: "PureFlexLayout$1"
            },
            COaIJNjL: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "COaIJNjL",
              title: "\u4EFB\u52A1\u5217\u8868",
              titleAlign: "left",
              tableColumnHeaderStyle: { borderTheme: "divisionLine" },
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              fullscreen: true,
              searchExpandCollapse: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              btnsGroups: [
                { title: "\u66F4\u591A", id: "zHeGCCgL", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "qugPiGsY", type: "inlineBtns" }
              ],
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "xZnTZUOD",
                  show: "visible",
                  type: "detail",
                  groupId: "qugPiGsY"
                }
              ],
              widgetCode: "NormalTable$3",
              columns: [
                {
                  dataIndex: "task_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  fixed: "left",
                  widgetId: "IgAfbBvy",
                  widgetRef: "FormInput",
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "task_type",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "gRmFUtGc",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u7C7B\u578B",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "status",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "XnePHvyr",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_user_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "eSrteSpJ",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  align: "left",
                  dataIndex: "_hy_NCruiOnB",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  configShow: true,
                  showSortBtn: false,
                  sortEditable: false,
                  width: "150px",
                  display: true,
                  title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
                  expId: "exp_wLLthOAj",
                  widgetId: "NCruiOnB",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  color: "#272727"
                },
                {
                  dataIndex: "exec_cost_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "kGDVcEQy",
                  widgetRef: "FormInput",
                  title: "\u7ED3\u679C\u8017\u65F6",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "CNLdVDpO",
                  widgetRef: "FormDateTimePicker",
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "start_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "xUjrHKjn",
                  widgetRef: "FormDateTimePicker",
                  title: "\u5F00\u59CB\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "end_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "nmgHxqCP",
                  widgetRef: "FormDateTimePicker",
                  title: "\u7ED3\u675F\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  columnName: "task_name",
                  widgetId: "djejCYrQ"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA",
                  columnName: "create_user_name",
                  widgetId: "HsmJFgJA"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  columnName: "create_time",
                  widgetId: "qGIpCZjd"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u7C7B\u578B",
                  columnName: "task_type",
                  widgetId: "uHjKbgQA"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  columnName: "status",
                  widgetId: "ebAaPJNj"
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              tagKey: "",
              keyshow: false,
              ds: "bis_api_1686908447992",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "progress",
                "result",
                "end_exec_time",
                "exec_cost_time",
                "start_exec_time",
                "status_des",
                "status",
                "task_name",
                "last_update_time",
                "create_time",
                "create_user_name"
              ],
              relatedAppPage: {
                pageNameCn: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355",
                pageId: "1668512181710368768"
              }
            },
            UNUbMkmx: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "UNUbMkmx",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colCounts: 4,
              alignType: "aligned",
              colsProps: {
                djejCYrQ: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                HsmJFgJA: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                qGIpCZjd: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                uHjKbgQA: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                ebAaPJNj: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: [
                "djejCYrQ",
                "uHjKbgQA",
                "ebAaPJNj",
                "HsmJFgJA",
                "qGIpCZjd"
              ],
              bodyInfo: [
                { id: "djejCYrQ", visible: true, widgetRef: "FormInput" },
                { id: "uHjKbgQA", visible: true, widgetRef: "DropdownSelector" },
                { id: "ebAaPJNj", visible: true, widgetRef: "DropdownSelector" },
                { id: "HsmJFgJA", visible: true, widgetRef: "FormInput" },
                {
                  id: "qGIpCZjd",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                }
              ]
            },
            djejCYrQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "djejCYrQ",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              field: "task_name",
              searchMethod: "like",
              widgetCode: "FormInput$19",
              columnName: "task_name"
            },
            uHjKbgQA: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "uHjKbgQA",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u7C7B\u578B",
              options: { 1: "\u5F02\u6B65", 2: "\u5B9A\u65F6" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$11",
              field: "task_type",
              fieldInfo: null,
              fieldSearch: { field: "task_type", title: "\u4EFB\u52A1\u7C7B\u578B" },
              fieldColumn: null,
              searchMethod: "in",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636740939788288_1687861068583"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636740939788288_1687861068583",
                type: "dict"
              }
            },
            ebAaPJNj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "ebAaPJNj",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$12",
              field: "status",
              fieldInfo: null,
              fieldSearch: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              fieldColumn: null,
              searchMethod: "in",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              }
            },
            HsmJFgJA: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "HsmJFgJA",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u64CD\u4F5C\u4EBA",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              field: "create_user_name",
              searchMethod: "like",
              widgetCode: "FormInput$22",
              columnName: "create_user_name"
            },
            qGIpCZjd: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "qGIpCZjd",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u63D0\u4EA4\u65F6\u95F4",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              fieldSearch: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              field: "create_time",
              widgetCode: "FormInput$23",
              timeMode: "datetime",
              timeType: "string",
              columnName: "create_time"
            },
            zHeGCCgL: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "zHeGCCgL",
              visible: true,
              customId: "COaIJNjL_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            qugPiGsY: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "qugPiGsY",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "COaIJNjL_inlineBtns",
              btnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "xZnTZUOD",
                  show: "visible",
                  type: "detail",
                  groupId: "qugPiGsY"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            xZnTZUOD: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "xZnTZUOD",
              title: "\u4EFB\u52A1\u8BE6\u60C5",
              visible: true,
              disabled: false,
              iconType: "",
              style: { borderRadius: "0px", padding: "2px 4px", width: "auto" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              $lazyload: false,
              type: "link"
            },
            IgAfbBvy: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "IgAfbBvy",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$24",
              field: "task_name",
              fieldColumn: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              $lazyload: false,
              columnName: "task_name"
            },
            gRmFUtGc: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "gRmFUtGc",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: { 1: "\u5F02\u6B65", 2: "\u5B9A\u65F6" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$10",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636740939788288_1687861068583"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636740939788288_1687861068583",
                type: "dict"
              },
              field: "task_type",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "task_type", title: "\u4EFB\u52A1\u7C7B\u578B" },
              $lazyload: false,
              bodyContainer: true
            },
            XnePHvyr: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "XnePHvyr",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                2: "\u90E8\u5206\u6210\u529F",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$13",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              field: "status",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              $lazyload: false,
              bodyContainer: true
            },
            eSrteSpJ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "eSrteSpJ",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$27",
              field: "create_user_name",
              fieldColumn: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              $lazyload: false,
              columnName: "create_user_name"
            },
            NCruiOnB: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "NCruiOnB",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$28",
              field: null,
              linkage: null,
              fieldInfo: null,
              fieldSearch: null,
              $lazyload: false,
              columnName: "result"
            },
            kGDVcEQy: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "kGDVcEQy",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$29",
              field: "exec_cost_time",
              fieldColumn: { field: "exec_cost_time", title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F" },
              $lazyload: false,
              columnName: "exec_cost_time"
            },
            CNLdVDpO: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "CNLdVDpO",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$30",
              field: "create_time",
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              timeMode: "datetime",
              timeType: "string",
              $lazyload: false,
              columnName: "create_time"
            },
            xUjrHKjn: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "xUjrHKjn",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$31",
              field: "start_exec_time",
              fieldColumn: { field: "start_exec_time", title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4" },
              timeMode: "datetime",
              timeType: "string",
              $lazyload: false,
              columnName: "start_exec_time"
            },
            nmgHxqCP: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "nmgHxqCP",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$32",
              field: "end_exec_time",
              fieldColumn: { field: "end_exec_time", title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6" },
              timeMode: "datetime",
              timeType: "string",
              $lazyload: false,
              columnName: "end_exec_time"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            ZnQoZeoe: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "ozEHSGbl",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368768",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "PnAbAyXF",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "ozEHSGbl",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "ozEHSGbl",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368768",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "PnAbAyXF",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "ozEHSGbl",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            xZnTZUOD: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "COaIJNjL",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368768",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "oUztiSfM",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "COaIJNjL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "COaIJNjL",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368768",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "oUztiSfM",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "COaIJNjL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "WkMFjWwG",
                  children: [
                    {
                      id: "QtRppnay",
                      children: [
                        {
                          id: "ozEHSGbl",
                          children: [
                            {
                              id: "fkbytLmQ",
                              children: [
                                {
                                  id: "nHiqoiiU",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "kvlPqMzj",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "SZNSFQuF",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "mNfdmKXh",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            },
                            {
                              id: "ozEHSGbl_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "RVeDrbwS",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "ozEHSGbl_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "CTriSVak",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "ZnQoZeoe",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "ozEHSGbl_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "EmqDxDGR",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "xhJlmGvk",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "KNRgVMea",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "ppVLUeiB",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "BUbFpJnW",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "Bjmtkniy",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "EebcEYOw",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "iogJtmJl",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "UtqOSUVt",
                      children: [
                        {
                          id: "COaIJNjL",
                          children: [
                            {
                              id: "UNUbMkmx",
                              children: [
                                {
                                  id: "djejCYrQ",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "uHjKbgQA",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "ebAaPJNj",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "HsmJFgJA",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "qGIpCZjd",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "zHeGCCgL",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "qugPiGsY",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "xZnTZUOD",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "IgAfbBvy",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "gRmFUtGc",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "XnePHvyr",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "eSrteSpJ",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "NCruiOnB",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "kGDVcEQy",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "CNLdVDpO",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "xUjrHKjn",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "nmgHxqCP",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_MIrEBtkh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  kvlPqMzj: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "kvlPqMzj",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_AvBrXziJ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EmqDxDGR: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EmqDxDGR",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zwnCZMDD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  xhJlmGvk: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "xhJlmGvk",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_RsPuQjtg: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  KNRgVMea: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "KNRgVMea",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_agcNuFHw: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ppVLUeiB: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ppVLUeiB",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_GLYyuhlr: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ppVLUeiB: [
                    { path: "saveValV2", id: "ppVLUeiB", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  ozEHSGbl: { "currentRow.result.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_BNYdqkTr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  BUbFpJnW: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "BUbFpJnW",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_dKoDCyGg: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  Bjmtkniy: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "Bjmtkniy",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_JKasRdYj: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EebcEYOw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EebcEYOw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_nRTuwGap: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  iogJtmJl: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "iogJtmJl",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_uxlHLDFf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uHjKbgQA: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "uHjKbgQA",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_KbwaKSUI: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ebAaPJNj: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ebAaPJNj",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_elHzRMwy: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  gRmFUtGc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "gRmFUtGc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_XruQbtSF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  XnePHvyr: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "XnePHvyr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_wLLthOAj: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  NCruiOnB: [
                    { path: "saveValV2", id: "NCruiOnB", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  COaIJNjL: { "currentRow.result.saveValV2": { paramKey: "$0" } }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_MIrEBtkh", type: "exp" },
                { id: "exp_AvBrXziJ", type: "exp" },
                { id: "exp_zwnCZMDD", type: "exp" },
                { id: "exp_RsPuQjtg", type: "exp" },
                { id: "exp_agcNuFHw", type: "exp" },
                { id: "exp_BNYdqkTr", type: "exp" },
                { id: "exp_dKoDCyGg", type: "exp" },
                { id: "exp_JKasRdYj", type: "exp" },
                { id: "exp_nRTuwGap", type: "exp" },
                { id: "exp_uxlHLDFf", type: "exp" },
                { id: "exp_KbwaKSUI", type: "exp" },
                { id: "exp_elHzRMwy", type: "exp" },
                { id: "exp_XruQbtSF", type: "exp" }
              ]
            },
            widget: {
              ozEHSGbl: {
                "currentRow.result.saveValV2": [
                  { id: "exp_GLYyuhlr", type: "exp" }
                ]
              },
              COaIJNjL: {
                "currentRow.result.saveValV2": [
                  { id: "exp_wLLthOAj", type: "exp" }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$WkMFjWwG`,
            key: `PC$$WkMFjWwG`,
            pageCtx,
            widgetRef: "TabContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$WkMFjWwG$$QtRppnay`,
              key: `PC$$WkMFjWwG$$QtRppnay`,
              pageCtx,
              widgetRef: "PureFlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl`,
                key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$RVeDrbwS`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$RVeDrbwS`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromozEHSGbl, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$CTriSVak`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$CTriSVak`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$CTriSVak$$ZnQoZeoe`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$CTriSVak$$ZnQoZeoe`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromozEHSGbl }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$EmqDxDGR`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$EmqDxDGR`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$xhJlmGvk`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$xhJlmGvk`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$KNRgVMea`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$KNRgVMea`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$ppVLUeiB`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$ppVLUeiB`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$BUbFpJnW`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$BUbFpJnW`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$Bjmtkniy`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$Bjmtkniy`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$EebcEYOw`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$EebcEYOw`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$iogJtmJl`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$%${indexFromozEHSGbl}%$$iogJtmJl`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ`,
                  key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$nHiqoiiU`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$nHiqoiiU`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$kvlPqMzj`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$kvlPqMzj`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$SZNSFQuF`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$SZNSFQuF`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$mNfdmKXh`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$ozEHSGbl$$fkbytLmQ$$mNfdmKXh`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                )
              )
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$WkMFjWwG$$UtqOSUVt`,
              key: `PC$$WkMFjWwG$$UtqOSUVt`,
              pageCtx,
              widgetRef: "PureFlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL`,
                key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$zHeGCCgL`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$zHeGCCgL`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromCOaIJNjL, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY$$xZnTZUOD`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY$$xZnTZUOD`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromCOaIJNjL }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$IgAfbBvy`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$IgAfbBvy`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$gRmFUtGc`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$gRmFUtGc`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$XnePHvyr`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$XnePHvyr`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$eSrteSpJ`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$eSrteSpJ`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$NCruiOnB`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$NCruiOnB`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$kGDVcEQy`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$kGDVcEQy`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$CNLdVDpO`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$CNLdVDpO`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$xUjrHKjn`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$xUjrHKjn`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$nmgHxqCP`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$nmgHxqCP`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx`,
                  key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$djejCYrQ`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$djejCYrQ`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$uHjKbgQA`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$uHjKbgQA`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$ebAaPJNj`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$ebAaPJNj`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$HsmJFgJA`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$HsmJFgJA`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$qGIpCZjd`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$qGIpCZjd`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1668504044102103040, "pageName", "\u5E94\u7528\u7EA7\u4EFB\u52A1\u4E2D\u5FC3");
  __publicField(Page1668504044102103040, "$pageKey", "yNYnFNtX");
  __publicField(Page1668504044102103040, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
