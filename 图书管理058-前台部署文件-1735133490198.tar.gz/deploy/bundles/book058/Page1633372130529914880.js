var Page1633372130529914880 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1633372130529914880: () => Page1633372130529914880
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1633372130529914880 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1633372130529914880",
            pageName: "\u5907\u4EFD\u8BB0\u5F55\u660E\u7EC6\u7BA1\u7406",
            apiMeta: {
              bis_api_1679813532322: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.lessee_code": {
                    title: "\u79DF\u6237\u7F16\u53F7",
                    __key: "lessee_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u7F16\u53F7",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.table_code": {
                    title: "\u5143\u6570\u636E\u8868\u7F16\u53F7",
                    __key: "table_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.orgin_code": {
                    title: "\u539F\u8868\u7F16\u53F7",
                    __key: "orgin_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.backup_code": {
                    title: "\u5907\u4EFD\u8868\u7F16\u53F7",
                    __key: "backup_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.file_path": {
                    title: "\u6587\u4EF6\u8DEF\u5F84",
                    __key: "file_path",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.group_code": {
                    title: "\u5907\u4EFD\u7F16\u53F7",
                    __key: "group_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.backup_table_name": {
                    title: "\u8868\u540D",
                    __key: "backup_table_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.backup_table_info": {
                    title: "\u5907\u4EFD\u8868\u4FE1\u606F",
                    __key: "backup_table_info",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.source_id": {
                    title: "\u6570\u636E\u6E90\u4E3B\u952E",
                    __key: "source_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._status_json": {
                    title: "\u72B6\u6001\u663E\u793A\u503C_json",
                    __key: "_status_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._status_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._status_json"
                  },
                  "__root.result.data._status_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._status_json"
                  },
                  "__root.result.data.job_code": {
                    title: "\u4EFB\u52A1\u6807\u8BC6",
                    __key: "job_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.process": {
                    title: "\u8FDB\u5EA6",
                    __key: "process",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.backup_field_codes": {
                    title: "\u5907\u4EFD\u5B57\u6BB5\u7F16\u53F7",
                    __key: "backup_field_codes",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._statusname": {
                    title: "\u72B6\u6001\u663E\u793A\u503C",
                    __key: "_statusname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root.backupCode": {
                    title: "\u5907\u4EFD\u7F16\u53F7",
                    __key: "backupCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  lessee_code: {
                    title: "\u79DF\u6237\u7F16\u53F7"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u7F16\u53F7"
                  },
                  table_code: {
                    title: "\u5143\u6570\u636E\u8868\u7F16\u53F7"
                  },
                  orgin_code: {
                    title: "\u539F\u8868\u7F16\u53F7"
                  },
                  backup_code: {
                    title: "\u5907\u4EFD\u8868\u7F16\u53F7"
                  },
                  file_path: {
                    title: "\u6587\u4EF6\u8DEF\u5F84"
                  },
                  group_code: {
                    title: "\u5907\u4EFD\u7F16\u53F7"
                  },
                  backup_table_name: {
                    title: "\u8868\u540D"
                  },
                  backup_table_info: {
                    title: "\u5907\u4EFD\u8868\u4FE1\u606F"
                  },
                  source_id: {
                    title: "\u6570\u636E\u6E90\u4E3B\u952E"
                  },
                  status: {
                    title: "\u72B6\u6001"
                  },
                  job_code: {
                    title: "\u4EFB\u52A1\u6807\u8BC6"
                  },
                  process: {
                    title: "\u8FDB\u5EA6"
                  },
                  backup_field_codes: {
                    title: "\u5907\u4EFD\u5B57\u6BB5\u7F16\u53F7"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  _statusname: {
                    title: "\u72B6\u6001\u663E\u793A\u503C"
                  }
                }
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id",
              code: "var_pageInput_2_YqajeHVe"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, {
            var_pageInput_0_mode: "insert",
            var_pageInput_1_id: "",
            var_pageInput_2_YqajeHVe: "code"
          }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u5907\u4EFD\u8BB0\u5F55\u660E\u7EC6\u7BA1\u7406"
            },
            FHwKNuNU: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "FHwKNuNU",
              title: "",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              customSetSave: true,
              fullscreen: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [],
              widgetCode: "NormalTable$1",
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u539F\u8868\u7F16\u53F7",
                  columnName: "orgin_code",
                  widgetId: "hGDPzNuj"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u5907\u4EFD\u8868\u540D\u79F0",
                  columnName: "backup_table_name",
                  widgetId: "RWwodKyL"
                }
              ],
              columns: [
                {
                  dataIndex: "group_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "JWAQSpZC",
                  widgetRef: "FormInput",
                  title: "\u5907\u4EFD\u7F16\u53F7",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "table_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "QYipfphK",
                  widgetRef: "FormInput",
                  title: "\u5143\u6570\u636E\u8868\u7F16\u53F7",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "orgin_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "scInQndT",
                  widgetRef: "FormInput",
                  title: "\u539F\u8868\u7F16\u53F7",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "backup_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "foqZOdrI",
                  widgetRef: "FormInput",
                  title: "\u5907\u4EFD\u8868\u7F16\u53F7",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "backup_table_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "vXXlObYg",
                  widgetRef: "FormInput",
                  title: "\u5907\u4EFD\u8868\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "job_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "uOSRvUYC",
                  widgetRef: "FormInput",
                  title: "\u4EFB\u52A1\u7F16\u53F7",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "status",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "KqLgSFAv",
                  widgetRef: "DropdownSelector",
                  title: "\u6267\u884C\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              tagKey: "",
              keyshow: false,
              ds: "bis_api_1679813532322",
              rowKey: "id",
              socket: null,
              customParams: [{ field: "__root.backupCode" }],
              tableSortFieldList: [
                "lessee_code",
                "app_code",
                "table_code",
                "orgin_code",
                "backup_code",
                "file_path",
                "group_code",
                "backup_table_name",
                "backup_table_info",
                "source_id",
                "status",
                "job_code",
                "process",
                "backup_field_codes",
                "id",
                "create_user_id",
                "create_user_name",
                "create_time",
                "last_update_user_id",
                "last_update_user_name",
                "last_update_time",
                "sequence",
                "_statusname"
              ],
              relatedAppPage: null
            },
            nhjMpEkg: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "nhjMpEkg",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsProps: {
                hGDPzNuj: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                RWwodKyL: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: ["hGDPzNuj", "RWwodKyL"],
              bodyInfo: [
                { id: "hGDPzNuj", visible: true, widgetRef: "FormInput" },
                { id: "RWwodKyL", visible: true, widgetRef: "FormInput" }
              ]
            },
            hGDPzNuj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "hGDPzNuj",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u539F\u8868\u7F16\u53F7",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              fieldSearch: { field: "orgin_code", title: "\u539F\u8868\u7F16\u53F7" },
              field: "orgin_code",
              searchMethod: "like",
              widgetCode: "FormInput$44",
              columnName: "orgin_code"
            },
            RWwodKyL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "RWwodKyL",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u5907\u4EFD\u8868\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              fieldSearch: { field: "backup_table_name", title: "\u8868\u540D" },
              field: "backup_table_name",
              searchMethod: "like",
              widgetCode: "FormInput$45",
              columnName: "backup_table_name"
            },
            dsGfunXd: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "dsGfunXd",
              visible: true,
              customId: "FHwKNuNU_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            xlFqZZrF: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "xlFqZZrF",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "FHwKNuNU_inlineBtns",
              btnsConfig: [],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            JWAQSpZC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "JWAQSpZC",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$38",
              field: "group_code",
              fieldColumn: { field: "group_code", title: "\u5907\u4EFD\u7F16\u53F7" },
              $lazyload: false,
              columnName: "group_code"
            },
            QYipfphK: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "QYipfphK",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              widgetCode: "FormInput$39",
              field: "table_code",
              fieldColumn: { field: "table_code", title: "\u5143\u6570\u636E\u8868\u7F16\u53F7" },
              $lazyload: false,
              columnName: "table_code"
            },
            scInQndT: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "scInQndT",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              widgetCode: "FormInput$40",
              field: "orgin_code",
              fieldColumn: { field: "orgin_code", title: "\u539F\u8868\u7F16\u53F7" },
              $lazyload: false,
              columnName: "orgin_code"
            },
            foqZOdrI: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "foqZOdrI",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              widgetCode: "FormInput$41",
              field: "backup_code",
              fieldColumn: { field: "backup_code", title: "\u5907\u4EFD\u8868\u7F16\u53F7" },
              $lazyload: false,
              columnName: "backup_code"
            },
            vXXlObYg: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "vXXlObYg",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              widgetCode: "FormInput$42",
              field: "backup_table_name",
              fieldColumn: { field: "backup_table_name", title: "\u8868\u540D" },
              $lazyload: false,
              columnName: "backup_table_name"
            },
            uOSRvUYC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "uOSRvUYC",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 100,
              widgetCode: "FormInput$43",
              field: "job_code",
              fieldColumn: { field: "job_code", title: "\u4EFB\u52A1\u6807\u8BC6" },
              note: "ETL\u5DE5\u5177\uFF08datax\uFF09\u7684\u4EFB\u52A1\u7F16\u53F7\uFF0C\u591A\u4E2A\u4EFB\u52A1\u4F7F\u7528\u82F1\u6587\u9017\u53F7\u5206\u9694",
              $lazyload: false,
              columnName: "job_code"
            },
            KqLgSFAv: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "KqLgSFAv",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: { 0: "\u5931\u8D25", 1: "\u8FDB\u884C\u4E2D", 2: "\u6210\u529F" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1639156575119749120_1679640356756"
                }
              },
              dictMeta: {
                dictBusiCode: "1639156575119749120_1679640356756",
                type: "dict"
              },
              stringLength: 32,
              widgetCode: "DropdownSelector$1",
              field: "status",
              fieldColumn: { field: "status", title: "\u72B6\u6001" },
              $lazyload: false,
              bodyContainer: true,
              columnName: "status"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "FHwKNuNU",
                  children: [
                    {
                      id: "nhjMpEkg",
                      children: [
                        {
                          id: "hGDPzNuj",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        },
                        {
                          id: "RWwodKyL",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ]
                    },
                    {
                      id: "FHwKNuNU_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "dsGfunXd",
                          parentToChild: "1:1",
                          type: "node",
                          children: []
                        }
                      ]
                    },
                    {
                      id: "FHwKNuNU_inlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "xlFqZZrF",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    },
                    {
                      id: "FHwKNuNU_columns",
                      type: "renderProp",
                      children: [
                        {
                          id: "JWAQSpZC",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "QYipfphK",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "scInQndT",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "foqZOdrI",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "vXXlObYg",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "uOSRvUYC",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "KqLgSFAv",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {},
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_2_YqajeHVe: [
                {
                  id: "FHwKNuNU",
                  type: "widget",
                  path: "customParams.0.value",
                  action: "changeConditions"
                }
              ]
            },
            widget: {}
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$FHwKNuNU`,
            key: `PC$$FHwKNuNU`,
            pageCtx,
            widgetRef: "NormalTable",
            headerBtnsRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$dsGfunXd`,
                  key: `PC$$FHwKNuNU$$dsGfunXd`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                }
              )
            ],
            inlineBtnsRenderer: ({ index: indexFromFHwKNuNU, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$xlFqZZrF`,
                key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$xlFqZZrF`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              }
            )),
            columnsRenderer: ({ index: indexFromFHwKNuNU }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$JWAQSpZC`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$JWAQSpZC`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$QYipfphK`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$QYipfphK`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$scInQndT`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$scInQndT`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$foqZOdrI`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$foqZOdrI`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$vXXlObYg`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$vXXlObYg`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$uOSRvUYC`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$uOSRvUYC`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$KqLgSFAv`,
                  key: `PC$$FHwKNuNU$$%${indexFromFHwKNuNU}%$$KqLgSFAv`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              )
            ]
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$FHwKNuNU$$nhjMpEkg`,
              key: `PC$$FHwKNuNU$$nhjMpEkg`,
              pageCtx,
              widgetRef: "GridLayoutSearch"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$FHwKNuNU$$nhjMpEkg$$hGDPzNuj`,
                key: `PC$$FHwKNuNU$$nhjMpEkg$$hGDPzNuj`,
                pageCtx,
                widgetRef: "FormInput"
              }
            ),
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$FHwKNuNU$$nhjMpEkg$$RWwodKyL`,
                key: `PC$$FHwKNuNU$$nhjMpEkg$$RWwodKyL`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          )
        )
      );
    }
  };
  __publicField(Page1633372130529914880, "pageName", "\u5907\u4EFD\u8BB0\u5F55\u660E\u7EC6\u7BA1\u7406");
  __publicField(Page1633372130529914880, "$pageKey", "SXYUKuCF");
  __publicField(Page1633372130529914880, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
