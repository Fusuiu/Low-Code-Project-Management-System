var Page1594325416447979520 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1594325416447979520: () => Page1594325416447979520
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1594325416447979520 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1594325416447979520",
            pageName: "\u9009\u62E9\u5F15\u7528\u9875\u9762\u5F39\u7A97",
            apiMeta: {},
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "#f1f1f1" },
              pageLog: true,
              title: "\u9009\u62E9\u5F15\u7528\u9875\u9762\u5F39\u7A97"
            },
            bcJYfkwl: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "bcJYfkwl",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [
                [
                  { span: "5", locked: false, id: "iOKoQnlD" },
                  { span: "19", locked: false, id: "zUykxHcZ" }
                ]
              ],
              style: { width: "100%", height: "100%" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1",
              title: "\u6805\u683C\u5E03\u5C401"
            },
            iOKoQnlD: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "iOKoQnlD",
              span: "5",
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                backgroundColor: "#ffffff",
                borderRadius: "5px",
                padding: "8px"
              },
              visible: true,
              widgetCode: "FlexLayout$1",
              locked: false
            },
            pCKvDXsl: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "listDisplay",
              reloadEvents: ["onTreeQuery"],
              id: "pCKvDXsl",
              titleWeight: 400,
              labelColor: "#272727",
              style: { height: "100%" },
              multiCheck: false,
              title: "\u9009\u62E9\u5E94\u7528",
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: false,
              expandLevel: "",
              defaultSelectedNode: false,
              selectedNodesPaths: "",
              required: false,
              requiredProps: { type: false },
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              buttonHover: true,
              readOnly: false,
              widgetCode: "Tree$1"
            },
            zUykxHcZ: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "zUykxHcZ",
              span: "19",
              title: "\u6805\u683C2",
              style: { height: "auto", margin: "0px 0px 0px 0px" },
              visible: true,
              widgetCode: "FlexLayout$1",
              locked: false
            },
            NGuCzDHo: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "NGuCzDHo",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [
                [
                  { span: "6", locked: false, id: "GVFxWpEV" },
                  { span: "18", locked: false, id: "jCzkmrGe" }
                ]
              ],
              style: {
                width: "100%",
                height: "100%",
                margin: "0px 0px 0px 10px",
                backgroundColor: "#f1f1f1",
                borderRadius: "5px"
              },
              visible: true,
              widgetCode: "FlexLayoutContainer$2",
              title: "\u6805\u683C\u5E03\u5C402"
            },
            GVFxWpEV: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "GVFxWpEV",
              span: "6",
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                backgroundColor: "#ffffff",
                padding: "8px",
                borderRadius: "5px"
              },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            VFjdinuY: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "listDisplay",
              reloadEvents: ["onTreeQuery"],
              id: "VFjdinuY",
              titleWeight: 400,
              labelColor: "#272727",
              style: { height: "100%" },
              multiCheck: false,
              title: "\u9009\u62E9\u6A21\u5757",
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: false,
              expandLevel: "",
              defaultSelectedNode: false,
              selectedNodesPaths: "",
              required: false,
              requiredProps: { type: false },
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              buttonHover: true,
              readOnly: false,
              widgetCode: "Tree$2"
            },
            jCzkmrGe: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "jCzkmrGe",
              span: "18",
              title: "\u6805\u683C2",
              style: { height: "auto", padding: "0px 0px 0px 10px" },
              visible: true,
              widgetCode: "FlexLayout$1",
              locked: false
            },
            aoVVdTOe: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "aoVVdTOe",
              title: "\u9009\u62E9\u9875\u9762",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              customSetSave: true,
              fullscreen: true,
              style: { height: "100%", padding: "0px 8px 8px 8px" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [],
              sortInfo: [],
              tagKey: "",
              keyshow: false,
              ds: null,
              rowKey: "",
              socket: null,
              tableSortFieldList: []
            },
            vLJQrnbY: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "vLJQrnbY",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            QVJiYmfT: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "QVJiYmfT",
              visible: true,
              customId: "aoVVdTOe_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            nKUiKNQG: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "nKUiKNQG",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "aoVVdTOe_inlineBtns",
              btnsConfig: [],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "bcJYfkwl",
                  children: [
                    {
                      id: "iOKoQnlD",
                      children: [
                        {
                          id: "pCKvDXsl",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "zUykxHcZ",
                      children: [
                        {
                          id: "NGuCzDHo",
                          children: [
                            {
                              id: "GVFxWpEV",
                              children: [
                                {
                                  id: "VFjdinuY",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "jCzkmrGe",
                              children: [
                                {
                                  id: "aoVVdTOe",
                                  children: [
                                    { id: "vLJQrnbY", children: [] },
                                    {
                                      id: "aoVVdTOe_headerBtns",
                                      type: "renderProp",
                                      children: [
                                        {
                                          id: "QVJiYmfT",
                                          parentToChild: "1:1",
                                          type: "node",
                                          children: []
                                        }
                                      ]
                                    },
                                    {
                                      id: "aoVVdTOe_inlineBtns",
                                      type: "renderProp",
                                      children: [
                                        {
                                          id: "nKUiKNQG",
                                          parentToChild: "1:n",
                                          type: "node",
                                          children: []
                                        }
                                      ]
                                    },
                                    {
                                      id: "aoVVdTOe_columns",
                                      type: "renderProp",
                                      children: []
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_XIATcjZm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  pCKvDXsl: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "pCKvDXsl",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_uCzuuIxc: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VFjdinuY: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "VFjdinuY",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_XIATcjZm", type: "exp" },
                { id: "exp_uCzuuIxc", type: "exp" }
              ]
            },
            widget: {}
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$bcJYfkwl`,
            key: `PC$$bcJYfkwl`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$bcJYfkwl$$iOKoQnlD`,
              key: `PC$$bcJYfkwl$$iOKoQnlD`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$bcJYfkwl$$iOKoQnlD$$pCKvDXsl`,
                key: `PC$$bcJYfkwl$$iOKoQnlD$$pCKvDXsl`,
                pageCtx,
                widgetRef: "Tree"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$bcJYfkwl$$zUykxHcZ`,
              key: `PC$$bcJYfkwl$$zUykxHcZ`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo`,
                key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo`,
                pageCtx,
                widgetRef: "FlexLayoutContainer"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$GVFxWpEV`,
                  key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$GVFxWpEV`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$GVFxWpEV$$VFjdinuY`,
                    key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$GVFxWpEV$$VFjdinuY`,
                    pageCtx,
                    widgetRef: "Tree"
                  }
                )
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe`,
                  key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe`,
                    key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe`,
                    pageCtx,
                    widgetRef: "NormalTable",
                    headerBtnsRenderer: () => [
                      /* @__PURE__ */ react_default.createElement(
                        COMPCONTROL.CompEntry,
                        {
                          path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$QVJiYmfT`,
                          key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$QVJiYmfT`,
                          pageCtx,
                          widgetRef: "FormButtonGroup"
                        }
                      )
                    ],
                    inlineBtnsRenderer: ({
                      index: indexFromaoVVdTOe,
                      record
                    }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$%${indexFromaoVVdTOe}%$$nKUiKNQG`,
                        key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$%${indexFromaoVVdTOe}%$$nKUiKNQG`,
                        pageCtx,
                        widgetRef: "FormButtonGroup"
                      }
                    )),
                    columnsRenderer: ({ index: indexFromaoVVdTOe }) => []
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$vLJQrnbY`,
                      key: `PC$$bcJYfkwl$$zUykxHcZ$$NGuCzDHo$$jCzkmrGe$$aoVVdTOe$$vLJQrnbY`,
                      pageCtx,
                      widgetRef: "GridLayoutSearch"
                    }
                  )
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1594325416447979520, "pageName", "\u9009\u62E9\u5F15\u7528\u9875\u9762\u5F39\u7A97");
  __publicField(Page1594325416447979520, "$pageKey", "fYJbVmZJ");
  __publicField(Page1594325416447979520, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
