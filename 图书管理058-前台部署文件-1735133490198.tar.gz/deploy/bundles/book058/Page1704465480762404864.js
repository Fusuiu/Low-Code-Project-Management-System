var Page1704465480762404864 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1704465480762404864: () => Page1704465480762404864
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1704465480762404864 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1704465480762404864",
            pageName: "\u6570\u636E\u5B57\u5178",
            apiMeta: {
              "1704463581262786560_list_1695211191714": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.dict_code": {
                    title: "\u5B57\u5178\u5B9E\u9645\u503C",
                    __key: "dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.bl_dict_code": {
                    title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C",
                    __key: "bl_dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_father_dict": {
                    title: "\u662F\u5426\u5B57\u5178\u9879",
                    __key: "is_father_dict",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_father_dict_json": {
                    title: "\u662F\u5426\u5B57\u5178\u9879\u663E\u793A\u503C_json",
                    __key: "_is_father_dict_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_father_dict_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_father_dict_json"
                  },
                  "__root.result.data._is_father_dict_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_father_dict_json"
                  },
                  "__root.result.data.dict_not": {
                    title: "\u5907\u6CE8",
                    __key: "dict_not",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.state": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001",
                    __key: "state",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._state_json": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001\u663E\u793A\u503C_json",
                    __key: "_state_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._state_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._state_json"
                  },
                  "__root.result.data._state_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._state_json"
                  },
                  "__root.result.data.path": {
                    title: "\u8DEF\u5F84",
                    __key: "path",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.name": {
                    title: "\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.level": {
                    title: "\u5C42\u7EA7",
                    __key: "level",
                    _remoteType: "string_number",
                    _type: "number",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pid": {
                    title: "\u7236\u8282\u70B9",
                    __key: "pid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._pid_json": {
                    title: "\u7236\u8282\u70B9\u663E\u793A\u503C_json",
                    __key: "_pid_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._pid_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._pid_json"
                  },
                  "__root.result.data._pid_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._pid_json"
                  },
                  "__root.result.data._statename": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001\u663E\u793A\u503C",
                    __key: "_statename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_father_dictname": {
                    title: "\u662F\u5426\u5B57\u5178\u9879\u663E\u793A\u503C",
                    __key: "_is_father_dictname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  dict_code: {
                    title: "\u5B57\u5178\u5B9E\u9645\u503C"
                  },
                  bl_dict_code: {
                    title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C"
                  },
                  is_father_dict: {
                    title: "\u662F\u5426\u5B57\u5178\u9879"
                  },
                  dict_not: {
                    title: "\u5907\u6CE8"
                  },
                  state: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001"
                  },
                  path: {
                    title: "\u8DEF\u5F84"
                  },
                  name: {
                    title: "\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  level: {
                    title: "\u5C42\u7EA7"
                  },
                  pid: {
                    title: "\u7236\u8282\u70B9"
                  },
                  _statename: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001\u663E\u793A\u503C"
                  },
                  _is_father_dictname: {
                    title: "\u662F\u5426\u5B57\u5178\u9879\u663E\u793A\u503C"
                  }
                }
              },
              bis_api_1695283406421: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E\u96C6\u5408",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1704463581262786560_del_1695211191249": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E\u96C6\u5408",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1704463581262786560_import_1695276650310": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.fileContent": {
                    title: "\u6587\u4EF6\u4FE1\u606F",
                    __key: "fileContent",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1704463581262786560_download_1695276681703": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {},
                cond: {}
              },
              "1704463581262786560_export_1695286011642": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root.fileContent": {
                    title: "\u6587\u4EF6\u4FE1\u606F",
                    __key: "fileContent",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {
                  dict_code: {
                    title: "\u5B57\u5178\u5B9E\u9645\u503C"
                  },
                  bl_dict_code: {
                    title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C"
                  },
                  is_father_dict: {
                    title: "\u662F\u5426\u5B57\u5178\u9879"
                  },
                  dict_not: {
                    title: "\u5907\u6CE8"
                  },
                  state: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001"
                  },
                  path: {
                    title: "\u8DEF\u5F84"
                  },
                  name: {
                    title: "\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  level: {
                    title: "\u5C42\u7EA7"
                  },
                  pid: {
                    title: "\u7236\u8282\u70B9"
                  },
                  _statename: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001\u663E\u793A\u503C"
                  },
                  _is_father_dictname: {
                    title: "\u662F\u5426\u5B57\u5178\u9879\u663E\u793A\u503C"
                  }
                }
              },
              "1704463581262786560_update_1695211191017": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.data": {
                    title: "\u8868\u6570\u636E",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.data.dict_code": {
                    title: "\u5B57\u5178\u5B9E\u9645\u503C",
                    __key: "dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.bl_dict_code": {
                    title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C",
                    __key: "bl_dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_father_dict": {
                    title: "\u662F\u5426\u5B57\u5178\u9879",
                    __key: "is_father_dict",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.dict_not": {
                    title: "\u5907\u6CE8",
                    __key: "dict_not",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.state": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001",
                    __key: "state",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.name": {
                    title: "\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.pid": {
                    title: "\u7236\u8282\u70B9",
                    __key: "pid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data._statename": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001\u663E\u793A\u503C",
                    __key: "_statename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data._is_father_dictname": {
                    title: "\u662F\u5426\u5B57\u5178\u9879\u663E\u793A\u503C",
                    __key: "_is_father_dictname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1695275445488: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1695275699494: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u6570\u636E\u5B57\u5178"
            },
            vwsJyAAq: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "vwsJyAAq",
              title: "\u6805\u683C\u5E03\u5C40",
              hGutter: 0,
              vGutter: 0,
              gridByLine: [
                [
                  { span: "6", locked: false, id: "UiLHhmMS" },
                  { span: "18", locked: false, id: "QzfwDXsa" }
                ]
              ],
              style: { width: "100%", height: "100%" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1"
            },
            UiLHhmMS: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "UiLHhmMS",
              span: "6",
              title: "\u6805\u683C1",
              style: { height: "auto" },
              visible: true,
              locked: false
            },
            EBDFHALE: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "listDisplay",
              reloadEvents: ["onTreeQuery"],
              id: "EBDFHALE",
              titleWeight: 400,
              labelColor: "#272727",
              style: { height: "auto" },
              multiCheck: false,
              title: "\u5B57\u5178\u9879",
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u7CFB\u7EDF\u5B57\u5178",
              defaultExpand: true,
              expandLevel: 2,
              defaultSelectedNode: false,
              selectedNodesPaths: "",
              required: false,
              requiredProps: { type: false },
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              treeNodeIconBtns: [
                {
                  title: "",
                  type: "custom",
                  groupId: "oQkWdgza",
                  widgetId: "ohuwbKWM"
                },
                {
                  title: "",
                  type: "delete",
                  groupId: "oQkWdgza",
                  widgetId: "WsRsoMDg"
                }
              ],
              buttonHover: true,
              draggable: false,
              readOnly: false,
              widgetCode: "Tree$1",
              sortInfo: [],
              conditions: [
                {
                  varAlias: 1,
                  field: "is_father_dict",
                  paramAmount: 1,
                  method: "equ",
                  value: ["1"]
                }
              ],
              formula: "1",
              tTitleKey: "name",
              tPIdKey: "pid",
              tIdKey: "id",
              ds: "1704463581262786560_list_1695211191714",
              btnsGroups: [
                { title: "\u66F4\u591A", id: "oQkWdgza", type: "treeHeaderIconBtns" },
                { title: "\u66F4\u591A", id: "rIJkbydP", type: "treeNodeIconBtns" }
              ],
              treeHeaderIconBtns: [
                { title: "\u65B0\u589E", type: "custom", widgetId: "RjqDlhzx" },
                {
                  title: "\u5C55\u5F00/\u6536\u7F29",
                  type: "expandCollapse",
                  widgetId: "HswUbyzs",
                  icons: [
                    { label: "\u5C55\u5F00", iconType: "FiMaximize2" },
                    { label: "\u6536\u7F29", iconType: "FiMinimize2" }
                  ]
                },
                { title: "\u5237\u65B0", type: "refresh", widgetId: "jEtnuDXr" }
              ],
              asyncType: "1",
              isAsync: true,
              tPathKey: "path",
              tLevelKey: "level",
              nodeExpandNum: 1,
              chidrenNodesApi: "",
              chidrenNodesParam: [],
              searchNodesApi: "",
              searchNodesParam: [],
              parentsAndBothersNodesApi: "",
              parentsAndBothersNodesParam: [],
              selectedNodes: [],
              leafPrefix: null,
              leafIconPrefix: "FiFileText",
              parentPrefix: null,
              parentIconPrefix: "FiLayers"
            },
            oQkWdgza: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "oQkWdgza",
              title: "\u8282\u70B9\u6309\u94AE\u56FE\u6807",
              visible: true,
              customId: "EBDFHALE_treeNodeIconBtns",
              btnsConfig: [
                {
                  title: "",
                  type: "custom",
                  groupId: "oQkWdgza",
                  widgetId: "ohuwbKWM"
                },
                {
                  title: "",
                  type: "delete",
                  groupId: "oQkWdgza",
                  widgetId: "WsRsoMDg"
                }
              ],
              style: { margin: "0", padding: "0" },
              size: "small"
            },
            ohuwbKWM: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "ohuwbKWM",
              iconType: "FiEdit",
              title: "",
              visible: true,
              disabled: false,
              style: { padding: "2px", marginRight: "6px" },
              fontStyle: { fontWeight: 400 },
              support: true,
              hoverTitle: "\u81EA\u5B9A\u4E491",
              size: "small",
              type: "link",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false
            },
            WsRsoMDg: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "WsRsoMDg",
              iconType: "FiTrash2",
              title: "",
              visible: true,
              disabled: false,
              style: { padding: "2px", color: "#f85e5e", marginRight: "6px" },
              fontStyle: { fontWeight: 400 },
              support: true,
              hoverTitle: "\u5220\u9664",
              size: "small",
              type: "link",
              widgetCode: "FormButton$1",
              $lazyload: false
            },
            RjqDlhzx: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "RjqDlhzx",
              iconType: "FiPlusCircle",
              title: "\u65B0\u589E",
              visible: true,
              disabled: false,
              style: {
                padding: "4px 15px 4px 15px",
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              },
              fontStyle: { fontWeight: 400 },
              support: true,
              hoverTitle: "\u81EA\u5B9A\u4E491",
              size: "small",
              type: "link",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false
            },
            HswUbyzs: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "HswUbyzs",
              title: "\u6536\u7F29",
              visible: true,
              disabled: false,
              iconType: "FiMinimize2",
              style: {
                padding: "4px 15px 4px 15px",
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              },
              fontStyle: { fontWeight: 400 },
              support: true,
              hoverTitle: "\u5C55\u5F00/\u6536\u7F29",
              size: "small",
              type: "link",
              $lazyload: false
            },
            jEtnuDXr: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "jEtnuDXr",
              title: "\u5237\u65B0",
              visible: true,
              disabled: false,
              iconType: "FiRotateCw",
              style: {
                padding: "4px 15px 4px 15px",
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              },
              fontStyle: { fontWeight: 400 },
              support: true,
              hoverTitle: "\u5237\u65B0",
              size: "small",
              type: "link",
              $lazyload: false
            },
            QzfwDXsa: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "QzfwDXsa",
              span: "18",
              title: "\u6805\u683C2",
              style: { height: "auto" },
              visible: true,
              locked: false,
              widgetCode: "FlexLayout$1"
            },
            nEdFDjrQ: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "nEdFDjrQ",
              title: "\u5B57\u5178\u6570\u636E",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              customSetSave: true,
              fullscreen: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              btnsGroups: [
                { title: "\u66F4\u591A", id: "CVGTmqUS", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "RtUDgpQc", type: "inlineBtns" }
              ],
              headerBtns: [
                { title: "\u65B0\u589E", btnType: "create" },
                { title: "\u5BFC\u5165", btnType: "import" },
                { title: "\u5BFC\u51FA", btnType: "export" }
              ],
              headerBtnsConfig: [
                { title: "\u65B0\u589E", widgetId: "wPHheaIt" },
                { title: "\u5BFC\u5165", amIFold: false, widgetId: "cKxVmQhQ" },
                { title: "\u5BFC\u51FA", widgetId: "ZOAmsFii" }
              ],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "KYslhkPN",
                  show: "visible",
                  type: "detail",
                  groupId: "RtUDgpQc"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "HgCrswBD",
                  show: "visible",
                  type: "update",
                  groupId: "RtUDgpQc",
                  pageType: "curPage"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "tXlUloan",
                  show: "visible",
                  type: "delete",
                  groupId: "RtUDgpQc",
                  pageType: "curPage"
                },
                {
                  title: "\u542F\u7528",
                  widgetId: "soYnivsb",
                  show: "exp",
                  type: "custom_dYsaSsPD",
                  groupId: "RtUDgpQc"
                },
                {
                  title: "\u7981\u7528",
                  widgetId: "ADxDLpyv",
                  show: "exp",
                  type: "custom_RjDLepzQ",
                  groupId: "RtUDgpQc"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "PKnDuSCH",
                  widgetRef: "FormInput",
                  title: "\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "dict_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "xefDbXnD",
                  widgetRef: "FormInput",
                  title: "\u5B57\u5178\u5B9E\u9645\u503C",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "is_father_dict",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "buDhjZck",
                  widgetRef: "DropdownSelector",
                  title: "\u662F\u5426\u5B57\u5178\u9879",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "pid",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "JwcCaiue",
                  widgetRef: "FormInput",
                  title: "\u6240\u5C5E\u5B57\u5178\u9879",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "bl_dict_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "VcrPDmUq",
                  widgetRef: "FormInput",
                  title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "dict_not",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "zsuVvLbu",
                  widgetRef: "FormInput",
                  title: "\u5907\u6CE8",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "state",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  fixed: "right",
                  widgetId: "lIBtKKsm",
                  widgetRef: "DropdownSelector",
                  title: "\u542F\u7528\u7981\u7528\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" },
                { fieldID: "id", title: "\u4E3B\u952E", sort: "asc" }
              ],
              conditions: [
                { varAlias: 1, field: "pid", paramAmount: 1, method: "equ" }
              ],
              formula: "1 ",
              tagKey: "",
              keyshow: false,
              ds: "1704463581262786560_list_1695211191714",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "dict_code",
                "bl_dict_code",
                "is_father_dict",
                "dict_not",
                "state",
                "path",
                "name",
                "id",
                "create_user_id",
                "create_user_name",
                "create_time",
                "last_update_user_id",
                "last_update_user_name",
                "last_update_time",
                "sequence",
                "level",
                "pid",
                "_statename",
                "_is_father_dictname"
              ],
              relatedAppPage: {
                pageNameCn: "\u6570\u636E\u5B57\u5178\u8868\u5355",
                pageId: "1704465780734832640"
              }
            },
            GRPipFSa: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "GRPipFSa",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            CVGTmqUS: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "CVGTmqUS",
              visible: true,
              customId: "nEdFDjrQ_headerBtns",
              btnsConfig: [
                { title: "\u65B0\u589E", widgetId: "wPHheaIt" },
                { title: "\u5BFC\u5165", amIFold: false, widgetId: "cKxVmQhQ" },
                { title: "\u5BFC\u51FA", widgetId: "ZOAmsFii" }
              ],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            wPHheaIt: {
              title: "\u65B0\u589E",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "wPHheaIt",
              visible: false,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              fontStyle: { fontWeight: 400 },
              size: "middle",
              widgetCode: "FormButton$1",
              type: "primary"
            },
            cKxVmQhQ: {
              title: "\u5BFC\u5165",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "cKxVmQhQ",
              visible: false,
              isDataWidget: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              fontStyle: { fontWeight: 400 },
              size: "middle",
              widgetCode: "FormButton$1",
              type: "default"
            },
            ZOAmsFii: {
              title: "\u5BFC\u51FA",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "ZOAmsFii",
              visible: false,
              isDataWidget: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              fontStyle: { fontWeight: 400 },
              size: "middle",
              widgetCode: "FormButton$1",
              type: "default",
              eventTypesWithTags: [
                { eventType: "onClick", tagType: "expandMenu" }
              ]
            },
            RtUDgpQc: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "RtUDgpQc",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "nEdFDjrQ_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "KYslhkPN",
                  show: "visible",
                  type: "detail",
                  groupId: "RtUDgpQc"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "HgCrswBD",
                  show: "visible",
                  type: "update",
                  groupId: "RtUDgpQc",
                  pageType: "curPage"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "tXlUloan",
                  show: "visible",
                  type: "delete",
                  groupId: "RtUDgpQc",
                  pageType: "curPage"
                },
                {
                  title: "\u542F\u7528",
                  widgetId: "soYnivsb",
                  show: "exp",
                  type: "custom_dYsaSsPD",
                  groupId: "RtUDgpQc"
                },
                {
                  title: "\u7981\u7528",
                  widgetId: "ADxDLpyv",
                  show: "exp",
                  type: "custom_RjDLepzQ",
                  groupId: "RtUDgpQc"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            KYslhkPN: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "KYslhkPN",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            HgCrswBD: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "HgCrswBD",
              title: "\u4FEE\u6539",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            tXlUloan: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "tXlUloan",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            soYnivsb: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "soYnivsb",
              title: "\u542F\u7528",
              visible: false,
              disabled: false,
              iconType: "FiCheckCircle",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            ADxDLpyv: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "ADxDLpyv",
              title: "\u7981\u7528",
              visible: false,
              disabled: false,
              iconType: "FiXCircle",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            PKnDuSCH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "PKnDuSCH",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$1",
              field: "name",
              fieldColumn: { field: "name", title: "\u540D\u79F0" },
              $lazyload: false,
              columnName: "name"
            },
            xefDbXnD: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "xefDbXnD",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$2",
              field: "dict_code",
              fieldColumn: { field: "dict_code", title: "\u5B57\u5178\u5B9E\u9645\u503C" },
              $lazyload: false,
              columnName: "dict_code"
            },
            buDhjZck: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "buDhjZck",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: { 0: "\u9009\u98790" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1576103853051490304_1664607415889"
                }
              },
              dictMeta: {
                dictBusiCode: "1576103853051490304_1664607415889",
                type: "dict"
              },
              stringLength: 32,
              widgetCode: "DropdownSelector$1",
              field: "is_father_dict",
              fieldColumn: { field: "is_father_dict", title: "\u662F\u5426\u5B57\u5178\u9879" },
              $lazyload: false,
              bodyContainer: true,
              columnName: "is_father_dict"
            },
            JwcCaiue: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "JwcCaiue",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 20,
              widgetCode: "FormInput$3",
              field: "pid",
              fieldColumn: { field: "pid", title: "\u7236\u8282\u70B9" },
              $lazyload: false,
              columnName: "pid"
            },
            VcrPDmUq: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "VcrPDmUq",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$4",
              field: "bl_dict_code",
              fieldColumn: { field: "bl_dict_code", title: "\u6240\u5C5E\u5B57\u5178\u9879\u5B9E\u9645\u503C" },
              $lazyload: false,
              columnName: "bl_dict_code"
            },
            zsuVvLbu: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "zsuVvLbu",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$5",
              field: "dict_not",
              fieldColumn: { field: "dict_not", title: "\u5907\u6CE8" },
              $lazyload: false,
              columnName: "dict_not"
            },
            lIBtKKsm: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "lIBtKKsm",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: { 0: "\u7981\u7528", 1: "\u542F\u7528" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1704438867106607104_1695204867603"
                }
              },
              dictMeta: {
                dictBusiCode: "1704438867106607104_1695204867603",
                type: "dict"
              },
              stringLength: 32,
              widgetCode: "DropdownSelector$2",
              field: "state",
              fieldColumn: { field: "state", title: "\u542F\u7528\u7981\u7528\u72B6\u6001" },
              $lazyload: false,
              bodyContainer: true,
              columnName: "state"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            ohuwbKWM: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "EBDFHALE",
                                      path: ["selectedData", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704469457402998784",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "topLeft",
                                  adsorbOffset: {
                                    horizontal: "8px",
                                    vertical: "8px"
                                  },
                                  appType: "currentApp",
                                  popupMode: "slideModal",
                                  isMask: true,
                                  closePopup: false,
                                  slidePlacement: "right",
                                  mini: false,
                                  fullscreen: true,
                                  Drag: false,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: true,
                                  showTopBar: true,
                                  id: "pbGHcCpS",
                                  pageNameCn: "\u6570\u636E\u5B57\u5178\u8868\u53552\u5B57\u5178\u9879",
                                  params: [
                                    { var_pageInput_0_mode: "update" },
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "EBDFHALE",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "id"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.finishNClosePage) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              },
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "ohuwbKWM"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.cancelNClosePage) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u6570\u636E\u5B57\u5178\u8868\u53552\u5B57\u5178\u9879" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            WsRsoMDg: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "EBDFHALE",
                                      path: ["selectedData", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  selectRowCheckBool: true,
                                  askText: "\u786E\u5B9A\u5220\u9664\uFF1F"
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "bis_api_1695283406421",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "WsRsoMDg"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "EBDFHALE",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "EBDFHALE",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["selectedData", "id"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: {
                              objectBehavior: "\u5220\u9664[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F-\u6811\u8282\u70B9"
                            }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            RjqDlhzx: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704469457402998784",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "topLeft",
                                  adsorbOffset: {
                                    horizontal: "8px",
                                    vertical: "8px"
                                  },
                                  appType: "currentApp",
                                  popupMode: "slideModal",
                                  isMask: true,
                                  closePopup: false,
                                  slidePlacement: "right",
                                  mini: false,
                                  fullscreen: true,
                                  Drag: false,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: true,
                                  showTopBar: true,
                                  id: "NRzLAEXv",
                                  pageNameCn: "\u6570\u636E\u5B57\u5178\u8868\u53552\u5B57\u5178\u9879",
                                  params: [{ var_pageInput_0_mode: "insert" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.finishNClosePage) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              },
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "RjqDlhzx"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.cancelNClosePage) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u6570\u636E\u5B57\u5178\u8868\u53552\u5B57\u5178\u9879" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            wPHheaIt: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "EBDFHALE",
                                      path: ["selectedData", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {},
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "jNnTxpDD",
                                  pageNameCn: "\u65B0\u589E_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    { var_pageInput_0_mode: "insert" },
                                    {
                                      var_pageInput_3_KgltCYTB: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "EBDFHALE",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "id"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "wPHheaIt"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "EBDFHALE",
                                      path: ["selectedData", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {},
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "jNnTxpDD",
                                  pageNameCn: "\u65B0\u589E_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    { var_pageInput_0_mode: "insert" },
                                    {
                                      var_pageInput_3_KgltCYTB: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "EBDFHALE",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "id"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "wPHheaIt"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            ZOAmsFii: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.exportData) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "1704463581262786560_export_1695286011642",
                                  input: [],
                                  outputPath: "__root.result",
                                  searchConds: void 0,
                                  rangeConds: void 0,
                                  selectedColsCond: {
                                    id: "nEdFDjrQ",
                                    field: "id",
                                    method: "in"
                                  },
                                  apis: {
                                    exportApi: "1704463581262786560_export_1695286011642",
                                    exportDataTemplateApi: ""
                                  },
                                  inputParamsTemplate: [],
                                  outputParamsTemplate: [
                                    {
                                      field: "__root.result",
                                      alias: "fileContent"
                                    }
                                  ],
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.finishNClosePage) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5BFC\u51FA[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            cKxVmQhQ: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.importData) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  apis: {
                                    importDataApi: "1704463581262786560_import_1695276650310",
                                    importDataTemplateApi: "1704463581262786560_download_1695276681703"
                                  },
                                  inputParams: [
                                    {
                                      field: "__root.fileContent",
                                      alias: "fileContent"
                                    }
                                  ],
                                  inputParamsTemplate: [],
                                  outputParamsTemplate: [
                                    {
                                      field: "__root.result",
                                      alias: "fileContent"
                                    }
                                  ],
                                  importDataDialog: platform_ui_default.ImportDataDialog,
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "cKxVmQhQ"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5BFC\u5165[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            soYnivsb: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["currentRow", "id", "saveValV2"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "\u662F\u5426\u786E\u5B9A\u542F\u7528\uFF1F",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1695275445488",
                                  input: [
                                    {
                                      "__root.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "currentRow",
                                            "id",
                                            "saveValV2"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataReload) == null ? void 0 : _b.call(
                                _a2,
                                { sourceWidgetId: "soYnivsb" },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u66F4\u65B0[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F-\u542F\u7528" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            ADxDLpyv: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["currentRow", "id", "saveValV2"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "\u662F\u5426\u786E\u5B9A\u7981\u7528\uFF1F",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1695275699494",
                                  input: [
                                    {
                                      "__root.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "currentRow",
                                            "id",
                                            "saveValV2"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataReload) == null ? void 0 : _b.call(
                                _a2,
                                { sourceWidgetId: "ADxDLpyv" },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u66F4\u65B0[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F-\u7981\u7528" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            KYslhkPN: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "BWCQDIcc",
                                  pageNameCn: "\u67E5\u770B_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "BWCQDIcc",
                                  pageNameCn: "\u67E5\u770B_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            HgCrswBD: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "NmtREEUC",
                                  pageNameCn: "\u4FEE\u6539_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "HgCrswBD"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1704465780734832640",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "NmtREEUC",
                                  pageNameCn: "\u4FEE\u6539_\u6570\u636E\u5B57\u5178\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "nEdFDjrQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "HgCrswBD"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6570\u636E\u5B57\u5178\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            tXlUloan: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "nEdFDjrQ",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  selectRowCheckBool: true,
                                  askText: "\u786E\u5B9A\u5220\u9664\uFF1F"
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "1704463581262786560_del_1695211191249",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.widgetDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    void 0,
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "nEdFDjrQ",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "nEdFDjrQ",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["lastSelectedRowKey"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5220\u9664[\u6570\u636E\u5B57\u5178\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "vwsJyAAq",
                  children: [
                    {
                      id: "UiLHhmMS",
                      children: [
                        {
                          id: "EBDFHALE",
                          children: [
                            {
                              id: "EBDFHALE_treeNodeIconBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "oQkWdgza",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "ohuwbKWM",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "WsRsoMDg",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "EBDFHALE_treeHeaderIconBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "RjqDlhzx",
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "HswUbyzs",
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "jEtnuDXr",
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "QzfwDXsa",
                      children: [
                        {
                          id: "nEdFDjrQ",
                          children: [
                            { id: "GRPipFSa", children: [] },
                            {
                              id: "nEdFDjrQ_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "CVGTmqUS",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: [
                                    {
                                      id: "wPHheaIt",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "cKxVmQhQ",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "ZOAmsFii",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "nEdFDjrQ_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "RtUDgpQc",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "KYslhkPN",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "HgCrswBD",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "tXlUloan",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "soYnivsb",
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "ADxDLpyv",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "nEdFDjrQ_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "PKnDuSCH",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "xefDbXnD",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "buDhjZck",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "JwcCaiue",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "VcrPDmUq",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "zsuVvLbu",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "lIBtKKsm",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_nledUVCO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EBDFHALE: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EBDFHALE",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_LTdptkZD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) != "";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  wPHheaIt: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "wPHheaIt",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  EBDFHALE: { "checkedDatas.dict_code": { paramKey: "$0" } }
                }
              }
            },
            exp_TivTLRyP: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == 0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  soYnivsb: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "soYnivsb",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  nEdFDjrQ: { "currentRow.state.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_oqxtTzwX: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == 1;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ADxDLpyv: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "ADxDLpyv",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  nEdFDjrQ: { "currentRow.state.saveValV2": { paramKey: "$0" } }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [{ id: "exp_nledUVCO", type: "exp" }]
            },
            widget: {
              EBDFHALE: {
                "checkedDatas.dict_code": [{ id: "exp_LTdptkZD", type: "exp" }],
                "selectedData.id": [
                  {
                    id: "nEdFDjrQ",
                    type: "widget",
                    path: "conditions.0.value",
                    action: "changeConditions"
                  }
                ]
              },
              nEdFDjrQ: {
                "currentRow.state.saveValV2": [
                  { id: "exp_TivTLRyP", type: "exp" },
                  { id: "exp_oqxtTzwX", type: "exp" }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$vwsJyAAq`,
            key: `PC$$vwsJyAAq`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$vwsJyAAq$$UiLHhmMS`,
              key: `PC$$vwsJyAAq$$UiLHhmMS`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE`,
                key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE`,
                pageCtx,
                widgetRef: "Tree",
                treeNodeIconBtnsRenderer: ({ index: indexFromEBDFHALE }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza`,
                    key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza$$ohuwbKWM`,
                      key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza$$ohuwbKWM`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza$$WsRsoMDg`,
                      key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$%${indexFromEBDFHALE}%$$oQkWdgza$$WsRsoMDg`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                treeHeaderIconBtnsRenderer: (props) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$RjqDlhzx`,
                      key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$RjqDlhzx`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$HswUbyzs`,
                      key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$HswUbyzs`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$jEtnuDXr`,
                      key: `PC$$vwsJyAAq$$UiLHhmMS$$EBDFHALE$$jEtnuDXr`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                ]
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$vwsJyAAq$$QzfwDXsa`,
              key: `PC$$vwsJyAAq$$QzfwDXsa`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ`,
                key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$wPHheaIt`,
                        key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$wPHheaIt`,
                        pageCtx,
                        widgetRef: "FormButton"
                      }
                    ),
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$cKxVmQhQ`,
                        key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$cKxVmQhQ`,
                        pageCtx,
                        widgetRef: "FormButton"
                      }
                    ),
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$ZOAmsFii`,
                        key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$CVGTmqUS$$ZOAmsFii`,
                        pageCtx,
                        widgetRef: "FormButton"
                      }
                    )
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromnEdFDjrQ, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc`,
                    key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$KYslhkPN`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$KYslhkPN`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$HgCrswBD`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$HgCrswBD`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$tXlUloan`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$tXlUloan`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$soYnivsb`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$soYnivsb`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$ADxDLpyv`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$RtUDgpQc$$ADxDLpyv`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromnEdFDjrQ }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$PKnDuSCH`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$PKnDuSCH`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$xefDbXnD`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$xefDbXnD`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$buDhjZck`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$buDhjZck`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$JwcCaiue`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$JwcCaiue`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$VcrPDmUq`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$VcrPDmUq`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$zsuVvLbu`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$zsuVvLbu`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$lIBtKKsm`,
                      key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$%${indexFromnEdFDjrQ}%$$lIBtKKsm`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$GRPipFSa`,
                  key: `PC$$vwsJyAAq$$QzfwDXsa$$nEdFDjrQ$$GRPipFSa`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                }
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1704465480762404864, "pageName", "\u6570\u636E\u5B57\u5178");
  __publicField(Page1704465480762404864, "$pageKey", "grAeblKo");
  __publicField(Page1704465480762404864, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
