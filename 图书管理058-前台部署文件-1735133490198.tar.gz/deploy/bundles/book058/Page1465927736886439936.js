var Page1465927736886439936 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1465927736886439936: () => Page1465927736886439936
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1465927736886439936 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1465927736886439936",
            pageName: "\u65B0\u589E\u7CFB\u7EDF\u516C\u544A",
            apiMeta: {
              bis_api_1638424729922: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u6570\u636E\u96C6",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.content": {
                    title: "\u6D88\u606F\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.read_num": {
                    title: "\u5DF2\u8BFB\u6570\u91CF",
                    __key: "read_num",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.msg_instance_id": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "msg_instance_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_type": {
                    title: "\u63A8\u9001\u65B9\u5F0F",
                    __key: "push_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._push_type_json": {
                    title: "\u63A8\u9001\u65B9\u5F0F\u663E\u793A\u503C",
                    __key: "_push_type_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_status": {
                    title: "\u63A8\u9001\u72B6\u6001",
                    __key: "push_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_time": {
                    title: "\u63A8\u9001\u65F6\u95F4",
                    __key: "push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.time_push": {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
                    __key: "time_push",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.on_time_push_time": {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
                    __key: "on_time_push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_id": {
                    title: "\u5B9A\u65F6\u4EFB\u52A1\u4E3B\u952E",
                    __key: "task_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_json": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C",
                    __key: "_priority_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._push_typename": {
                    title: "\u63A8\u9001\u65B9\u5F0F\u663E\u793A\u503C",
                    __key: "_push_typename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priorityname": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C",
                    __key: "_priorityname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sys_notice_user": {
                    title: "\u9644\u5C5E\u8868_sys_notice_user",
                    __key: "sys_notice_user",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sys_notice_user.is_read": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB",
                    __key: "is_read",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._is_read_json": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C",
                    __key: "_is_read_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.fid": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u5916\u952E",
                    __key: "fid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._fid_json": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u5916\u952E\u663E\u793A\u503C",
                    __key: "_fid_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_time": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.sequence": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_time": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_user_name": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.data_version": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6570\u636E\u7248\u672C",
                    __key: "data_version",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_user_name": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._is_readname": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C",
                    __key: "_is_readname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              },
              bis_api_1636427290219: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root.time_push": {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
                    __key: "time_push",
                    _remoteType: "string_number",
                    _type: "number",
                    __parent: "__root"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.on_time_push_time": {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
                    __key: "on_time_push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root"
                  },
                  "__root.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.content": {
                    title: "\u6D88\u606F\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.push_type": {
                    title: "\u63A8\u9001\u65B9\u5F0F",
                    __key: "push_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.sys_notice_user": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868",
                    __key: "sys_notice_user",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root.sys_notice_user.user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.sys_notice_user"
                  },
                  "__root.sys_notice_user._type": {
                    title: "\u6279\u91CF\u64CD\u4F5C\u7C7B\u578B",
                    __key: "_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.sys_notice_user"
                  }
                },
                cond: {}
              },
              bis_api_1636027925113: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root.time_push": {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
                    __key: "time_push",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.on_time_push_time": {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
                    __key: "on_time_push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root"
                  },
                  "__root.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.content": {
                    title: "\u6D88\u606F\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.push_type": {
                    title: "\u63A8\u9001\u65B9\u5F0F",
                    __key: "push_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.sys_notice_user": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868",
                    __key: "sys_notice_user",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root.sys_notice_user.user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.sys_notice_user"
                  },
                  "__root.sys_notice_user._type": {
                    title: "\u6279\u91CF\u64CD\u4F5C\u7C7B\u578B",
                    __key: "_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.sys_notice_user"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              title: "\u65B0\u589E\u7CFB\u7EDF\u516C\u544A",
              sockets: null,
              dss: ["bis_api_1638424729922"],
              requests: {
                bis_api_1638424729922: [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              },
              showBottomBar: true
            },
            yuGpoMrr: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "yuGpoMrr",
              title: "\u6807\u9898",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$1",
              field: "title",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.title"
              },
              readOnly: false,
              stringLength: 64
            },
            Ccflwxlx: {
              group: "formInput",
              parseInReadOnly: true,
              varMap: { saveValV2: { type: "string" }, text: { type: "string" } },
              widgetRef: "RichEditor",
              eventAttr: ["onChange", "onFocus", "onBlur"],
              id: "Ccflwxlx",
              title: "\u6D88\u606F\u5185\u5BB9",
              required: false,
              visible: true,
              height: 500,
              titleAlign: "left",
              style: {},
              readOnly: false,
              widgetCode: "RichEditor$2",
              field: "content",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.content"
              },
              fieldSearch: null
            },
            yBzqkVJy: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "yBzqkVJy",
              title: "\u4F18\u5148\u7EA7",
              options: { 1: "\u666E\u901A", 2: "\u7D27\u6025" },
              checkByExp: [],
              visible: true,
              required: true,
              titleAlign: "left",
              style: {},
              showValColor: "#1890ff",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1466220846950526976_1638409265977"
                }
              },
              dictMeta: {
                dictBusiCode: "1466220846950526976_1638409265977",
                type: "dict"
              },
              widgetCode: "DropdownSelector$1",
              field: "priority",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.priority"
              },
              readOnly: false,
              defRealVal: "1",
              linkage: null
            },
            LApCKeus: {
              varMap: {
                saveValV2: { type: "stringArray" },
                realValV2: { type: "string" }
              },
              widgetRef: "Checkbox",
              eventAttr: ["onChange", "onBlur", "onMouseEnter", "onMouseLeave"],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "LApCKeus",
              title: "\u63A8\u9001\u65B9\u5F0F",
              options: { 1: "\u7AD9\u5185\u63A8\u9001", 2: "\u9489\u9489", 3: "\u5FAE\u4FE1", 4: "\u90AE\u7BB1" },
              checkByExp: [],
              visible: true,
              titleAlign: "left",
              readOnly: false,
              required: true,
              style: {},
              widgetCode: "Checkbox$2",
              field: "push_type",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.push_type"
              },
              fieldSearch: null,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1460518685449007104_1637049764501"
                }
              },
              dictMeta: {
                dictBusiCode: "1460518685449007104_1637049764501",
                type: "dict"
              },
              defRealVal: ["1"],
              linkage: null
            },
            aSZGRSeX: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Radio",
              eventAttr: ["onChange", "onBlur", "onMouseEnter", "onMouseLeave"],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "aSZGRSeX",
              title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
              options: { 0: "\u5426", 1: "\u662F" },
              checkByExp: [],
              titleAlign: "left",
              visible: true,
              required: true,
              style: {},
              readOnly: false,
              widgetCode: "Radio$1",
              field: null,
              fieldInfo: null,
              fieldSearch: null,
              propOptions: {
                type: "custom",
                optionsConfig: [
                  { showVal: "\u662F", realVal: "1" },
                  { showVal: "\u5426", realVal: "0" }
                ]
              },
              linkage: null
            },
            SVHSRTdm: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "SVHSRTdm",
              title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001-\u6587\u672C",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$9",
              field: "time_push",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.time_push"
              },
              fieldSearch: null
            },
            EXbGiJFC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "EXbGiJFC",
              title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: false,
              style: {},
              readOnly: false,
              widgetCode: "FormDateTimePicker$1",
              field: "on_time_push_time",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.on_time_push_time"
              },
              fieldSearch: null
            },
            anupPCUa: {
              varMap: {
                dataVal: { type: "array" },
                actualVal: { type: "array" },
                colsVal: { type: "array" },
                displayVal: { type: "array" },
                curRow: { type: "object" },
                checkedRows: { type: "array" }
              },
              widgetRef: "SubformContainer",
              eventAttr: [
                "onRowAdd",
                "onRowDel",
                "onRowCopy",
                "onRowCopyEnd",
                "onRowInsertEnd",
                "onRowBatchDel",
                "onRowSort"
              ],
              isContainer: true,
              parseInReadOnly: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["NormalTable", "FormButton", "FormDivider"]
              },
              id: "anupPCUa",
              title: "\u901A\u77E5\u7528\u6237",
              titleAlign: "left",
              visible: false,
              rowDirection: "horizonal",
              style: { height: "auto" },
              readOnly: false,
              widgetCode: "SubformContainer$1",
              newBtn: { visible: true },
              field: null,
              fieldInfo: null,
              fieldSearch: null,
              headerBtns: [],
              headerBtnsConfig: [],
              note: "\u4FEE\u6539\u516C\u544A\u9700\u91CD\u65B0\u9009\u62E9\u901A\u77E5\u7528\u6237",
              inlineBtnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "hvSdMgqj",
                  btnType: "delete",
                  groupId: "yvDqvOtJ"
                }
              ],
              rowBtn: [],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "yvDqvOtJ", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "YVJfRWEH", type: "inlineBtns" }
              ],
              bodyHeaders: [
                {
                  title: "\u7528\u6237\u540D\u79F0",
                  id: "SmHansWu",
                  titleAlign: "left",
                  field: null
                },
                { title: "\u6587\u672C\u6846", id: "UTqzZklF", titleAlign: "left" }
              ],
              childMap: {
                SmHansWu: { id: "SmHansWu" },
                UTqzZklF: { id: "UTqzZklF" }
              },
              visibleCols: [true, false]
            },
            SmHansWu: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "SmHansWu",
              title: "\u7528\u6237\u540D\u79F0",
              checkByExp: [],
              visible: true,
              required: true,
              titleAlign: "left",
              widgetCode: "FormInput$4",
              field: null,
              fieldInfo: null,
              readOnly: false,
              stringLength: 20,
              eventTypesWithTags: [],
              forbidChange: true,
              linkage: null,
              fieldSearch: null,
              _props: { title: "\u7528\u6237\u540D\u79F0" }
            },
            UTqzZklF: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "UTqzZklF",
              title: "\u6587\u672C\u6846",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$6",
              defRealVal: "add",
              linkage: null,
              _props: { title: "\u6587\u672C\u6846" }
            },
            yvDqvOtJ: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "yvDqvOtJ",
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              visible: true,
              btnsConfig: [],
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            YVJfRWEH: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "YVJfRWEH",
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              visible: true,
              customId: "anupPCUa_subFormInlineBtns",
              btnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "hvSdMgqj",
                  btnType: "delete",
                  groupId: "yvDqvOtJ"
                }
              ]
            },
            hvSdMgqj: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "hvSdMgqj",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: {
                padding: "0px 4px 0px 4px",
                cursor: "pointer",
                borderRadius: "6px",
                height: "28px",
                lineHeight: "28px",
                fontSize: "12px",
                color: "#096dd9"
              },
              size: "middle",
              $lazyload: false,
              type: "link",
              groupBtnId: "yvDqvOtJ"
            },
            SeabQHRm: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "SeabQHRm",
              contentAlign: "right",
              style: { padding: "16px 0px 0px 0px" },
              widgetCode: "FloatBar$1"
            },
            fIHIXxnl: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "fIHIXxnl",
              title: "\u786E\u5B9A",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px" },
              widgetCode: "FormButton$3",
              eventTypesWithTags: []
            },
            MFELzXnC: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "MFELzXnC",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              style: {
                padding: "4px 15px 4px 15px",
                background: "white",
                color: "#1890FF"
              },
              eventTypesWithTags: [],
              widgetCode: "FormButton$5"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1638424729922",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1638424729922",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            SmHansWu: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "HnfBBsDk",
                                      path: ["selectedRows", "id"]
                                    },
                                    {
                                      widgetId: "HnfBBsDk",
                                      path: ["selectedRows", "username"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1466352077470052352",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u7528\u6237",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "colsVal_anupPCUa.saveValV2_SmHansWu",
                                      widgetId: "anupPCUa",
                                      propPath: ["colsVal", "saveValV2_SmHansWu"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "HnfBBsDk",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "colsVal_anupPCUa.realValV2_SmHansWu",
                                      widgetId: "anupPCUa",
                                      propPath: ["colsVal", "realValV2_SmHansWu"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "HnfBBsDk",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "username"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "GaAFiiDg"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u7528\u6237\u5F39\u7A97" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            fIHIXxnl: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "yuGpoMrr", path: ["saveValV2"] },
                                    { widgetId: "EXbGiJFC", path: ["saveValV2"] },
                                    { widgetId: "yBzqkVJy", path: ["saveValV2"] },
                                    { widgetId: "Ccflwxlx", path: ["saveValV2"] },
                                    { widgetId: "LApCKeus", path: ["saveValV2"] },
                                    { widgetId: "aSZGRSeX", path: ["saveValV2"] },
                                    {
                                      widgetId: "anupPCUa",
                                      path: ["colsVal", "saveValV2_SmHansWu"]
                                    },
                                    {
                                      widgetId: "anupPCUa",
                                      path: ["colsVal", "saveValV2_UTqzZklF"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1636427290219",
                                  input: [
                                    {
                                      "__root.title": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "yuGpoMrr",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.on_time_push_time": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "EXbGiJFC",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.priority": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "yBzqkVJy",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.content": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "Ccflwxlx",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.push_type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "LApCKeus",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.time_push": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "aSZGRSeX",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.sys_notice_user.user_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "anupPCUa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_SmHansWu"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.sys_notice_user._type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "anupPCUa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_UTqzZklF"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u65B0\u589E\u7CFB\u7EDF\u516C\u544A" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "anupPCUa",
                                      path: ["colsVal", "saveValV2_SmHansWu"]
                                    },
                                    { widgetId: "Ccflwxlx", path: ["saveValV2"] },
                                    { widgetId: "EXbGiJFC", path: ["saveValV2"] },
                                    { widgetId: "yBzqkVJy", path: ["saveValV2"] },
                                    { widgetId: "yuGpoMrr", path: ["saveValV2"] },
                                    { widgetId: "LApCKeus", path: ["saveValV2"] },
                                    { widgetId: "aSZGRSeX", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: true
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.updateDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1636027925113",
                                  updateType: "submitWholeForm",
                                  input: [],
                                  conditionBasis: [
                                    {
                                      "__root.id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_1_id"
                                      })
                                    },
                                    { "__root.sys_notice_user._type": "add" },
                                    {
                                      "__root.sys_notice_user.user_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "anupPCUa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_SmHansWu"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.content": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "Ccflwxlx",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.on_time_push_time": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "EXbGiJFC",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.priority": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "yBzqkVJy",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.title": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "yuGpoMrr",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.push_type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "LApCKeus",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.time_push": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "aSZGRSeX",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4FEE\u6539\u7CFB\u7EDF\u516C\u544A" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "detail",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            MFELzXnC: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "yuGpoMrr",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "Ccflwxlx",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "yBzqkVJy",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "LApCKeus",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "aSZGRSeX",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "SVHSRTdm",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "EXbGiJFC",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "anupPCUa",
                  children: [
                    {
                      id: "anupPCUa_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "yvDqvOtJ",
                          parentToChild: "1:1",
                          type: "node",
                          children: []
                        }
                      ]
                    },
                    {
                      id: "anupPCUa_subFormInlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "YVJfRWEH",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "hvSdMgqj",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "anupPCUa_subFormBody",
                      type: "renderProp",
                      children: [
                        {
                          id: "SmHansWu",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "UTqzZklF",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "SeabQHRm",
                  children: [
                    {
                      id: "fIHIXxnl",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "MFELzXnC",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_qrRqYazs: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  yuGpoMrr: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "yuGpoMrr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ZUDfFYWU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  Ccflwxlx: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "Ccflwxlx",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_AbXCMyCS: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  yBzqkVJy: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "yBzqkVJy",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zSfsDRrF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  LApCKeus: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "LApCKeus",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_iCkqiNJF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aSZGRSeX: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "aSZGRSeX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ZWNmHXYg: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) != null ? platform_exp_default.ToString(param == null ? void 0 : param.$0) : "0";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aSZGRSeX: [
                    { path: "saveValV2", id: "aSZGRSeX", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { SVHSRTdm: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_HhxMEyGL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SVHSRTdm: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "SVHSRTdm",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_JyCOEgJn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EXbGiJFC: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "EXbGiJFC",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { aSZGRSeX: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_JfzfnLzX: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EXbGiJFC: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EXbGiJFC",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cDMPYxnr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  anupPCUa: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "anupPCUa",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_IDQCKkgr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  anupPCUa: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "anupPCUa",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_sgadWgqY: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SmHansWu: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "SmHansWu",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_KyuYTIfZ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  UTqzZklF: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "UTqzZklF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_qrRqYazs", type: "exp" },
                { id: "exp_ZUDfFYWU", type: "exp" },
                { id: "exp_AbXCMyCS", type: "exp" },
                { id: "exp_zSfsDRrF", type: "exp" },
                { id: "exp_iCkqiNJF", type: "exp" },
                { id: "exp_HhxMEyGL", type: "exp" },
                { id: "exp_JfzfnLzX", type: "exp" },
                { id: "exp_cDMPYxnr", type: "exp" },
                { id: "exp_IDQCKkgr", type: "exp" },
                { id: "exp_sgadWgqY", type: "exp" },
                { id: "exp_KyuYTIfZ", type: "exp" }
              ]
            },
            widget: {
              SVHSRTdm: { saveValV2: [{ id: "exp_ZWNmHXYg", type: "exp" }] },
              aSZGRSeX: { saveValV2: [{ id: "exp_JyCOEgJn", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$yuGpoMrr`,
            key: `PC$$yuGpoMrr`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$Ccflwxlx`,
            key: `PC$$Ccflwxlx`,
            pageCtx,
            widgetRef: "RichEditor"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$yBzqkVJy`,
            key: `PC$$yBzqkVJy`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$LApCKeus`,
            key: `PC$$LApCKeus`,
            pageCtx,
            widgetRef: "Checkbox"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$aSZGRSeX`,
            key: `PC$$aSZGRSeX`,
            pageCtx,
            widgetRef: "Radio"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$SVHSRTdm`,
            key: `PC$$SVHSRTdm`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$EXbGiJFC`,
            key: `PC$$EXbGiJFC`,
            pageCtx,
            widgetRef: "FormDateTimePicker"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$anupPCUa`,
            key: `PC$$anupPCUa`,
            pageCtx,
            widgetRef: "SubformContainer",
            customBtnRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$anupPCUa$$yvDqvOtJ`,
                  key: `PC$$anupPCUa$$yvDqvOtJ`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                }
              )
            ],
            inlineBtnsRenderer: ({
              index: anupPCUa_indexFromSubform,
              rowIndex: anupPCUa_rowIndexFromSubform
            }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$YVJfRWEH`,
                key: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$YVJfRWEH`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$YVJfRWEH$$hvSdMgqj`,
                  key: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$YVJfRWEH$$hvSdMgqj`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            bodyRenderer: ({
              index: anupPCUa_indexFromSubform,
              rowIndex: anupPCUa_rowIndexFromSubform
            }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$SmHansWu`,
                  key: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$SmHansWu`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$UTqzZklF`,
                  key: `PC$$anupPCUa$$%${anupPCUa_rowIndexFromSubform}%$$UTqzZklF`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$SeabQHRm`,
            key: `PC$$SeabQHRm`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$SeabQHRm$$fIHIXxnl`,
              key: `PC$$SeabQHRm$$fIHIXxnl`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$SeabQHRm$$MFELzXnC`,
              key: `PC$$SeabQHRm$$MFELzXnC`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        )
      );
    }
  };
  __publicField(Page1465927736886439936, "pageName", "\u65B0\u589E\u7CFB\u7EDF\u516C\u544A");
  __publicField(Page1465927736886439936, "$pageKey", "hmiWoXXd");
  __publicField(Page1465927736886439936, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
