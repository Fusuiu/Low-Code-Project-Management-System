var Page1548852313320468480 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1548852313320468480: () => Page1548852313320468480
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1548852313320468480 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1548852313320468480",
            pageName: "\u64CD\u4F5C\u65E5\u5FD7\u4FE1\u606F",
            apiMeta: {
              basisdata_list_org: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.org_name": {
                    title: "\u673A\u6784\u540D\u79F0",
                    __key: "org_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_code": {
                    title: "\u673A\u6784\u7F16\u53F7",
                    __key: "org_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.branch_leader_code": {
                    title: "\u5206\u7BA1\u9886\u5BFC\u7F16\u53F7",
                    __key: "branch_leader_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.level": {
                    title: "\u5C42\u7EA7",
                    __key: "level",
                    _remoteType: "string_number",
                    _type: "number",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pcode": {
                    title: "\u4E0A\u7EA7\u673A\u6784\u7F16\u53F7",
                    __key: "pcode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pid": {
                    title: "\u7236\u8282\u70B9",
                    __key: "pid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.path": {
                    title: "\u8DEF\u5F84",
                    __key: "path",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.manager_id": {
                    title: "\u673A\u6784\u8D1F\u8D23\u4EBAid",
                    __key: "manager_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.manager_code": {
                    title: "\u8D1F\u8D23\u4EBA\u7F16\u53F7",
                    __key: "manager_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._statusname": {
                    title: "\u673A\u6784\u72B6\u6001\u663E\u793A\u503C",
                    __key: "_statusname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u673A\u6784\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.name": {
                    title: "\u540D\u79F0_\u4E0D\u7528\u65E0\u6CD5\u5220",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  org_name: {
                    title: "\u673A\u6784\u540D\u79F0"
                  },
                  org_code: {
                    title: "\u673A\u6784\u7F16\u53F7"
                  },
                  branch_leader_code: {
                    title: "\u5206\u7BA1\u9886\u5BFC\u7F16\u53F7"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  level: {
                    title: "\u5C42\u7EA7"
                  },
                  pcode: {
                    title: "\u4E0A\u7EA7\u673A\u6784\u7F16\u53F7"
                  },
                  pid: {
                    title: "\u7236\u8282\u70B9"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  path: {
                    title: "\u8DEF\u5F84"
                  },
                  manager_id: {
                    title: "\u673A\u6784\u8D1F\u8D23\u4EBAid"
                  },
                  manager_code: {
                    title: "\u8D1F\u8D23\u4EBA\u7F16\u53F7"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  _statusname: {
                    title: "\u673A\u6784\u72B6\u6001\u663E\u793A\u503C"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  status: {
                    title: "\u673A\u6784\u72B6\u6001"
                  },
                  name: {
                    title: "\u540D\u79F0_\u4E0D\u7528\u65E0\u6CD5\u5220"
                  }
                }
              },
              "1535094014561366016_list_1658110242814": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.error_msg": {
                    title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F",
                    __key: "error_msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_module": {
                    title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
                    __key: "business_module",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_code": {
                    title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
                    __key: "hr_member_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_name": {
                    title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
                    __key: "hr_member_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.ip_address": {
                    title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740",
                    __key: "ip_address",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.log_date": {
                    title: "\u65E5\u5FD7\u65F6\u95F4",
                    __key: "log_date",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_behavior": {
                    title: "\u4F5C\u4E1A\u884C\u4E3A",
                    __key: "object_behavior",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_message": {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
                    __key: "object_message",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_name": {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
                    __key: "object_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.object_result": {
                    title: "\u4F5C\u4E1A\u7ED3\u679C",
                    __key: "object_result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_code": {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u7F16\u53F7",
                    __key: "org_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_name": {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
                    __key: "org_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.page_name": {
                    title: "\u64CD\u4F5C\u9875\u9762",
                    __key: "page_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.user_account_name": {
                    title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
                    __key: "user_account_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.username": {
                    title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D",
                    __key: "username",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.data_status": {
                    title: "\u6570\u636E\u72B6\u6001",
                    __key: "data_status",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.enable_disable": {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001",
                    __key: "enable_disable",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  error_msg: {
                    title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F"
                  },
                  business_module: {
                    title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757"
                  },
                  hr_member_code: {
                    title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7"
                  },
                  hr_member_name: {
                    title: "\u64CD\u4F5C\u4EBA\u59D3\u540D"
                  },
                  ip_address: {
                    title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740"
                  },
                  log_date: {
                    title: "\u65E5\u5FD7\u65F6\u95F4"
                  },
                  object_behavior: {
                    title: "\u4F5C\u4E1A\u884C\u4E3A"
                  },
                  object_message: {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F"
                  },
                  object_name: {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0"
                  },
                  object_result: {
                    title: "\u4F5C\u4E1A\u7ED3\u679C"
                  },
                  org_code: {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u7F16\u53F7"
                  },
                  org_name: {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0"
                  },
                  page_name: {
                    title: "\u64CD\u4F5C\u9875\u9762"
                  },
                  user_account_name: {
                    title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D"
                  },
                  username: {
                    title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D"
                  },
                  data_status: {
                    title: "\u6570\u636E\u72B6\u6001"
                  },
                  enable_disable: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  }
                }
              },
              "1535094014561366016_export_1658128559713": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root.fileContent": {
                    title: "\u6587\u4EF6\u4FE1\u606F",
                    __key: "fileContent",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {
                  business_module: {
                    title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757"
                  },
                  hr_member_code: {
                    title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7"
                  },
                  hr_member_name: {
                    title: "\u64CD\u4F5C\u4EBA\u59D3\u540D"
                  },
                  ip_address: {
                    title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740"
                  },
                  log_date: {
                    title: "\u65E5\u5FD7\u65F6\u95F4"
                  },
                  object_behavior: {
                    title: "\u4F5C\u4E1A\u884C\u4E3A"
                  },
                  object_message: {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F"
                  },
                  object_name: {
                    title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0"
                  },
                  object_result: {
                    title: "\u4F5C\u4E1A\u7ED3\u679C"
                  },
                  org_code: {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u7F16\u53F7"
                  },
                  org_name: {
                    title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0"
                  },
                  page_name: {
                    title: "\u64CD\u4F5C\u9875\u9762"
                  },
                  user_account_name: {
                    title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D"
                  },
                  username: {
                    title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D"
                  },
                  data_status: {
                    title: "\u6570\u636E\u72B6\u6001"
                  },
                  enable_disable: {
                    title: "\u542F\u7528\u7981\u7528\u72B6\u6001"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  }
                }
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              title: "\u64CD\u4F5C\u65E5\u5FD7\u4FE1\u606F"
            },
            uIAkYZaL: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "uIAkYZaL",
              hGutter: 0,
              vGutter: 0,
              style: {
                height: "100%",
                width: "100%",
                border: "0px",
                padding: "8px"
              },
              visible: true,
              widgetCode: "FlexLayoutContainer$1",
              title: "\u6805\u683C\u5E03\u5C401",
              gridByLine: [
                [
                  { span: 6, locked: false, id: "cONgNgjD" },
                  { span: 18, locked: false, id: "JogDLiId" }
                ]
              ]
            },
            txNRdYqR: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "txNRdYqR",
              span: 6,
              title: "\u6805\u683C1",
              style: { height: "100%", border: "0px" },
              visible: true
            },
            uFTreAMh: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "listDisplay",
              reloadEvents: ["onTreeQuery"],
              id: "uFTreAMh",
              style: { height: "100%" },
              multiCheck: false,
              title: "\u673A\u6784\u6811",
              titleAlign: "left",
              visible: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: true,
              expandLevel: 2,
              defaultSelectedNode: false,
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              readOnly: false,
              widgetCode: "Tree$1",
              sortInfo: [
                {
                  fieldID: "last_update_time",
                  title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                  sort: "desc"
                },
                { fieldID: "org_code", title: "\u673A\u6784\u7F16\u53F7", sort: "asc" }
              ],
              tTitleKey: "org_name",
              tPIdKey: "pid",
              tIdKey: "id",
              ds: "basisdata_list_org",
              asyncType: "1",
              isAsync: true,
              tPathKey: "path",
              tLevelKey: "level",
              nodeExpandNum: 2,
              chidrenNodesApi: "",
              chidrenNodesParam: [],
              searchNodesApi: "",
              searchNodesParam: [],
              parentsAndBothersNodesApi: "",
              parentsAndBothersNodesParam: [],
              selectedNodesPaths: "",
              selectedNodes: []
            },
            VeUrAxDr: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "VeUrAxDr",
              span: 18,
              title: "\u6805\u683C2",
              style: { height: "100%", border: "0px" },
              visible: true
            },
            MIaQVDEx: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "MIaQVDEx",
              title: "\u7528\u6237\u64CD\u4F5C\u65E5\u5FD7\u8868",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: {
                type: "checkbox",
                checkedStyle: "checkedCellNActiveRow"
              },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              style: { height: "100%" },
              headerBtns: [{ title: "\u5BFC\u51FA", btnType: "export" }],
              headerBtnsConfig: [{ title: "\u5BFC\u51FA", widgetId: "htPhiUGW" }],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "fqmhHQRL",
                  show: "visible",
                  type: "detail",
                  groupId: "vwCLgfVO"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
                  columnName: "user_account_name",
                  widgetId: "ClKKbxnW"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
                  columnName: "hr_member_name",
                  widgetId: "arQzWHJn"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
                  columnName: "hr_member_code",
                  widgetId: "acfagNqH"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
                  columnName: "business_module",
                  widgetId: "pwtcTYWB"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
                  columnName: "org_name",
                  widgetId: "BLUteyON"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4F5C\u4E1A\u884C\u4E3A",
                  columnName: "object_behavior",
                  widgetId: "uuHfksFH"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
                  columnName: "object_name",
                  widgetId: "mWLNnbVL"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
                  columnName: "object_message",
                  widgetId: "sFRKDoIm"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4F5C\u4E1A\u7ED3\u679C",
                  columnName: "object_result",
                  widgetId: "SfvVZcov"
                }
              ],
              columns: [
                {
                  dataIndex: "username",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "hxdkZBXr",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA\u7528\u6237\u540D",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "user_account_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "vgQCJFiE",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "object_behavior",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "EzSaicFH",
                  widgetRef: "FormInput",
                  title: "\u4F5C\u4E1A\u884C\u4E3A",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "object_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "KHlPjdPk",
                  widgetRef: "FormInput",
                  title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "object_message",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "UokFHBcC",
                  widgetRef: "FormInput",
                  title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "object_result",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "guTWWFoi",
                  widgetRef: "FormInput",
                  title: "\u4F5C\u4E1A\u7ED3\u679C",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "business_module",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "ezPQgZXo",
                  widgetRef: "FormInput",
                  title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "page_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "ELQMBXxq",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u9875\u9762",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "log_date",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "1",
                  showSortBtn: true,
                  widgetId: "elnrMGyE",
                  widgetRef: "FormDateTimePicker",
                  title: "\u65E5\u5FD7\u65F6\u95F4",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "hr_member_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "bImNKZgM",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "hr_member_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "fxeTcoFo",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "org_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "HTidgHqF",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "ip_address",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "UyXLkOEY",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBAIP\u5730\u5740",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "error_msg",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "1",
                  showSortBtn: false,
                  widgetId: "OYjBBxef",
                  widgetRef: "Textarea",
                  title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              conditions: [
                {
                  varAlias: 1,
                  field: "log_date",
                  paramAmount: 1,
                  method: "greaterEqu"
                },
                {
                  varAlias: 2,
                  field: "log_date",
                  paramAmount: 1,
                  method: "lessEqu"
                },
                { varAlias: 3, field: "org_code", paramAmount: 1, method: "in" },
                {
                  varAlias: 4,
                  field: "hr_member_name",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 5,
                  field: "hr_member_code",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 6,
                  field: "user_account_name",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 7,
                  field: "object_behavior",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 8,
                  field: "object_name",
                  paramAmount: 1,
                  method: "like"
                },
                {
                  varAlias: 9,
                  field: "business_module",
                  paramAmount: 1,
                  method: "like"
                }
              ],
              formula: "1 and 2 and 3 and (4 or 5 or 6 or 7 or 8 or 9 or 10)",
              tagKey: "",
              keySearch: {
                fields: [
                  { field: "business_module" },
                  { field: "hr_member_code" },
                  { field: "hr_member_name" },
                  { field: "ip_address" },
                  { field: "object_behavior" },
                  { field: "object_message" },
                  { field: "object_name" },
                  { field: "object_result" },
                  { field: "org_code" },
                  { field: "org_name" },
                  { field: "page_name" },
                  { field: "user_account_name" },
                  { field: "username" },
                  { field: "data_status" },
                  { field: "enable_disable" }
                ],
                searchCondRel: "and"
              },
              keyshow: true,
              ds: "1535094014561366016_list_1658110242814",
              rowKey: "id",
              socket: "1535094014561366016_list_1658110242814",
              tableSortFieldList: [
                "business_module",
                "hr_member_code",
                "hr_member_name",
                "ip_address",
                "log_date",
                "object_behavior",
                "object_message",
                "object_name",
                "object_result",
                "org_code",
                "org_name",
                "page_name",
                "user_account_name",
                "username",
                "data_status",
                "enable_disable",
                "create_user_name",
                "id",
                "create_user_id",
                "create_time",
                "last_update_user_id",
                "last_update_time",
                "sequence",
                "last_update_user_name"
              ],
              orderNumWidth: null
            },
            rgugujxk: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "rgugujxk",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsProps: {
                ClKKbxnW: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                arQzWHJn: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                acfagNqH: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                pwtcTYWB: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                BLUteyON: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                uuHfksFH: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                mWLNnbVL: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                sFRKDoIm: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                SfvVZcov: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: [
                "vwumthcd",
                "mNipilZh",
                "ClKKbxnW",
                "arQzWHJn",
                "acfagNqH",
                "pwtcTYWB",
                "BLUteyON",
                "uuHfksFH",
                "mWLNnbVL",
                "sFRKDoIm",
                "SfvVZcov"
              ],
              bodyInfo: [
                {
                  id: "vwumthcd",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                {
                  id: "mNipilZh",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                { id: "ClKKbxnW", visible: true, widgetRef: "FormInput" },
                { id: "arQzWHJn", visible: true, widgetRef: "FormInput" },
                { id: "acfagNqH", visible: true, widgetRef: "FormInput" },
                { id: "pwtcTYWB", visible: true, widgetRef: "FormInput" },
                { id: "BLUteyON", visible: true, widgetRef: "FormInput" },
                { id: "uuHfksFH", visible: true, widgetRef: "FormInput" },
                { id: "mWLNnbVL", visible: true, widgetRef: "FormInput" },
                { id: "sFRKDoIm", visible: true, widgetRef: "FormInput" },
                { id: "SfvVZcov", visible: true, widgetRef: "FormInput" }
              ]
            },
            vwumthcd: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "vwumthcd",
              title: "\u5F00\u59CB\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnly: false,
              widgetCode: "FormDateTimePicker$2",
              field: null,
              fieldInfo: null,
              searchMethod: "like",
              fieldColumn: null
            },
            mNipilZh: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "mNipilZh",
              title: "\u7ED3\u675F\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnly: false,
              widgetCode: "FormDateTimePicker$1"
            },
            ClKKbxnW: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "ClKKbxnW",
              title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "user_account_name", title: "\u64CD\u4F5C\u4EBA\u8D26\u53F7\u540D" },
              field: "user_account_name",
              searchMethod: "like",
              widgetCode: "FormInput$19",
              columnName: "user_account_name"
            },
            arQzWHJn: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "arQzWHJn",
              title: "\u64CD\u4F5C\u4EBA\u59D3\u540D",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "hr_member_name", title: "\u64CD\u4F5C\u4EBA\u59D3\u540D" },
              field: "hr_member_name",
              searchMethod: "like",
              widgetCode: "FormInput$20",
              columnName: "hr_member_name"
            },
            acfagNqH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "acfagNqH",
              title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "hr_member_code", title: "\u64CD\u4F5C\u4EBA\u5DE5\u53F7" },
              field: "hr_member_code",
              searchMethod: "like",
              widgetCode: "FormInput$21",
              columnName: "hr_member_code"
            },
            pwtcTYWB: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "pwtcTYWB",
              title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "business_module", title: "\u6240\u5C5E\u4E1A\u52A1\u6A21\u5757" },
              field: "business_module",
              searchMethod: "like",
              widgetCode: "FormInput$22",
              columnName: "business_module"
            },
            BLUteyON: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "BLUteyON",
              title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "org_name", title: "\u64CD\u4F5C\u4EBA\u6240\u5C5E\u673A\u6784\u540D\u79F0" },
              field: "org_name",
              searchMethod: "like",
              widgetCode: "FormInput$23",
              columnName: "org_name"
            },
            uuHfksFH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "uuHfksFH",
              title: "\u4F5C\u4E1A\u884C\u4E3A",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "object_behavior", title: "\u4F5C\u4E1A\u884C\u4E3A" },
              field: "object_behavior",
              searchMethod: "like",
              widgetCode: "FormInput$24",
              columnName: "object_behavior"
            },
            mWLNnbVL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "mWLNnbVL",
              title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "object_name", title: "\u4F5C\u4E1A\u5BF9\u8C61\u540D\u79F0" },
              field: "object_name",
              searchMethod: "like",
              widgetCode: "FormInput$25",
              columnName: "object_name"
            },
            sFRKDoIm: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "sFRKDoIm",
              title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "object_message", title: "\u4F5C\u4E1A\u5BF9\u8C61\u5173\u952E\u4FE1\u606F" },
              field: "object_message",
              searchMethod: "like",
              widgetCode: "FormInput$26",
              columnName: "object_message"
            },
            SfvVZcov: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "SfvVZcov",
              title: "\u4F5C\u4E1A\u7ED3\u679C",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              fieldSearch: { field: "object_result", title: "\u4F5C\u4E1A\u7ED3\u679C" },
              field: "object_result",
              searchMethod: "like",
              widgetCode: "FormInput$27",
              columnName: "object_result"
            },
            TTQYcqMt: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "TTQYcqMt",
              visible: true,
              customId: "MIaQVDEx_headerBtns",
              btnsConfig: [{ title: "\u5BFC\u51FA", widgetId: "htPhiUGW" }],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            htPhiUGW: {
              title: "\u5BFC\u51FA",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "htPhiUGW",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              size: "middle",
              widgetCode: "FormButton$1",
              type: "primary",
              eventTypesWithTags: [
                { eventType: "onClick", tagType: "expandMenu" }
              ]
            },
            vwCLgfVO: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "vwCLgfVO",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "MIaQVDEx_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "fqmhHQRL",
                  show: "visible",
                  type: "detail",
                  groupId: "vwCLgfVO"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            fqmhHQRL: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "fqmhHQRL",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            hxdkZBXr: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "hxdkZBXr",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "username",
              fieldColumn: { field: "username" },
              $lazyload: false
            },
            vgQCJFiE: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "vgQCJFiE",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "user_account_name",
              fieldColumn: { field: "user_account_name" },
              $lazyload: false
            },
            EzSaicFH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "EzSaicFH",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "object_behavior",
              fieldColumn: { field: "object_behavior" },
              $lazyload: false
            },
            KHlPjdPk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "KHlPjdPk",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "object_name",
              fieldColumn: { field: "object_name" },
              $lazyload: false
            },
            UokFHBcC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "UokFHBcC",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "object_message",
              fieldColumn: { field: "object_message" },
              $lazyload: false
            },
            guTWWFoi: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "guTWWFoi",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "object_result",
              fieldColumn: { field: "object_result" },
              $lazyload: false
            },
            ezPQgZXo: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "ezPQgZXo",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "business_module",
              fieldColumn: { field: "business_module" },
              $lazyload: false
            },
            ELQMBXxq: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "ELQMBXxq",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "page_name",
              fieldColumn: { field: "page_name" },
              $lazyload: false
            },
            elnrMGyE: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "elnrMGyE",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              field: "log_date",
              fieldColumn: { field: "log_date" },
              $lazyload: false
            },
            bImNKZgM: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "bImNKZgM",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "hr_member_name",
              fieldColumn: { field: "hr_member_name" },
              $lazyload: false
            },
            fxeTcoFo: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "fxeTcoFo",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "hr_member_code",
              fieldColumn: { field: "hr_member_code" },
              $lazyload: false
            },
            HTidgHqF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "HTidgHqF",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "org_name",
              fieldColumn: { field: "org_name" },
              $lazyload: false
            },
            UyXLkOEY: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "UyXLkOEY",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "ip_address",
              fieldColumn: { field: "ip_address" },
              widgetCode: "FormInput$9",
              $lazyload: false
            },
            OYjBBxef: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Textarea",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              parseInReadOnly: true,
              id: "OYjBBxef",
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              checkByExp: [],
              rows: 3,
              style: {},
              required: false,
              field: "error_msg",
              fieldColumn: { field: "error_msg", title: "\u9519\u8BEF\u8BE6\u60C5\u4FE1\u606F" },
              $lazyload: false,
              columnName: "error_msg"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            htPhiUGW: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.exportData) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "1535094014561366016_export_1658128559713",
                                  input: [],
                                  outputPath: "__root.result",
                                  searchConds: void 0,
                                  rangeConds: void 0,
                                  selectedColsCond: {
                                    id: "MIaQVDEx",
                                    field: "id",
                                    method: "in"
                                  },
                                  apis: {
                                    exportApi: "1535094014561366016_export_1658128559713"
                                  },
                                  inputParamsTemplate: [],
                                  outputParamsTemplate: [],
                                  successCallback: () => __async(this, null, function* () {
                                  }),
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5BFC\u51FA[\u7528\u6237\u64CD\u4F5C\u65E5\u5FD7\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            fqmhHQRL: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "MIaQVDEx",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1548855937488531456",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "bzbjPSYB",
                                  pageNameCn: "\u8BE6\u60C5",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "MIaQVDEx",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u64CD\u4F5C\u65E5\u5FD7\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "MIaQVDEx",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1548855937488531456",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "bzbjPSYB",
                                  pageNameCn: "\u8BE6\u60C5",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "MIaQVDEx",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u64CD\u4F5C\u65E5\u5FD7\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "uIAkYZaL",
                  children: [
                    {
                      id: "txNRdYqR",
                      children: [
                        {
                          id: "uFTreAMh",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "VeUrAxDr",
                      children: [
                        {
                          id: "MIaQVDEx",
                          children: [
                            {
                              id: "rgugujxk",
                              children: [
                                {
                                  id: "vwumthcd",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "mNipilZh",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "ClKKbxnW",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "arQzWHJn",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "acfagNqH",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "pwtcTYWB",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "BLUteyON",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "uuHfksFH",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "mWLNnbVL",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "sFRKDoIm",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "SfvVZcov",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            },
                            {
                              id: "MIaQVDEx_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "TTQYcqMt",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: [
                                    {
                                      id: "htPhiUGW",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "MIaQVDEx_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "vwCLgfVO",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "fqmhHQRL",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "MIaQVDEx_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "hxdkZBXr",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "vgQCJFiE",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "EzSaicFH",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "KHlPjdPk",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "UokFHBcC",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "guTWWFoi",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "ezPQgZXo",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "ELQMBXxq",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "elnrMGyE",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "bImNKZgM",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "fxeTcoFo",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "HTidgHqF",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "UyXLkOEY",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "OYjBBxef",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_dJJJVwyU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uFTreAMh: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "uFTreAMh",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_HuaeOnYp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vwumthcd: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "vwumthcd",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_rHtaWzFT: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  mNipilZh: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "mNipilZh",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_dJJJVwyU", type: "exp" },
                { id: "exp_HuaeOnYp", type: "exp" },
                { id: "exp_rHtaWzFT", type: "exp" }
              ]
            },
            widget: {
              vwumthcd: {
                realValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.0.value",
                    action: "changeConditions"
                  }
                ]
              },
              mNipilZh: {
                realValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.1.value",
                    action: "changeConditions"
                  }
                ]
              },
              uFTreAMh: {
                "selectedData.org_code": [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.2.value",
                    action: "changeConditions"
                  }
                ]
              },
              arQzWHJn: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.3.value",
                    action: "changeConditions"
                  }
                ]
              },
              acfagNqH: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.4.value",
                    action: "changeConditions"
                  }
                ]
              },
              ClKKbxnW: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.5.value",
                    action: "changeConditions"
                  }
                ]
              },
              uuHfksFH: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.6.value",
                    action: "changeConditions"
                  }
                ]
              },
              mWLNnbVL: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.7.value",
                    action: "changeConditions"
                  }
                ]
              },
              pwtcTYWB: {
                saveValV2: [
                  {
                    id: "MIaQVDEx",
                    type: "widget",
                    path: "conditions.8.value",
                    action: "changeConditions"
                  }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: ["1535094014561366016_list_1658110242814"]
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$uIAkYZaL`,
            key: `PC$$uIAkYZaL`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$uIAkYZaL$$txNRdYqR`,
              key: `PC$$uIAkYZaL$$txNRdYqR`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$uIAkYZaL$$txNRdYqR$$uFTreAMh`,
                key: `PC$$uIAkYZaL$$txNRdYqR$$uFTreAMh`,
                pageCtx,
                widgetRef: "Tree"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$uIAkYZaL$$VeUrAxDr`,
              key: `PC$$uIAkYZaL$$VeUrAxDr`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx`,
                key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$TTQYcqMt`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$TTQYcqMt`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$TTQYcqMt$$htPhiUGW`,
                        key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$TTQYcqMt$$htPhiUGW`,
                        pageCtx,
                        widgetRef: "FormButton"
                      }
                    )
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromMIaQVDEx, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vwCLgfVO`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vwCLgfVO`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vwCLgfVO$$fqmhHQRL`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vwCLgfVO$$fqmhHQRL`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromMIaQVDEx }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$hxdkZBXr`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$hxdkZBXr`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vgQCJFiE`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$vgQCJFiE`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$EzSaicFH`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$EzSaicFH`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$KHlPjdPk`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$KHlPjdPk`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$UokFHBcC`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$UokFHBcC`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$guTWWFoi`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$guTWWFoi`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$ezPQgZXo`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$ezPQgZXo`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$ELQMBXxq`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$ELQMBXxq`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$elnrMGyE`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$elnrMGyE`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$bImNKZgM`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$bImNKZgM`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$fxeTcoFo`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$fxeTcoFo`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$HTidgHqF`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$HTidgHqF`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$UyXLkOEY`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$UyXLkOEY`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$OYjBBxef`,
                      key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$%${indexFromMIaQVDEx}%$$OYjBBxef`,
                      pageCtx,
                      widgetRef: "Textarea"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk`,
                  key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$vwumthcd`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$vwumthcd`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$mNipilZh`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$mNipilZh`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$ClKKbxnW`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$ClKKbxnW`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$arQzWHJn`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$arQzWHJn`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$acfagNqH`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$acfagNqH`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$pwtcTYWB`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$pwtcTYWB`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$BLUteyON`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$BLUteyON`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$uuHfksFH`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$uuHfksFH`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$mWLNnbVL`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$mWLNnbVL`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$sFRKDoIm`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$sFRKDoIm`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$SfvVZcov`,
                    key: `PC$$uIAkYZaL$$VeUrAxDr$$MIaQVDEx$$rgugujxk$$SfvVZcov`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1548852313320468480, "pageName", "\u64CD\u4F5C\u65E5\u5FD7\u4FE1\u606F");
  __publicField(Page1548852313320468480, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
