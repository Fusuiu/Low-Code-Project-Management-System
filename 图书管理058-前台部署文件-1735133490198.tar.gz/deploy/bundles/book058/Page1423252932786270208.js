var Page1423252932786270208 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1423252932786270208: () => Page1423252932786270208
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1423252932786270208 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1423252932786270208",
            pageName: "\u5173\u8054\u9875\u9762",
            apiMeta: {
              "1418509899297599488_detail_1628153613329": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.in_time": {
                    title: "\u8FDB\u5165\u673A\u6784\u65F6\u95F4",
                    __key: "in_time",
                    _remoteType: void 0,
                    _type: "date",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.org_id": {
                    title: "\u673A\u6784id",
                    __key: "org_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              "1418509899704446976_detail_1628164986371": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.account_id": {
                    title: "\u8D26\u6237id",
                    __key: "account_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              "1418509899150798848_list_1628164990981": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.position_id": {
                    title: "\u5C97\u4F4Did",
                    __key: "position_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  hr_member_id: {
                    title: "\u4EBA\u5458id"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  position_id: {
                    title: "\u5C97\u4F4Did"
                  }
                }
              },
              "1343522824660332544_detail_1627460592746": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.role_id": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "role_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.user_id": {
                    title: "\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              "1343522824660332544_insert_1627460592481": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.role_id": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "role_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.user_id": {
                    title: "\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1418509899150798848_insert_1628164990395": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.position_id": {
                    title: "\u5C97\u4F4Did",
                    __key: "position_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1418509899704446976_insert_1628164986117": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.account_id": {
                    title: "\u8D26\u6237id",
                    __key: "account_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1418509899297599488_insert_1628153613015": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.in_time": {
                    title: "\u8FDB\u5165\u673A\u6784\u65F6\u95F4",
                    __key: "in_time",
                    _remoteType: void 0,
                    _type: "date",
                    __parent: "__root"
                  },
                  "__root.org_id": {
                    title: "\u673A\u6784id",
                    __key: "org_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.hr_member_id": {
                    title: "\u4EBA\u5458id",
                    __key: "hr_member_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {}
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              title: "\u5173\u8054\u9875\u9762",
              dss: [
                "1418509899297599488_detail_1628153613329",
                "1418509899704446976_detail_1628164986371",
                "1418509899150798848_list_1628164990981",
                "1343522824660332544_detail_1627460592746"
              ],
              requests: {
                "1418509899297599488_detail_1628153613329": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ],
                "1418509899704446976_detail_1628164986371": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ],
                "1343522824660332544_detail_1627460592746": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              }
            },
            Irrdffmp: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "Irrdffmp",
              grid: [
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" },
                { span: "12" }
              ],
              hGutter: 16,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1",
              title: "\u6805\u683C\u5E03\u5C401"
            },
            PockNCJe: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "PockNCJe",
              span: "12",
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 8px 0px 8px"
              }
            },
            GIQZZjhS: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "GIQZZjhS",
              title: "\u9009\u62E9\u4EBA\u5458",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$1",
              eventTypesWithTags: [],
              forbidChange: true
            },
            kIMckjNV: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "kIMckjNV",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C2",
              widgetCode: "FlexLayout$1"
            },
            PIQpUkpK: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "PIQpUkpK",
              title: "\u9009\u62E9\u4EBA\u5458Code",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: true,
              widgetCode: "FormInput$2"
            },
            qxTHKNMJ: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "qxTHKNMJ",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C3"
            },
            CFJFVtyu: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "CFJFVtyu",
              title: "\u9009\u62E9\u7528\u6237",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$5",
              eventTypesWithTags: [],
              forbidChange: true
            },
            oabbrjDD: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "oabbrjDD",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C4"
            },
            FYhLHfsD: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "FYhLHfsD",
              title: "\u9009\u62E9\u7528\u6237Code",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: true,
              widgetCode: "FormInput$6"
            },
            ByfjeXpF: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "ByfjeXpF",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C5"
            },
            YSmWHyyF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "YSmWHyyF",
              title: "\u9009\u62E9\u673A\u6784",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$3",
              eventTypesWithTags: [],
              forbidChange: true
            },
            DPgkgFca: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "DPgkgFca",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C6"
            },
            xupaSDfr: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "xupaSDfr",
              title: "\u9009\u62E9\u673A\u6784Code",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: true,
              widgetCode: "FormInput$4"
            },
            SQYiTBHX: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "SQYiTBHX",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C7",
              widgetCode: "FlexLayout$1"
            },
            beCGbOxA: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "beCGbOxA",
              title: "\u9009\u62E9\u5C97\u4F4D",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$7",
              eventTypesWithTags: [],
              forbidChange: true
            },
            bDyxFLDN: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "bDyxFLDN",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C8",
              widgetCode: "FlexLayout$1"
            },
            mJnFWNoB: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "mJnFWNoB",
              title: "\u9009\u62E9\u5C97\u4F4DCode",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$8"
            },
            jucRVQnJ: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "jucRVQnJ",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C9"
            },
            PZWzGjPR: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "PZWzGjPR",
              title: "\u9009\u62E9\u89D2\u8272",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$9",
              eventTypesWithTags: [],
              forbidChange: true
            },
            YIiKwWua: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "YIiKwWua",
              span: "12",
              visible: true,
              style: { padding: "0px 8px 0px 8px" },
              title: "\u6805\u683C10"
            },
            gcBzpAMv: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "gcBzpAMv",
              title: "\u9009\u62E9\u89D2\u8272Code",
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$10"
            },
            qzDYmtLG: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "qzDYmtLG",
              grid: [{ span: 6 }, { span: 6 }, { span: 6 }, { span: 6 }],
              hGutter: 0,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$2",
              title: "\u6805\u683C\u5E03\u5C402"
            },
            fCjFduLm: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "fCjFduLm",
              span: 6,
              title: "\u6805\u683C1",
              style: { height: "auto", border: "0px" },
              widgetCode: "FlexLayout$1"
            },
            yLGDxOnn: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "yLGDxOnn",
              title: "\u4EBA\u5458-\u5C97\u4F4D",
              visible: true,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$3",
              eventTypesWithTags: []
            },
            eFwpfuVG: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "eFwpfuVG",
              span: 6,
              visible: true,
              style: {},
              title: "\u6805\u683C2"
            },
            wkCPdCsJ: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "wkCPdCsJ",
              title: "\u4EBA\u5458-\u673A\u6784",
              visible: true,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$4",
              eventTypesWithTags: []
            },
            OtzgSDmg: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "OtzgSDmg",
              span: 6,
              visible: true,
              style: {},
              title: "\u6805\u683C3"
            },
            SlSXnvtw: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "SlSXnvtw",
              title: "\u4EBA\u5458-\u8D26\u53F7",
              visible: true,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$2",
              eventTypesWithTags: []
            },
            AvUFtbhY: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "AvUFtbhY",
              span: 6,
              visible: true,
              style: {},
              title: "\u6805\u683C4"
            },
            wSLZyayH: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "wSLZyayH",
              title: "\u89D2\u8272-\u7528\u6237",
              visible: true,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$5",
              eventTypesWithTags: []
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1418509899297599488_detail_1628153613329",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1418509899704446976_detail_1628164986371",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1418509899150798848_list_1628164990981",
                                      method: "post",
                                      range: null
                                    },
                                    {
                                      ds: "1343522824660332544_detail_1627460592746",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1418509899297599488_detail_1628153613329",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1418509899704446976_detail_1628164986371",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1418509899150798848_list_1628164990981",
                                      method: "post",
                                      range: null
                                    },
                                    {
                                      ds: "1343522824660332544_detail_1627460592746",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            GIQZZjhS: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "JjSbkVmQ",
                                      path: ["selectedRows", "name"]
                                    },
                                    {
                                      widgetId: "JjSbkVmQ",
                                      path: ["selectedRows", "code"]
                                    },
                                    {
                                      widgetId: "JjSbkVmQ",
                                      path: ["selectedRows", "name"]
                                    },
                                    {
                                      widgetId: "JjSbkVmQ",
                                      path: ["selectedRows", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1423207030210048000",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u4EBA\u5458",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "realValV2_PIQpUkpK",
                                      widgetId: "PIQpUkpK",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "JjSbkVmQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "name"]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_PIQpUkpK",
                                      widgetId: "PIQpUkpK",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "JjSbkVmQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "code"]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_GIQZZjhS",
                                      widgetId: "GIQZZjhS",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "JjSbkVmQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "name"]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_GIQZZjhS",
                                      widgetId: "GIQZZjhS",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "JjSbkVmQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "id"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "KghwPLHq"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u4EBA\u5458\u56DE\u586B" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            CFJFVtyu: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "PYknIlUu",
                                      path: ["selectedRows", "user_account_name"]
                                    },
                                    {
                                      widgetId: "PYknIlUu",
                                      path: ["selectedRows", "id"]
                                    },
                                    {
                                      widgetId: "PYknIlUu",
                                      path: ["selectedRows", "username"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1423255770044182528",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u7528\u6237",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "saveValV2_FYhLHfsD",
                                      widgetId: "FYhLHfsD",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "PYknIlUu",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "selectedRows",
                                            "user_account_name"
                                          ]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_CFJFVtyu",
                                      widgetId: "CFJFVtyu",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "PYknIlUu",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_CFJFVtyu",
                                      widgetId: "CFJFVtyu",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "PYknIlUu",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "username"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "qnlZEmMj"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u7528\u6237" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            YSmWHyyF: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "jlTdQlcJ",
                                      path: ["selectedData", "code"]
                                    },
                                    {
                                      widgetId: "jlTdQlcJ",
                                      path: ["selectedData", "id"]
                                    },
                                    {
                                      widgetId: "jlTdQlcJ",
                                      path: ["selectedData", "name"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1423206041390297088",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u673A\u6784",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "saveValV2_xupaSDfr",
                                      widgetId: "xupaSDfr",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "jlTdQlcJ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "code"]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_YSmWHyyF",
                                      widgetId: "YSmWHyyF",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "jlTdQlcJ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_YSmWHyyF",
                                      widgetId: "YSmWHyyF",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "jlTdQlcJ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "name"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "WnPHtdEb"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u673A\u6784" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            beCGbOxA: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "vlOZLzyQ",
                                      path: ["selectedRows", "name"]
                                    },
                                    {
                                      widgetId: "vlOZLzyQ",
                                      path: ["selectedRows", "id"]
                                    },
                                    {
                                      widgetId: "vlOZLzyQ",
                                      path: ["selectedRows", "code"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1423255448756301824",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u5C97\u4F4D",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "realValV2_beCGbOxA",
                                      widgetId: "beCGbOxA",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "vlOZLzyQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "name"]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_beCGbOxA",
                                      widgetId: "beCGbOxA",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "vlOZLzyQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "saveValV2_mJnFWNoB",
                                      widgetId: "mJnFWNoB",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "vlOZLzyQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "code"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "PpxKZiCF"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u5C97\u4F4D" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PZWzGjPR: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "KqxQoxem",
                                      path: ["selectedRows", "id"]
                                    },
                                    {
                                      widgetId: "KqxQoxem",
                                      path: ["selectedRows", "name"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1423256078275194880",
                                  appType: void 0,
                                  showCloseIcon: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  openType: "undefined",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  closePopup: void 0,
                                  showTopBar: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  pageNameCn: "\u9009\u62E9\u89D2\u8272",
                                  extraprops: { height: null, width: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "saveValV2_PZWzGjPR",
                                      widgetId: "PZWzGjPR",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "KqxQoxem",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_PZWzGjPR",
                                      widgetId: "PZWzGjPR",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "KqxQoxem",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedRows", "name"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "JLUlPuJs"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u9009\u62E9\u89D2\u8272" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            yLGDxOnn: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "beCGbOxA", path: ["saveValV2"] },
                                    { widgetId: "GIQZZjhS", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1418509899150798848_insert_1628164990395",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.position_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "beCGbOxA",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.hr_member_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "GIQZZjhS",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4EBA\u5458-\u5C97\u4F4D" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            wkCPdCsJ: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "GIQZZjhS", path: ["saveValV2"] },
                                    { widgetId: "YSmWHyyF", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1418509899297599488_insert_1628153613015",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.hr_member_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "GIQZZjhS",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.org_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "YSmWHyyF",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4EBA\u5458-\u673A\u6784" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            SlSXnvtw: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "GIQZZjhS", path: ["saveValV2"] },
                                    { widgetId: "CFJFVtyu", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1418509899704446976_insert_1628164986117",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.hr_member_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "GIQZZjhS",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.account_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "CFJFVtyu",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4EBA\u5458-\u7528\u6237" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            wSLZyayH: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "CFJFVtyu", path: ["saveValV2"] },
                                    { widgetId: "PZWzGjPR", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1343522824660332544_insert_1627460592481",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.user_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "CFJFVtyu",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.role_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "PZWzGjPR",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u5173\u8054\u7528\u6237-\u89D2\u8272" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "Irrdffmp",
                  children: [
                    {
                      id: "PockNCJe",
                      children: [
                        {
                          id: "GIQZZjhS",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "kIMckjNV",
                      children: [
                        {
                          id: "PIQpUkpK",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "qxTHKNMJ",
                      children: [
                        {
                          id: "CFJFVtyu",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "oabbrjDD",
                      children: [
                        {
                          id: "FYhLHfsD",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "ByfjeXpF",
                      children: [
                        {
                          id: "YSmWHyyF",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "DPgkgFca",
                      children: [
                        {
                          id: "xupaSDfr",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "SQYiTBHX",
                      children: [
                        {
                          id: "beCGbOxA",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "bDyxFLDN",
                      children: [
                        {
                          id: "mJnFWNoB",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "jucRVQnJ",
                      children: [
                        {
                          id: "PZWzGjPR",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "YIiKwWua",
                      children: [
                        {
                          id: "gcBzpAMv",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "qzDYmtLG",
                  children: [
                    {
                      id: "fCjFduLm",
                      children: [
                        {
                          id: "yLGDxOnn",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "eFwpfuVG",
                      children: [
                        {
                          id: "wkCPdCsJ",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "OtzgSDmg",
                      children: [
                        {
                          id: "SlSXnvtw",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "AvUFtbhY",
                      children: [
                        {
                          id: "wSLZyayH",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_ufiKcMfB: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  GIQZZjhS: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "GIQZZjhS",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_sZIlRKTb: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  CFJFVtyu: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "CFJFVtyu",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_RjIanTPN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  YSmWHyyF: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "YSmWHyyF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cTvaAwvY: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  beCGbOxA: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "beCGbOxA",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_egQXxKTR: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  mJnFWNoB: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "mJnFWNoB",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_slzlffuW: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  PZWzGjPR: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "PZWzGjPR",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_RLEHouCv: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  gcBzpAMv: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "gcBzpAMv",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_ufiKcMfB", type: "exp" },
                { id: "exp_sZIlRKTb", type: "exp" },
                { id: "exp_RjIanTPN", type: "exp" },
                { id: "exp_cTvaAwvY", type: "exp" },
                { id: "exp_egQXxKTR", type: "exp" },
                { id: "exp_slzlffuW", type: "exp" },
                { id: "exp_RLEHouCv", type: "exp" }
              ]
            },
            widget: {}
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$Irrdffmp`,
            key: `PC$$Irrdffmp`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$PockNCJe`,
              key: `PC$$Irrdffmp$$PockNCJe`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$PockNCJe$$GIQZZjhS`,
                key: `PC$$Irrdffmp$$PockNCJe$$GIQZZjhS`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$kIMckjNV`,
              key: `PC$$Irrdffmp$$kIMckjNV`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$kIMckjNV$$PIQpUkpK`,
                key: `PC$$Irrdffmp$$kIMckjNV$$PIQpUkpK`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$qxTHKNMJ`,
              key: `PC$$Irrdffmp$$qxTHKNMJ`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$qxTHKNMJ$$CFJFVtyu`,
                key: `PC$$Irrdffmp$$qxTHKNMJ$$CFJFVtyu`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$oabbrjDD`,
              key: `PC$$Irrdffmp$$oabbrjDD`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$oabbrjDD$$FYhLHfsD`,
                key: `PC$$Irrdffmp$$oabbrjDD$$FYhLHfsD`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$ByfjeXpF`,
              key: `PC$$Irrdffmp$$ByfjeXpF`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$ByfjeXpF$$YSmWHyyF`,
                key: `PC$$Irrdffmp$$ByfjeXpF$$YSmWHyyF`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$DPgkgFca`,
              key: `PC$$Irrdffmp$$DPgkgFca`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$DPgkgFca$$xupaSDfr`,
                key: `PC$$Irrdffmp$$DPgkgFca$$xupaSDfr`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$SQYiTBHX`,
              key: `PC$$Irrdffmp$$SQYiTBHX`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$SQYiTBHX$$beCGbOxA`,
                key: `PC$$Irrdffmp$$SQYiTBHX$$beCGbOxA`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$bDyxFLDN`,
              key: `PC$$Irrdffmp$$bDyxFLDN`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$bDyxFLDN$$mJnFWNoB`,
                key: `PC$$Irrdffmp$$bDyxFLDN$$mJnFWNoB`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$jucRVQnJ`,
              key: `PC$$Irrdffmp$$jucRVQnJ`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$jucRVQnJ$$PZWzGjPR`,
                key: `PC$$Irrdffmp$$jucRVQnJ$$PZWzGjPR`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$Irrdffmp$$YIiKwWua`,
              key: `PC$$Irrdffmp$$YIiKwWua`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$Irrdffmp$$YIiKwWua$$gcBzpAMv`,
                key: `PC$$Irrdffmp$$YIiKwWua$$gcBzpAMv`,
                pageCtx,
                widgetRef: "FormInput"
              }
            )
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$qzDYmtLG`,
            key: `PC$$qzDYmtLG`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qzDYmtLG$$fCjFduLm`,
              key: `PC$$qzDYmtLG$$fCjFduLm`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$qzDYmtLG$$fCjFduLm$$yLGDxOnn`,
                key: `PC$$qzDYmtLG$$fCjFduLm$$yLGDxOnn`,
                pageCtx,
                widgetRef: "FormButton"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qzDYmtLG$$eFwpfuVG`,
              key: `PC$$qzDYmtLG$$eFwpfuVG`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$qzDYmtLG$$eFwpfuVG$$wkCPdCsJ`,
                key: `PC$$qzDYmtLG$$eFwpfuVG$$wkCPdCsJ`,
                pageCtx,
                widgetRef: "FormButton"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qzDYmtLG$$OtzgSDmg`,
              key: `PC$$qzDYmtLG$$OtzgSDmg`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$qzDYmtLG$$OtzgSDmg$$SlSXnvtw`,
                key: `PC$$qzDYmtLG$$OtzgSDmg$$SlSXnvtw`,
                pageCtx,
                widgetRef: "FormButton"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$qzDYmtLG$$AvUFtbhY`,
              key: `PC$$qzDYmtLG$$AvUFtbhY`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$qzDYmtLG$$AvUFtbhY$$wSLZyayH`,
                key: `PC$$qzDYmtLG$$AvUFtbhY$$wSLZyayH`,
                pageCtx,
                widgetRef: "FormButton"
              }
            )
          )
        )
      );
    }
  };
  __publicField(Page1423252932786270208, "pageName", "\u5173\u8054\u9875\u9762");
  __publicField(Page1423252932786270208, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
