var Page1668504044102103041 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1668504044102103041: () => Page1668504044102103041
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1668504044102103041 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1668504044102103041",
            pageName: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u4E2D\u5FC3",
            apiMeta: {
              "1669609463667109888_list_1686900953519": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.remark": {
                    title: "\u5907\u6CE8\u63CF\u8FF0",
                    __key: "remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.output_file_param": {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "output_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.input_file_param": {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "input_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.progress": {
                    title: "\u8FDB\u5EA6",
                    __key: "progress",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.result": {
                    title: "\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.end_exec_time": {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6",
                    __key: "end_exec_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.exec_cost_time": {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F",
                    __key: "exec_cost_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.start_exec_time": {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4",
                    __key: "start_exec_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_des": {
                    title: "\u72B6\u6001\u63CF\u8FF0",
                    __key: "status_des",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u4EFB\u52A1\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_name": {
                    title: "\u4E1A\u52A1\u4E2D\u6587\u540D\u79F0",
                    __key: "business_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_code": {
                    title: "\u4E1A\u52A1\u7F16\u7801",
                    __key: "business_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_name": {
                    title: "\u4EFB\u52A1\u540D\u79F0",
                    __key: "task_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_type": {
                    title: "\u4EFB\u52A1\u7C7B\u578B",
                    __key: "task_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u53F7",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.less_code": {
                    title: "\u79DF\u6237\u53F7",
                    __key: "less_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {
                  remark: {
                    title: "\u5907\u6CE8\u63CF\u8FF0"
                  },
                  output_file_param: {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  input_file_param: {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F"
                  },
                  progress: {
                    title: "\u8FDB\u5EA6"
                  },
                  result: {
                    title: "\u7ED3\u679C"
                  },
                  end_exec_time: {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6"
                  },
                  exec_cost_time: {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F"
                  },
                  start_exec_time: {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4"
                  },
                  status_des: {
                    title: "\u72B6\u6001\u63CF\u8FF0"
                  },
                  status: {
                    title: "\u4EFB\u52A1\u72B6\u6001"
                  },
                  business_name: {
                    title: "\u4E1A\u52A1\u4E2D\u6587\u540D\u79F0"
                  },
                  business_code: {
                    title: "\u4E1A\u52A1\u7F16\u7801"
                  },
                  task_name: {
                    title: "\u4EFB\u52A1\u540D\u79F0"
                  },
                  task_type: {
                    title: "\u4EFB\u52A1\u7C7B\u578B"
                  },
                  app_code: {
                    title: "\u5E94\u7528\u53F7"
                  },
                  less_code: {
                    title: "\u79DF\u6237\u53F7"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  }
                }
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u4E2D\u5FC3"
            },
            WkMFjWwG: {
              varMap: { curTab: { type: "string" }, tapTab: { type: "string" } },
              widgetRef: "TabContainer",
              eventAttr: ["onTabChange", "onTabClick"],
              id: "WkMFjWwG",
              title: "\u6807\u7B7E\u9875",
              visible: true,
              showTitleEffective: false,
              titleAlign: "left",
              tabsVisibleList: [true, false],
              curTab: "",
              tabsList: [
                {
                  title: "\u5F02\u6B65\u4EFB\u52A1",
                  icon: "",
                  id: "QtRppnay",
                  style: { height: "100%", padding: "0px", margin: "0px" },
                  widgetCode: "Tab$1"
                },
                {
                  title: "\u5168\u90E8",
                  icon: "",
                  id: "UtqOSUVt",
                  style: { height: "100%", margin: "0px", padding: "0px" },
                  widgetCode: "Tab$1"
                }
              ],
              titleWeight: 400,
              labelColor: "#272727",
              style: { width: "100%", height: "100%" },
              widgetCode: "TabContainer$1",
              tabBarGutter: 12,
              tabType: "card"
            },
            QtRppnay: {
              varMap: {},
              widgetRef: "PureFlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "QtRppnay",
              span: 24,
              title: "\u6807\u7B7E1\u5BB9\u5668",
              style: { height: "100%", border: "0px solid #D6D7DA" },
              visible: true,
              widgetCode: "PureFlexLayout$1"
            },
            WjZLfFgH: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "WjZLfFgH",
              title: "\u5F02\u6B65\u4EFB\u52A1\u5217\u8868",
              titleAlign: "left",
              tableColumnHeaderStyle: { borderTheme: "divisionLine" },
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              fullscreen: true,
              searchExpandCollapse: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              btnsGroups: [
                { title: "\u66F4\u591A", id: "NhGmnWng", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "SLbvwHKT", type: "inlineBtns" }
              ],
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "UkFlWeWJ",
                  show: "visible",
                  type: "detail",
                  groupId: "SLbvwHKT"
                }
              ],
              widgetCode: "NormalTable$1",
              columns: [
                {
                  dataIndex: "task_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  fixed: "left",
                  widgetId: "hOFYmpGk",
                  widgetRef: "FormInput",
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "app_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "eMXvEySe",
                  widgetRef: "FormInput",
                  title: "\u6240\u5C5E\u5E94\u7528",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "status",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "veaQzBze",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_user_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "PXAPwQRQ",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  align: "left",
                  dataIndex: "_hy_etHbIpcj",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  configShow: true,
                  showSortBtn: false,
                  sortEditable: false,
                  width: "150px",
                  display: true,
                  title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
                  expId: "exp_pxDnJIYZ",
                  widgetId: "etHbIpcj",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  color: "#272727"
                },
                {
                  dataIndex: "exec_cost_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "bmhJTggs",
                  widgetRef: "FormInput",
                  title: "\u7ED3\u679C\u8017\u65F6",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "FqMIhOqU",
                  widgetRef: "FormDateTimePicker",
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "start_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "nenwcvZu",
                  widgetRef: "FormDateTimePicker",
                  title: "\u5F00\u59CB\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "end_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "cfkYIVaw",
                  widgetRef: "FormDateTimePicker",
                  title: "\u7ED3\u675F\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  columnName: "task_name",
                  widgetId: "GFfVCvAl"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u6240\u5C5E\u5E94\u7528",
                  columnName: "app_code",
                  widgetId: "itFoXgVx"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  columnName: "status",
                  widgetId: "fgfeUzla"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA",
                  columnName: "create_user_name",
                  widgetId: "CaLZYbAH"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  columnName: "create_time",
                  widgetId: "ONJpnFjC"
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" },
                { fieldID: "id", title: "\u4E3B\u952E", sort: "asc" }
              ],
              conditions: [
                {
                  varAlias: 1,
                  field: "task_type",
                  paramAmount: 1,
                  method: "equ",
                  value: ["1"]
                }
              ],
              formula: "1",
              tagKey: "",
              keyshow: false,
              ds: "1669609463667109888_list_1686900953519",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "remark",
                "output_file_param",
                "input_file_param",
                "progress",
                "result",
                "end_exec_time",
                "exec_cost_time",
                "start_exec_time",
                "status_des",
                "status",
                "business_name",
                "business_code",
                "task_name",
                "task_type",
                "app_code",
                "less_code",
                "last_update_time",
                "last_update_user_name",
                "last_update_user_id",
                "create_time",
                "create_user_name",
                "create_user_id",
                "id"
              ],
              relatedAppPage: {
                pageNameCn: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355",
                pageId: "1668512181710368769"
              }
            },
            RAkSSdjU: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "RAkSSdjU",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsProps: {
                GFfVCvAl: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                itFoXgVx: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                fgfeUzla: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                CaLZYbAH: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                ONJpnFjC: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: [
                "GFfVCvAl",
                "itFoXgVx",
                "fgfeUzla",
                "CaLZYbAH",
                "ONJpnFjC"
              ],
              bodyInfo: [
                { id: "GFfVCvAl", visible: true, widgetRef: "FormInput" },
                { id: "itFoXgVx", visible: true, widgetRef: "FormInput" },
                { id: "fgfeUzla", visible: true, widgetRef: "DropdownSelector" },
                { id: "CaLZYbAH", visible: true, widgetRef: "FormInput" },
                {
                  id: "ONJpnFjC",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                }
              ]
            },
            GFfVCvAl: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "GFfVCvAl",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$1",
              field: "task_name",
              fieldInfo: null,
              fieldSearch: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              fieldColumn: null,
              stringLength: 512,
              searchMethod: "like"
            },
            itFoXgVx: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "itFoXgVx",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u6240\u5C5E\u5E94\u7528",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              fieldSearch: { field: "app_code", title: "\u5E94\u7528\u53F7" },
              field: "app_code",
              searchMethod: "like",
              widgetCode: "FormInput$26",
              columnName: "app_code"
            },
            fgfeUzla: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "fgfeUzla",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$1",
              field: "status",
              fieldInfo: null,
              fieldSearch: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              fieldColumn: null,
              stringLength: 32,
              searchMethod: "in",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              }
            },
            CaLZYbAH: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "CaLZYbAH",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u64CD\u4F5C\u4EBA",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$2",
              field: "create_user_name",
              fieldInfo: null,
              fieldSearch: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              fieldColumn: null,
              stringLength: 32,
              searchMethod: "like"
            },
            ONJpnFjC: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "ONJpnFjC",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u63D0\u4EA4\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$1",
              field: "create_time",
              fieldInfo: null,
              fieldSearch: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              fieldColumn: null,
              stringLength: 0,
              searchMethod: "like"
            },
            NhGmnWng: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "NhGmnWng",
              visible: true,
              customId: "WjZLfFgH_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            SLbvwHKT: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "SLbvwHKT",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "WjZLfFgH_inlineBtns",
              btnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "UkFlWeWJ",
                  show: "visible",
                  type: "detail",
                  groupId: "SLbvwHKT"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            UkFlWeWJ: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "UkFlWeWJ",
              title: "\u4EFB\u52A1\u8BE6\u60C5",
              visible: true,
              disabled: false,
              iconType: "",
              style: { borderRadius: "0px", padding: "2px 4px", width: "auto" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              $lazyload: false,
              type: "link"
            },
            hOFYmpGk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "hOFYmpGk",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 512,
              widgetCode: "FormInput$27",
              field: "task_name",
              fieldColumn: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              $lazyload: false,
              columnName: "task_name"
            },
            eMXvEySe: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "eMXvEySe",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              widgetCode: "FormInput$28",
              field: "app_code",
              fieldColumn: { field: "app_code", title: "\u5E94\u7528\u53F7" },
              $lazyload: false,
              columnName: "app_code"
            },
            veaQzBze: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "veaQzBze",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                2: "\u90E8\u5206\u6210\u529F",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$11",
              field: "status",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              stringLength: 32,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              $lazyload: false,
              bodyContainer: true
            },
            PXAPwQRQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "PXAPwQRQ",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$30",
              field: "create_user_name",
              fieldColumn: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              $lazyload: false,
              columnName: "create_user_name"
            },
            etHbIpcj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              parseInReadOnly: true,
              id: "etHbIpcj",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              checkByExp: [],
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              required: false,
              stringLength: 65535,
              widgetCode: "Textarea$2",
              field: null,
              linkage: null,
              fieldInfo: null,
              fieldSearch: null,
              $lazyload: false,
              columnName: "result"
            },
            bmhJTggs: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "bmhJTggs",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              widgetCode: "FormInput$31",
              field: "exec_cost_time",
              fieldColumn: { field: "exec_cost_time", title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F" },
              $lazyload: false,
              columnName: "exec_cost_time"
            },
            FqMIhOqU: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "FqMIhOqU",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$16",
              field: "create_time",
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              $lazyload: false,
              columnName: "create_time"
            },
            nenwcvZu: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "nenwcvZu",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$17",
              field: "start_exec_time",
              fieldColumn: { field: "start_exec_time", title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4" },
              $lazyload: false,
              columnName: "start_exec_time"
            },
            cfkYIVaw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "cfkYIVaw",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$18",
              field: "end_exec_time",
              fieldColumn: { field: "end_exec_time", title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6" },
              $lazyload: false,
              columnName: "end_exec_time"
            },
            UtqOSUVt: {
              varMap: {},
              widgetRef: "PureFlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "UtqOSUVt",
              span: 24,
              title: "\u6807\u7B7E3\u5BB9\u5668",
              style: { height: "100%", border: "0px solid #D6D7DA" },
              visible: true,
              widgetCode: "PureFlexLayout$1"
            },
            COaIJNjL: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "COaIJNjL",
              title: "\u4EFB\u52A1\u5217\u8868",
              titleAlign: "left",
              tableColumnHeaderStyle: { borderTheme: "divisionLine" },
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              fullscreen: true,
              searchExpandCollapse: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              btnsGroups: [
                { title: "\u66F4\u591A", id: "zHeGCCgL", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "qugPiGsY", type: "inlineBtns" }
              ],
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "xZnTZUOD",
                  show: "visible",
                  type: "detail",
                  groupId: "qugPiGsY"
                }
              ],
              widgetCode: "NormalTable$3",
              columns: [
                {
                  dataIndex: "task_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  fixed: "left",
                  widgetId: "uIErKrDi",
                  widgetRef: "FormInput",
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "app_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  title: "\u6240\u5C5E\u5E94\u7528",
                  widgetId: "oRVsKpZK",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "task_type",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "tmGOSjEc",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u7C7B\u578B",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  editType: "0",
                  align: "left",
                  dataIndex: "status",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "showVal",
                  show: true,
                  showSortBtn: true,
                  width: "150px",
                  widgetId: "Pfudslgw",
                  widgetRef: "DropdownSelector",
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_user_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "KaLOIrmU",
                  widgetRef: "FormInput",
                  title: "\u64CD\u4F5C\u4EBA",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  align: "left",
                  dataIndex: "_hy_JIzyxbSF",
                  editable: false,
                  editableDataType: false,
                  fieldShowType: "realVal",
                  show: true,
                  configShow: true,
                  showSortBtn: false,
                  sortEditable: false,
                  width: "150px",
                  display: true,
                  title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
                  expId: "exp_ViNLSZjh",
                  widgetId: "JIzyxbSF",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  color: "#272727"
                },
                {
                  dataIndex: "exec_cost_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "sQemzVZh",
                  widgetRef: "FormInput",
                  title: "\u7ED3\u679C\u8017\u65F6",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "create_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "KqBXINay",
                  widgetRef: "FormDateTimePicker",
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "start_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "sorNVtVf",
                  widgetRef: "FormDateTimePicker",
                  title: "\u5F00\u59CB\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "end_exec_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  widgetId: "vhJyjEyf",
                  widgetRef: "FormDateTimePicker",
                  title: "\u7ED3\u675F\u65F6\u95F4",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              searchColumns: [
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u540D\u79F0",
                  columnName: "task_name",
                  widgetId: "esXkrdsk"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u6240\u5C5E\u5E94\u7528",
                  columnName: "app_code",
                  widgetId: "dhLoyaMQ"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u7C7B\u578B",
                  columnName: "task_type",
                  widgetId: "IDWpJvSL"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u4EFB\u52A1\u72B6\u6001",
                  columnName: "status",
                  widgetId: "SjNugpXB"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u64CD\u4F5C\u4EBA",
                  columnName: "create_user_name",
                  widgetId: "mkKClcry"
                },
                {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false,
                  title: "\u63D0\u4EA4\u65F6\u95F4",
                  columnName: "create_time",
                  widgetId: "rjSqeEgq"
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" },
                { fieldID: "id", title: "\u4E3B\u952E", sort: "asc" }
              ],
              tagKey: "",
              keyshow: false,
              ds: "1669609463667109888_list_1686900953519",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "remark",
                "output_file_param",
                "input_file_param",
                "progress",
                "result",
                "end_exec_time",
                "exec_cost_time",
                "start_exec_time",
                "status_des",
                "status",
                "business_name",
                "business_code",
                "task_name",
                "task_type",
                "app_code",
                "less_code",
                "last_update_time",
                "last_update_user_name",
                "last_update_user_id",
                "create_time",
                "create_user_name",
                "create_user_id",
                "id"
              ],
              relatedAppPage: {
                pageNameCn: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355",
                pageId: "1668512181710368769"
              }
            },
            UNUbMkmx: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "UNUbMkmx",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsProps: {
                esXkrdsk: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                dhLoyaMQ: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                IDWpJvSL: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                SjNugpXB: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                mkKClcry: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                },
                rjSqeEgq: {
                  span: { xs: 24, sm: 12, md: 8, lg: 6 },
                  blurSearch: false,
                  packUp: false
                }
              },
              colsPackUp: false,
              colsKeys: [
                "esXkrdsk",
                "dhLoyaMQ",
                "IDWpJvSL",
                "SjNugpXB",
                "mkKClcry",
                "rjSqeEgq"
              ],
              bodyInfo: [
                { id: "esXkrdsk", visible: true, widgetRef: "FormInput" },
                { id: "dhLoyaMQ", visible: true, widgetRef: "FormInput" },
                { id: "IDWpJvSL", visible: true, widgetRef: "DropdownSelector" },
                { id: "SjNugpXB", visible: true, widgetRef: "DropdownSelector" },
                { id: "mkKClcry", visible: true, widgetRef: "FormInput" },
                {
                  id: "rjSqeEgq",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                }
              ]
            },
            esXkrdsk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "esXkrdsk",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$13",
              field: "task_name",
              fieldInfo: null,
              fieldSearch: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              fieldColumn: null,
              stringLength: 512,
              searchMethod: "like"
            },
            dhLoyaMQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "dhLoyaMQ",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u6240\u5C5E\u5E94\u7528",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              fieldSearch: { field: "app_code", title: "\u5E94\u7528\u53F7" },
              field: "app_code",
              searchMethod: "like",
              widgetCode: "FormInput$25",
              columnName: "app_code"
            },
            IDWpJvSL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "IDWpJvSL",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u7C7B\u578B",
              options: { 1: "\u5F02\u6B65", 2: "\u5B9A\u65F6" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$5",
              field: "task_type",
              fieldInfo: null,
              fieldSearch: { field: "task_type", title: "\u4EFB\u52A1\u7C7B\u578B" },
              fieldColumn: null,
              stringLength: 128,
              searchMethod: "in",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636740939788288_1687861068583"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636740939788288_1687861068583",
                type: "dict"
              }
            },
            SjNugpXB: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "SjNugpXB",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$6",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              field: "status",
              fieldInfo: null,
              fieldSearch: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              fieldColumn: null,
              stringLength: 32,
              searchMethod: "in"
            },
            mkKClcry: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "mkKClcry",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u64CD\u4F5C\u4EBA",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$14",
              field: "create_user_name",
              fieldInfo: null,
              fieldSearch: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              fieldColumn: null,
              stringLength: 32,
              searchMethod: "like"
            },
            rjSqeEgq: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "rjSqeEgq",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u63D0\u4EA4\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$9",
              field: "create_time",
              fieldInfo: null,
              fieldSearch: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              fieldColumn: null,
              stringLength: 0,
              searchMethod: "like"
            },
            zHeGCCgL: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "zHeGCCgL",
              visible: true,
              customId: "COaIJNjL_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            qugPiGsY: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "qugPiGsY",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "COaIJNjL_inlineBtns",
              btnsConfig: [
                {
                  title: "\u4EFB\u52A1\u8BE6\u60C5",
                  widgetId: "xZnTZUOD",
                  show: "visible",
                  type: "detail",
                  groupId: "qugPiGsY"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            xZnTZUOD: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "xZnTZUOD",
              title: "\u4EFB\u52A1\u8BE6\u60C5",
              visible: true,
              disabled: false,
              iconType: "",
              style: { borderRadius: "0px", padding: "2px 4px", width: "auto" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              $lazyload: false,
              type: "link"
            },
            uIErKrDi: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "uIErKrDi",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 512,
              widgetCode: "FormInput$19",
              field: "task_name",
              fieldColumn: { field: "task_name", title: "\u4EFB\u52A1\u540D\u79F0" },
              $lazyload: false,
              columnName: "task_name"
            },
            oRVsKpZK: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "oRVsKpZK",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              widgetCode: "FormInput$21",
              field: "app_code",
              fieldColumn: { field: "app_code", title: "\u5E94\u7528\u53F7" },
              $lazyload: false,
              columnName: "app_code"
            },
            tmGOSjEc: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "tmGOSjEc",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: { 1: "\u5F02\u6B65", 2: "\u5B9A\u65F6" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$9",
              field: "task_type",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "task_type", title: "\u4EFB\u52A1\u7C7B\u578B" },
              stringLength: 128,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636740939788288_1687861068583"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636740939788288_1687861068583",
                type: "dict"
              },
              $lazyload: false,
              bodyContainer: true
            },
            Pfudslgw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "Pfudslgw",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                2: "\u90E8\u5206\u6210\u529F",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$10",
              field: "status",
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: { field: "status", title: "\u4EFB\u52A1\u72B6\u6001" },
              stringLength: 32,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              },
              $lazyload: false,
              bodyContainer: true
            },
            KaLOIrmU: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "KaLOIrmU",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$23",
              field: "create_user_name",
              fieldColumn: { field: "create_user_name", title: "\u521B\u5EFA\u4EBA\u540D\u79F0" },
              $lazyload: false,
              columnName: "create_user_name"
            },
            JIzyxbSF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              parseInReadOnly: true,
              id: "JIzyxbSF",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              checkByExp: [],
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              required: false,
              stringLength: 65535,
              widgetCode: "Textarea$1",
              field: null,
              linkage: null,
              fieldInfo: null,
              fieldSearch: null,
              $lazyload: false,
              columnName: "result"
            },
            sQemzVZh: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "sQemzVZh",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 128,
              widgetCode: "FormInput$24",
              field: "exec_cost_time",
              fieldColumn: { field: "exec_cost_time", title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F" },
              $lazyload: false,
              columnName: "exec_cost_time"
            },
            KqBXINay: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "KqBXINay",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$13",
              field: "create_time",
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              $lazyload: false,
              columnName: "create_time"
            },
            sorNVtVf: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "sorNVtVf",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$14",
              field: "start_exec_time",
              fieldColumn: { field: "start_exec_time", title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4" },
              $lazyload: false,
              columnName: "start_exec_time"
            },
            vhJyjEyf: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "vhJyjEyf",
              titleWeight: 400,
              labelColor: "#272727",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: { borderRadius: "0px" },
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              fontStyle: { color: "#272727" },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$15",
              field: "end_exec_time",
              fieldColumn: { field: "end_exec_time", title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6" },
              $lazyload: false,
              columnName: "end_exec_time"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            UkFlWeWJ: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "WjZLfFgH",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368769",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "srDADzya",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "WjZLfFgH",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "WjZLfFgH",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368769",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "srDADzya",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "WjZLfFgH",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            xZnTZUOD: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "COaIJNjL",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368769",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "MsyFzplL",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "COaIJNjL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "COaIJNjL",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1668512181710368769",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "MsyFzplL",
                                  pageNameCn: "\u8BE6\u60C5_\u5F02\u6B65\u4EFB\u52A1\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "COaIJNjL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "WkMFjWwG",
                  children: [
                    {
                      id: "QtRppnay",
                      children: [
                        {
                          id: "WjZLfFgH",
                          children: [
                            {
                              id: "RAkSSdjU",
                              children: [
                                {
                                  id: "GFfVCvAl",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "itFoXgVx",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "fgfeUzla",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "CaLZYbAH",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "ONJpnFjC",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            },
                            {
                              id: "WjZLfFgH_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "NhGmnWng",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "WjZLfFgH_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "SLbvwHKT",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "UkFlWeWJ",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "WjZLfFgH_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "hOFYmpGk",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "eMXvEySe",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "veaQzBze",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "PXAPwQRQ",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "etHbIpcj",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "bmhJTggs",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "FqMIhOqU",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "nenwcvZu",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "cfkYIVaw",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "UtqOSUVt",
                      children: [
                        {
                          id: "COaIJNjL",
                          children: [
                            {
                              id: "UNUbMkmx",
                              children: [
                                {
                                  id: "esXkrdsk",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "dhLoyaMQ",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "IDWpJvSL",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "SjNugpXB",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "mkKClcry",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "rjSqeEgq",
                                  children: [],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "zHeGCCgL",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "qugPiGsY",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "xZnTZUOD",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "COaIJNjL_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "uIErKrDi",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "oRVsKpZK",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "tmGOSjEc",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "Pfudslgw",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "KaLOIrmU",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "JIzyxbSF",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "sQemzVZh",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "KqBXINay",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "sorNVtVf",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                },
                                {
                                  id: "vhJyjEyf",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_lhyCSGsC: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  GFfVCvAl: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "GFfVCvAl",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_dZjUApQv: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  fgfeUzla: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "fgfeUzla",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_EvSTMHtn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  CaLZYbAH: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "CaLZYbAH",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cnerZHuV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ONJpnFjC: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ONJpnFjC",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_nkFvOeML: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  veaQzBze: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "veaQzBze",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_pxDnJIYZ: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  etHbIpcj: [
                    { path: "saveValV2", id: "etHbIpcj", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  WjZLfFgH: { "currentRow.result.saveValV2": { paramKey: "$0" } }
                }
              }
            },
            exp_zWBdpBGx: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  esXkrdsk: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "esXkrdsk",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_QOXOKxys: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  IDWpJvSL: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "IDWpJvSL",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_DJTgoFyU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  SjNugpXB: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "SjNugpXB",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_uOBxEnKD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  mkKClcry: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "mkKClcry",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_cobyKiOh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  rjSqeEgq: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "rjSqeEgq",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_AMSbnwny: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  tmGOSjEc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "tmGOSjEc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_WutUIDMi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  Pfudslgw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "Pfudslgw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ViNLSZjh: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  JIzyxbSF: [
                    { path: "saveValV2", id: "JIzyxbSF", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  COaIJNjL: { "currentRow.result.saveValV2": { paramKey: "$0" } }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_lhyCSGsC", type: "exp" },
                { id: "exp_dZjUApQv", type: "exp" },
                { id: "exp_EvSTMHtn", type: "exp" },
                { id: "exp_cnerZHuV", type: "exp" },
                { id: "exp_nkFvOeML", type: "exp" },
                { id: "exp_zWBdpBGx", type: "exp" },
                { id: "exp_QOXOKxys", type: "exp" },
                { id: "exp_DJTgoFyU", type: "exp" },
                { id: "exp_uOBxEnKD", type: "exp" },
                { id: "exp_cobyKiOh", type: "exp" },
                { id: "exp_AMSbnwny", type: "exp" },
                { id: "exp_WutUIDMi", type: "exp" }
              ]
            },
            widget: {
              WjZLfFgH: {
                "currentRow.result.saveValV2": [
                  { id: "exp_pxDnJIYZ", type: "exp" }
                ]
              },
              COaIJNjL: {
                "currentRow.result.saveValV2": [
                  { id: "exp_ViNLSZjh", type: "exp" }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$WkMFjWwG`,
            key: `PC$$WkMFjWwG`,
            pageCtx,
            widgetRef: "TabContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$WkMFjWwG$$QtRppnay`,
              key: `PC$$WkMFjWwG$$QtRppnay`,
              pageCtx,
              widgetRef: "PureFlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH`,
                key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$NhGmnWng`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$NhGmnWng`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromWjZLfFgH, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$SLbvwHKT`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$SLbvwHKT`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$SLbvwHKT$$UkFlWeWJ`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$SLbvwHKT$$UkFlWeWJ`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromWjZLfFgH }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$hOFYmpGk`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$hOFYmpGk`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$eMXvEySe`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$eMXvEySe`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$veaQzBze`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$veaQzBze`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$PXAPwQRQ`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$PXAPwQRQ`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$etHbIpcj`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$etHbIpcj`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$bmhJTggs`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$bmhJTggs`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$FqMIhOqU`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$FqMIhOqU`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$nenwcvZu`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$nenwcvZu`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$cfkYIVaw`,
                      key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$%${indexFromWjZLfFgH}%$$cfkYIVaw`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU`,
                  key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$GFfVCvAl`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$GFfVCvAl`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$itFoXgVx`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$itFoXgVx`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$fgfeUzla`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$fgfeUzla`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$CaLZYbAH`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$CaLZYbAH`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$ONJpnFjC`,
                    key: `PC$$WkMFjWwG$$QtRppnay$$WjZLfFgH$$RAkSSdjU$$ONJpnFjC`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                )
              )
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$WkMFjWwG$$UtqOSUVt`,
              key: `PC$$WkMFjWwG$$UtqOSUVt`,
              pageCtx,
              widgetRef: "PureFlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL`,
                key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$zHeGCCgL`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$zHeGCCgL`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromCOaIJNjL, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY$$xZnTZUOD`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$qugPiGsY$$xZnTZUOD`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromCOaIJNjL }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$uIErKrDi`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$uIErKrDi`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$oRVsKpZK`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$oRVsKpZK`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$tmGOSjEc`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$tmGOSjEc`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$Pfudslgw`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$Pfudslgw`,
                      pageCtx,
                      widgetRef: "DropdownSelector"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$KaLOIrmU`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$KaLOIrmU`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$JIzyxbSF`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$JIzyxbSF`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$sQemzVZh`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$sQemzVZh`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$KqBXINay`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$KqBXINay`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$sorNVtVf`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$sorNVtVf`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$vhJyjEyf`,
                      key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$%${indexFromCOaIJNjL}%$$vhJyjEyf`,
                      pageCtx,
                      widgetRef: "FormDateTimePicker"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx`,
                  key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$esXkrdsk`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$esXkrdsk`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$dhLoyaMQ`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$dhLoyaMQ`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$IDWpJvSL`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$IDWpJvSL`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$SjNugpXB`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$SjNugpXB`,
                    pageCtx,
                    widgetRef: "DropdownSelector"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$mkKClcry`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$mkKClcry`,
                    pageCtx,
                    widgetRef: "FormInput"
                  }
                ),
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$rjSqeEgq`,
                    key: `PC$$WkMFjWwG$$UtqOSUVt$$COaIJNjL$$UNUbMkmx$$rjSqeEgq`,
                    pageCtx,
                    widgetRef: "FormDateTimePicker"
                  }
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1668504044102103041, "pageName", "\u79DF\u6237\u7EA7\u4EFB\u52A1\u4E2D\u5FC3");
  __publicField(Page1668504044102103041, "$pageKey", "ZoCLtqHY");
  __publicField(Page1668504044102103041, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
