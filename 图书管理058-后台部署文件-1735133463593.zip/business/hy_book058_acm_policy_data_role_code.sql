CREATE TABLE IF NOT EXISTS `hy_book058_acm_policy_data_role_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subject_value` varchar(32) NOT NULL,
  `resource_value` varchar(32) NOT NULL,
  `res_type` varchar(32) DEFAULT NULL,
  `bit_code` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
