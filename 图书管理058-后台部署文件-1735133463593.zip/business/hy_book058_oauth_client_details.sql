CREATE TABLE IF NOT EXISTS `hy_book058_oauth_client_details` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `autoapprove` text COMMENT '设置用户是否自动Approval操作',
  `authorized_grant_types` text COMMENT '客户端支持的grant_type',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `client_id` varchar(255) NOT NULL COMMENT '客户端主键',
  `authorities` text COMMENT '客户端所拥有的权限值',
  `refresh_token_validity` int(9) DEFAULT NULL COMMENT '客户端refresh_token_validity的有效期',
  `additional_information` mediumtext COMMENT '这是一个预留的字段',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `access_token_validity` int(9) DEFAULT NULL COMMENT '客户端的access_token的有效时间值',
  `scope` text COMMENT '客户端申请的权限范围',
  `web_server_redirect_uri` text COMMENT '客户端的重定向URI',
  `client_secret` text COMMENT '用于指定客户端(client)的访问密匙',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `resource_ids` text COMMENT '客户端所能访问的资源id集合',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_nOzdv7rC` (`client_id`) USING BTREE,
  KEY `idx_dSyANIyA` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='oauth客户端信息表';
INSERT IGNORE INTO `hy_book058_oauth_client_details` (`create_user_id`,`create_user_name`,`create_time`,`data_version`,`autoapprove`,`authorized_grant_types`,`last_update_user_id`,`client_id`,`authorities`,`refresh_token_validity`,`additional_information`,`last_update_time`,`sequence`,`access_token_validity`,`scope`,`web_server_redirect_uri`,`client_secret`,`id`,`resource_ids`,`last_update_user_name`) VALUES ('1295915065878388737',null,'2022-05-07 13:56:41.0','1','false','password,client_credentials,refresh_token,all_custom','1295915065878388737','client_hy_web','oauth2',null,null,'2022-05-07 13:56:41.0','2','3600','all',null,'3LfsJMVt/chTqNgo85Gl/w==','1522817678769795072','hy_res_sdk,hy_auth_center,hy_saas',null);
###end_paragraph
