CREATE TABLE IF NOT EXISTS `hy_book058_page_structure_pea` (
  `id` bigint(20) NOT NULL,
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `api_id` varchar(128) NOT NULL COMMENT '使用到的事件api(code)',
  `event_id` decimal(20,0) NOT NULL COMMENT '所属事件ID',
  `page_id` decimal(20,0) NOT NULL COMMENT '所属页面',
  `original_page_id` varchar(32) NOT NULL COMMENT '入参页面id',
  PRIMARY KEY (`id`),
  KEY `idx_ja4lnjfvdp` (`create_time`) USING BTREE,
  KEY `idx_xyxcvzvseh` (`sequence`) USING BTREE,
  KEY `idx_pea_delete` (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='页面事件api关系';
