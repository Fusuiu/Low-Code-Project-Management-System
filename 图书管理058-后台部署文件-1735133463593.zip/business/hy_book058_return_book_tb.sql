CREATE TABLE IF NOT EXISTS `hy_book058_return_book_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `return_book_date` datetime DEFAULT NULL COMMENT '还书时间',
  `return_book_name` varchar(32) DEFAULT NULL COMMENT '还书书名',
  `return_book_people` varchar(32) DEFAULT NULL COMMENT '还书人',
  `return_book_code` varchar(32) DEFAULT NULL COMMENT '还书编号',
  `return_book_state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_return_book_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  PRIMARY KEY (`id`),
  KEY `idx_txdil1ccik` (`create_time`) USING BTREE,
  KEY `idx_jcy6h3dkl5` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COMMENT='还书表';
INSERT IGNORE INTO `hy_book058_return_book_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`return_book_date`,`return_book_name`,`return_book_people`,`return_book_code`,`return_book_state`,`_return_book_statename`) VALUES ('1865640820945190913','0','1','诸葛亮','2024-12-08 14:13:28.0','1','诸葛亮','2024-12-08 14:13:28.0','49','2024-12-08 14:13:28.0','三国演义','admin','B2412080007',null,null),('1868872156496228353','0','1','诸葛亮','2024-12-17 12:13:39.0','1','诸葛亮','2024-12-17 12:13:39.0','50','2024-12-17 12:13:38.0','俗世奇人','admin','B2412082020',null,null);
###end_paragraph
