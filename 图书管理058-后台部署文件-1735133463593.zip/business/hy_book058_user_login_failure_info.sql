CREATE TABLE IF NOT EXISTS `hy_book058_user_login_failure_info` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `login_failure_count` bigint(11) DEFAULT NULL COMMENT '登录失败次数',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `user_id` decimal(20,0) NOT NULL COMMENT '用户主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `login_time` datetime DEFAULT NULL COMMENT '登录时间',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_EpYE4zm0` (`user_id`) USING BTREE,
  KEY `idx_bZnGkOiD` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户登录失败信息表';
