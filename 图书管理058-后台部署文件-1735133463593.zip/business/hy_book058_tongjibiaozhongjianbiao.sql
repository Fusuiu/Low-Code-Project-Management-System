CREATE TABLE IF NOT EXISTS `hy_book058_tongjibiaozhongjianbiao` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `book_type` varchar(32) DEFAULT NULL COMMENT '图书分类',
  `book_code` varchar(32) DEFAULT NULL COMMENT '图书编号',
  `book_name` varchar(128) DEFAULT NULL COMMENT '图书名称',
  `borrow_code` varchar(32) DEFAULT NULL COMMENT '借书编号',
  `borrow_date` datetime DEFAULT NULL COMMENT '借书时间',
  PRIMARY KEY (`id`),
  KEY `idx_ngw9f3equt` (`create_time`) USING BTREE,
  KEY `idx_2pqfwswx8a` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=707 DEFAULT CHARSET=utf8 COMMENT='统计表中间表';
INSERT IGNORE INTO `hy_book058_tongjibiaozhongjianbiao` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`book_type`,`book_code`,`book_name`,`borrow_code`,`borrow_date`) VALUES ('1865696376937529345','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','697','TY004','11','俗世奇人','B2412082012','2024-12-08 17:45:07.0'),('1865696376937529346','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','698','TY002','10','史记','B2412082013','2024-12-08 17:45:08.0'),('1865696376937529347','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','699','TY004','8','平凡的世界','B2412080021','2024-12-08 17:53:54.0'),('1865696376937529348','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','700','TY004','6','聊斋志异','B2412081010','2024-12-08 17:53:55.0'),('1865696376937529349','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','701','TY004','4','三国演义','B2412081011','2024-12-08 17:53:56.0'),('1865696376937529350','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','702','TY004','3','红楼梦','B2412082014','2024-12-08 17:53:57.0'),('1865696376937529351','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','703','TY004','2','水浒传','B2412082015','2024-12-08 17:53:57.0'),('1865696376937529352','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','704','TY004','11','俗世奇人','B2412082016','2024-12-08 17:53:58.0'),('1865696376937529353','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','705','TY004','1','西游记',null,null),('1865696376937529354','0','1','诸葛亮','2024-12-08 17:54:14.0','1','诸葛亮','2024-12-08 17:54:14.0','706','TY002','5','资治通鉴',null,null);
###end_paragraph
