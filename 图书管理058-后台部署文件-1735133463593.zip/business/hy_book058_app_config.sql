CREATE TABLE IF NOT EXISTS `hy_book058_app_config` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `cfg_key` varchar(100) DEFAULT NULL COMMENT 'cfg_key',
  `cfg_val` varchar(200) DEFAULT NULL COMMENT 'cfg_val',
  `cfg_desc` varchar(200) DEFAULT NULL COMMENT '描述信息',
  `cfg_type` bigint(11) DEFAULT NULL COMMENT 'cfg_type',
  `cfg_name` varchar(200) DEFAULT NULL COMMENT 'cfg_name',
  `sys_default` tinyint(1) DEFAULT NULL COMMENT '是否系统默认 1：是 0：否',
  `cfg_val_type` varchar(32) DEFAULT NULL COMMENT '配置值类型',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_4o2viklqbj` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COMMENT='app_config';
INSERT IGNORE INTO `hy_book058_app_config` (`create_user_id`,`last_update_time`,`sequence`,`create_user_name`,`create_time`,`data_version`,`id`,`last_update_user_id`,`last_update_user_name`,`cfg_key`,`cfg_val`,`cfg_desc`,`cfg_type`,`cfg_name`,`sys_default`,`cfg_val_type`) VALUES ('1','2022-11-21 14:26:16.0','18','admin','2022-11-21 14:26:16.0','0','7','1','admin','user_share_switch','1','用户分享开关，0-关，1-开','1','用户分享开关','1','1'),('1','2024-12-04 14:27:32.0','10',null,'2023-05-17 19:01:46.0','0','8','1863895470333386755','LG058','APP_NAME','图书管理058符家峻','支持修改当前应用名称','1','应用名称','1','1'),('1','2024-12-04 14:27:32.0','19',null,'2023-03-07 10:55:55.0','0','1632938094510616576','1863895470333386755','LG058','appLogoPic','null','支持修改当前应用logo','1','应用logo','1','1'),('1','2024-02-21 16:36:42.0','20',null,'2023-03-07 10:55:55.0','0','1632938094510656555','1295915065878388737','hy','saas_acm_switch','1','新版本权限开关，0-关，1-开','1','新版本权限开关','0','0'),('1','2024-03-27 09:23:38.0','53',null,'2024-03-07 10:55:55.0','0','1632938094510765439','1','admin','sysdevAsyncApiInvokeDelay','300','api异步调用延迟执行时间上限','3','api异步调用延迟执行时间上限','1','1');
###end_paragraph
