CREATE TABLE IF NOT EXISTS `hy_book058_app_sys_backup_group` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `code` varchar(32) DEFAULT NULL COMMENT '备份编号',
  `process` varchar(10) DEFAULT NULL COMMENT '进度完成率',
  `status` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statusname` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `source_id` varchar(32) DEFAULT NULL COMMENT '数据源主键',
  `file_path` text COMMENT '文件路径',
  `task_type` varchar(32) DEFAULT NULL COMMENT '任务类型',
  `_task_typename` varchar(32) DEFAULT NULL COMMENT '任务类型显示值',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_jdrn6nzd2e` (`create_time`) USING BTREE,
  KEY `idx_b8xcanpzvf` (`sequence`) USING BTREE,
  KEY `idx_iagcntd7a4` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='应用系统备份记录主表';
INSERT IGNORE INTO `hy_book058_app_sys_backup_group` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`code`,`process`,`status`,`_statusname`,`end_time`,`source_id`,`file_path`,`task_type`,`_task_typename`) VALUES ('1627519110630903809','1','1','admin','2023-03-25 20:43:41.0','1','admin','2023-03-25 20:43:41.0','2','master','100.00','2','成功','2023-03-25 20:44:17.0',null,null,null,null);
###end_paragraph
