CREATE TABLE IF NOT EXISTS `hy_book058_bizgw_plugin_driver_business_cfg` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `address` varchar(200) DEFAULT NULL COMMENT '目标服务静态地址',
  `bus_cfg_key` varchar(32) DEFAULT NULL COMMENT '业务配置标识',
  `bus_cfg_name` varchar(32) DEFAULT NULL COMMENT '业务配置名称',
  `bus_cfg_desc` varchar(200) DEFAULT NULL,
  `create_user_id` decimal(20,0) DEFAULT NULL COMMENT '创建人主键',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL DEFAULT '0' COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `data_version` varchar(32) DEFAULT NULL COMMENT '数据版本',
  `last_update_user_id` decimal(20,0) DEFAULT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `quote_lessee` tinyint(1) DEFAULT NULL COMMENT '是否是覆盖自租户 1：是 0：否',
  `sys_default` tinyint(1) DEFAULT NULL COMMENT '是否系统默认 1：是 0：否',
  `bus_cfg_type` varchar(32) DEFAULT NULL COMMENT '业务配置类型',
  `address_type` varchar(32) DEFAULT NULL COMMENT '业务配置值类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用参数表';
INSERT IGNORE INTO `hy_book058_bizgw_plugin_driver_business_cfg` (`id`,`address`,`bus_cfg_key`,`bus_cfg_name`,`bus_cfg_desc`,`create_user_id`,`last_update_time`,`sequence`,`create_user_name`,`create_time`,`data_version`,`last_update_user_id`,`last_update_user_name`,`quote_lessee`,`sys_default`,`bus_cfg_type`,`address_type`) VALUES ('1683726540963196928','0','faceLoginEnabled','人脸认证--启用状态','1为开启；0为关闭','1543883730203062289','2023-07-25 14:35:00.0','0','hy','2023-07-25 14:35:00.0','1.0','1543883730203062289','hy','0','1','1','1'),('1683726658361765888','2','faceLoginCaptureInterval','人脸认证--捕获间隔（秒）','参数值类型为正整数，最小为1','1543883730203062289','2023-07-25 14:31:32.0','0','hy','2023-07-25 14:31:32.0','1.0','1543883730203062289','hy','0','1','1','1'),('1683726776116850688','8','faceLoginPopInterval','人脸认证--报错间隔（秒）','参数值类型为正整数，不小于1','1543883730203062289','2023-07-25 14:32:00.0','0','hy','2023-07-25 14:32:00.0','1.0','1543883730203062289','hy','0','1','1','1'),('1683726880970256384','0','faceLoginAutoRetry','人脸认证--重试方式','1为自动重试；0为手动重试','1543883730203062289','2023-07-25 14:32:25.0','0','hy','2023-07-25 14:32:25.0','1.0','1543883730203062289','hy','0','1','1','1'),('1715650057845485568','0','saas_api_operation_log_switch','系统日志开关','saas的API操作日志开关，0-关，1-开，默认关','1295915065878388737','2023-10-23 21:25:38.0','0','hy','2023-10-21 16:43:44.0','0','1','admin','0','1','3','1');
###end_paragraph
