CREATE TABLE IF NOT EXISTS `hy_book058_table_style_attribute_whole` (
  `fid` decimal(20,0) NOT NULL COMMENT '外键',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `name` varchar(32) DEFAULT NULL COMMENT '属性名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `content` text COMMENT '内容',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_y61AtOkR` (`fid`) USING BTREE,
  KEY `idx_rnupol1yl0` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='表格样式附属表_整体';
INSERT IGNORE INTO `hy_book058_table_style_attribute_whole` (`fid`,`create_user_id`,`last_update_time`,`sequence`,`create_time`,`create_user_name`,`data_version`,`name`,`id`,`last_update_user_id`,`content`,`last_update_user_name`) VALUES ('1864652186519601153','1','2024-12-05 20:44:59.0','4','2024-12-05 20:44:59.0','admin','0','columnsDataSort','1864652186565738497','1','[{\"field\":\"book_date\"}]','admin'),('1865632267143495681','1','2024-12-08 13:39:29.0','8','2024-12-08 13:39:29.0','诸葛亮','0','columnsDataSort','1865632267185438721','1','[{\"field\":\"borrow_code\"}]','诸葛亮'),('1865688293533286401','1','2024-12-08 17:22:07.0','9','2024-12-08 17:22:07.0','诸葛亮','0','columnsDataSort','1865688293579423745','1','[{\"field\":\"tongjiyuefen\",\"order\":\"asc\",\"multiple\":1}]','诸葛亮');
###end_paragraph
