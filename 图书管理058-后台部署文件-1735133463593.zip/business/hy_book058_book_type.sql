CREATE TABLE IF NOT EXISTS `hy_book058_book_type` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `type_code` varchar(32) DEFAULT NULL COMMENT '分类编号',
  `type_name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `type_explain` longtext COMMENT '分类说明',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lt3wlehaq8` (`type_code`),
  KEY `idx_mdspaib5bk` (`create_time`) USING BTREE,
  KEY `idx_onmkgoorws` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='图书分类管理';
INSERT IGNORE INTO `hy_book058_book_type` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`type_code`,`type_name`,`type_explain`,`state`,`_statename`) VALUES ('1864215827590725633','0','1','admin','2024-12-04 15:51:03.0','1','admin','2024-12-04 15:51:03.0','1','TY001','计算机类',null,'1','启用'),('1864216454452756481','0','1','admin','2024-12-04 15:53:33.0','1','admin','2024-12-04 16:25:11.0','2','TY002','历史类',null,'1','启用'),('1864224601901891585','0','1','admin','2024-12-04 16:25:55.0','1','admin','2024-12-04 16:25:55.0','3','TY003','哲学类',null,'1','启用'),('1864295197474029569','0','1','admin','2024-12-04 21:06:27.0','1','admin','2024-12-04 21:06:27.0','7','TY004','文学类',null,'1','启用'),('1864301577156182017','0','1','admin','2024-12-04 21:31:48.0','1','诸葛亮','2024-12-08 17:12:08.0','10','q1','q1','q1','0','禁用'),('1864301612930433025','0','1','admin','2024-12-04 21:31:56.0','1','admin','2024-12-05 11:48:19.0','11','q2','q2',null,'0','禁用'),('1864486592918847489','0','1','admin','2024-12-05 09:46:59.0','1','admin','2024-12-05 15:57:37.0','12','123','332323',null,'0','禁用');
###end_paragraph
