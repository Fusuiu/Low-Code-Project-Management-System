CREATE TABLE IF NOT EXISTS `hy_book058_gis_baseinfo` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `center` varchar(256) DEFAULT NULL COMMENT '中心点坐标',
  `zoom` decimal(8,2) DEFAULT NULL COMMENT '缩放比',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `mapurl` varchar(512) DEFAULT NULL COMMENT '地图地址',
  `disabled` int(8) DEFAULT NULL COMMENT '是否禁用(1是0否)',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`),
  KEY `idx_zywdvb4w` (`sequence`) USING BTREE,
  KEY `idx_7ncgtyus` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='GIS地图基本信息表';
