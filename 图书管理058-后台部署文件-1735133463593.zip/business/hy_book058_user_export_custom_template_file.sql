CREATE TABLE IF NOT EXISTS `hy_book058_user_export_custom_template_file` (
  `id` bigint(20) NOT NULL,
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `template_file_name` varchar(255) DEFAULT NULL COMMENT '模板名称',
  `original_template_id` decimal(20,0) DEFAULT NULL COMMENT '源模板id',
  `control_unique_code` varchar(255) DEFAULT NULL COMMENT '控件唯一标识',
  `user_code` varchar(255) DEFAULT NULL COMMENT '用户标识',
  `custom_export_cell_content` text COMMENT '自定义内容',
  PRIMARY KEY (`id`),
  KEY `idx_vhnehwp4tb` (`create_time`) USING BTREE,
  KEY `idx_jcdtw5nqzy` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='内置_自定义导出模板关联表';
