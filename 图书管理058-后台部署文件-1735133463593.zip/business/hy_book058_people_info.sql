CREATE TABLE IF NOT EXISTS `hy_book058_people_info` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `people_code` varchar(32) DEFAULT NULL COMMENT '学号',
  `people_name` varchar(32) DEFAULT NULL COMMENT '姓名',
  `people_class` varchar(32) DEFAULT NULL COMMENT '班级',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ric4ms2vwi` (`people_code`),
  KEY `idx_a7c6yiwwpd` (`create_time`) USING BTREE,
  KEY `idx_xptza0wxnl` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='借书人员信息表';
INSERT IGNORE INTO `hy_book058_people_info` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`people_code`,`people_name`,`people_class`) VALUES ('1864876391688323073','0','1','admin','2024-12-06 11:35:54.0','1','admin','2024-12-06 11:36:07.0','2','R001','曹操','软件1班'),('1864876625194647553','0','1','admin','2024-12-06 11:36:50.0','1','admin','2024-12-06 11:36:50.0','3','R002','刘备','软工1班'),('1864876722274975745','0','1','admin','2024-12-06 11:37:13.0','1','admin','2024-12-06 11:37:13.0','4','R003','孙权','软工2班'),('1864878686708482049','0','1','admin','2024-12-06 11:45:01.0','1','诸葛亮','2024-12-06 12:50:49.0','5','admin','诸葛','软件2班'),('1864936867419930625','0','1','诸葛亮','2024-12-06 15:36:13.0','1','诸葛亮','2024-12-06 15:36:13.0','6','R-1001','张飞','软件4班'),('1864936957920428033','0','1','诸葛亮','2024-12-06 15:36:34.0','1','诸葛亮','2024-12-06 15:36:34.0','7','R-1002','董卓','软件5班'),('1864937053202432001','0','1','诸葛亮','2024-12-06 15:36:57.0','1','诸葛亮','2024-12-06 15:36:57.0','8','R-1003','袁绍','软件1班'),('1864949998998257665','0','1','诸葛亮','2024-12-06 16:28:24.0','1','诸葛亮','2024-12-06 16:28:24.0','9','R-0002','帆帆','软工3班');
###end_paragraph
