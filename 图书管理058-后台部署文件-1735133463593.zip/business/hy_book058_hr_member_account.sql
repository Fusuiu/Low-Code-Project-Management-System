CREATE TABLE IF NOT EXISTS `hy_book058_hr_member_account` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `account_name` varchar(32) DEFAULT NULL COMMENT '账号name',
  `hr_member_code` varchar(32) DEFAULT NULL COMMENT '人员code',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_nmyyrhkjdu` (`account_name`) USING BTREE,
  KEY `idx_n4yypozbk4` (`hr_member_code`) USING BTREE,
  KEY `idx_a617LqEO` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='人员账户关联表';
