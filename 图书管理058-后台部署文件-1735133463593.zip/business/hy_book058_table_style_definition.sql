CREATE TABLE IF NOT EXISTS `hy_book058_table_style_definition` (
  `page_id` decimal(20,0) DEFAULT NULL COMMENT '页面主键',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `widget_id` varchar(100) DEFAULT NULL COMMENT '控件主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `user_id` decimal(20,0) NOT NULL COMMENT '用户主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_u6kb2sj3v9` (`sequence`) USING BTREE,
  KEY `hy_8test8_table_style_definition_user_id_IDX` (`user_id`,`widget_id`,`page_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='表格样式主表';
INSERT IGNORE INTO `hy_book058_table_style_definition` (`page_id`,`create_user_id`,`last_update_time`,`sequence`,`widget_id`,`create_time`,`create_user_name`,`user_id`,`data_version`,`id`,`last_update_user_id`,`last_update_user_name`) VALUES ('1864279052637855744','1','2024-12-05 20:44:59.0','4','ecGqNwtU','2024-12-05 20:44:59.0','admin','1','0','1864652186519601153','1','admin'),('1864837783213727744','1','2024-12-08 13:39:29.0','8','OSdXpgbs','2024-12-08 13:39:29.0','诸葛亮','1','0','1865632267143495681','1','诸葛亮'),('1865684065285201920','1','2024-12-08 17:22:07.0','9','mUgNKaME','2024-12-08 17:22:07.0','诸葛亮','1','0','1865688293533286401','1','诸葛亮');
###end_paragraph
