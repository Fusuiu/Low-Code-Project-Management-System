CREATE TABLE IF NOT EXISTS `hy_book058_acm_widget_api_relation` (
  `create_user_id` decimal(20,0) DEFAULT NULL COMMENT '创建人主键',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) DEFAULT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) DEFAULT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `widget_id` varchar(32) DEFAULT NULL COMMENT '控件id',
  `api_code` varchar(128) DEFAULT NULL COMMENT 'api编码',
  `authority_code` varchar(32) DEFAULT NULL COMMENT '权限项编码',
  `page_info_id` decimal(20,0) DEFAULT NULL COMMENT '页面主键',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_aa0gbmvw3d` (`api_code`) USING BTREE,
  KEY `idx_pokdcl5lst` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限项控件与api关联关系表';
