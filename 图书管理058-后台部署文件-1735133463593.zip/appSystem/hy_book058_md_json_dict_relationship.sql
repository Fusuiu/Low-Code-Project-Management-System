DROP TABLE IF EXISTS `hy_book058_md_json_dict_relationship`;
CREATE TABLE IF NOT EXISTS `hy_book058_md_json_dict_relationship` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `ref_table_name` varchar(32) DEFAULT NULL COMMENT '关联表表名',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `business_code` varchar(64) DEFAULT NULL COMMENT '字典业务编码',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `dynamic_field_id` decimal(20,0) NOT NULL COMMENT '动态字段表主键',
  `condition_content` varchar(64) DEFAULT NULL COMMENT '条件内容',
  `ref_table_id` decimal(20,0) DEFAULT NULL COMMENT '字典关联主键',
  `business_name` varchar(100) DEFAULT NULL COMMENT '字典业务名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_6ikjdugmnh` (`business_code`) USING BTREE,
  KEY `idx_qlwpcijp4f` (`sequence`) USING BTREE,
  KEY `idx_uog2n7lfog` (`ref_table_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='JSON字典关联表';
