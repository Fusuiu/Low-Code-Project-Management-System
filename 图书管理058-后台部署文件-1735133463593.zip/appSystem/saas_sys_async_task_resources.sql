CREATE TABLE IF NOT EXISTS `saas_sys_async_task_resources` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `lessee_code` varchar(100) DEFAULT NULL COMMENT '租户编码',
  `app_code` varchar(100) DEFAULT NULL COMMENT '应用编码',
  `type` tinyint(4) NOT NULL COMMENT '类型：0平台级，1租户级、2应用级',
  `enable` tinyint(4) DEFAULT '1' COMMENT '数据源启用状态：0禁用，1启用',
  `timeout` int(11) DEFAULT '120' COMMENT '任务超时时长 秒',
  `priority` int(11) DEFAULT '1' COMMENT '应用间的任务优先级',
  `pool_core_size` int(11) DEFAULT '0' COMMENT '线程池核心线程数量，0使用平台内置',
  `concurrent_num` int(11) DEFAULT '1' COMMENT '并发量',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='saas异步任务资源分配表';
