DROP TABLE IF EXISTS `hy_book058_verification_rule`;
CREATE TABLE IF NOT EXISTS `hy_book058_verification_rule` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `rule_name` varchar(128) NOT NULL COMMENT '规则名称',
  `desc` text COMMENT '描述',
  `rule_type` varchar(10) NOT NULL COMMENT '规则类型',
  `sheet` varchar(128) NOT NULL COMMENT '工作表名/sheet页名称',
  `if_db_compare` tinyint(4) DEFAULT '0' COMMENT '是否数据库比对，0否，1是',
  `express` varchar(255) NOT NULL COMMENT '条件组合表达式 (1 and 2 and 3)',
  `create_user_name` varchar(255) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `template_id` varchar(32) NOT NULL COMMENT '模板id',
  `execution_strategy` tinyint(4) DEFAULT NULL COMMENT '执行策略',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='校验规则表';
