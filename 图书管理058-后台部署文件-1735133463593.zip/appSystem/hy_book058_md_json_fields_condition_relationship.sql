DROP TABLE IF EXISTS `hy_book058_md_json_fields_condition_relationship`;
CREATE TABLE IF NOT EXISTS `hy_book058_md_json_fields_condition_relationship` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `fields_condition_id` decimal(20,0) NOT NULL COMMENT 'JSON字段条件主键',
  `dynamic_field_id` decimal(20,0) NOT NULL COMMENT '动态字段主键',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_condition_field_unique` (`fields_condition_id`,`dynamic_field_id`) USING BTREE,
  KEY `idx_t40ah9g5dk` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='JSON字段条件关联表';
