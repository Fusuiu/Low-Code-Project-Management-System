DROP TABLE IF EXISTS `hy_book058_auth_sys_log_custom_handle`;
CREATE TABLE IF NOT EXISTS `hy_book058_auth_sys_log_custom_handle` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `script` mediumtext COMMENT 'script',
  `uri` varchar(512) DEFAULT NULL COMMENT '请求地址',
  `enable` int(8) DEFAULT '1' COMMENT '是否启用',
  `description` varchar(512) DEFAULT NULL COMMENT '备注描述',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_ppjd8fjbq1` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='认证中心日志自定义处理配置表';
INSERT IGNORE INTO `hy_book058_auth_sys_log_custom_handle` (`create_user_id`,`last_update_time`,`sequence`,`create_user_name`,`create_time`,`data_version`,`id`,`last_update_user_id`,`last_update_user_name`,`script`,`uri`,`enable`,`description`) VALUES ('1','2022-06-06 13:59:15.0','2',null,'2022-06-06 13:59:19.0','1','12345678','1',null,'return true;','/*','1','登录日志处理,登出日志处理和修改密码日志处理');
###end_paragraph
