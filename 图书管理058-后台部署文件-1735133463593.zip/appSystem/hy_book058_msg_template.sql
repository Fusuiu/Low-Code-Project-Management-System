DROP TABLE IF EXISTS `hy_book058_msg_template`;
CREATE TABLE IF NOT EXISTS `hy_book058_msg_template` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `remark` varchar(255) DEFAULT NULL COMMENT '描述',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `jump_address_mode` varchar(32) DEFAULT NULL COMMENT '跳转地址方式',
  `content` tinytext COMMENT '内容',
  `template_code` varchar(32) NOT NULL COMMENT '模板编码',
  `page_id` decimal(20,0) DEFAULT NULL COMMENT '页面主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `module_id` decimal(20,0) DEFAULT NULL COMMENT '所属模块',
  `_redirect_url_typename` varchar(32) DEFAULT NULL COMMENT '跳转地址类型显示值',
  `name` varchar(64) NOT NULL COMMENT '模板名称',
  `redirect_url_type` varchar(32) DEFAULT 'IN_SYS' COMMENT '跳转地址类型',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `redirect_url` varchar(255) DEFAULT NULL COMMENT '跳转地址',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_hjg4Vh09` (`template_code`) USING BTREE,
  KEY `idx_stllhh7tcq` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='消息模板表';
INSERT IGNORE INTO `hy_book058_msg_template` (`create_user_id`,`create_time`,`create_user_name`,`data_version`,`remark`,`last_update_user_id`,`title`,`jump_address_mode`,`content`,`template_code`,`page_id`,`last_update_time`,`sequence`,`module_id`,`_redirect_url_typename`,`name`,`redirect_url_type`,`id`,`redirect_url`,`last_update_user_name`) VALUES ('1295915065878388737','2021-11-11 15:35:26.0',null,'1','系统公告模板','1295915065878388737','[系统公告]{title}','current',null,'SYS_NOTICE',null,'2021-12-04 14:03:49.0','17','1455708066640179200',null,'系统公告模板','IN_SYS','1458699873091203072','1466676114599587840',null),('1458718934428692480','2021-11-16 14:53:36.0',null,'1','流程提醒','1295915065878388737','[流程提醒]{title}','current',null,'FLOW',null,'2021-11-23 19:57:02.0','21','1455708066640179200',null,'流程提醒','IN_SYS','1460501284581945344','1402508584880844800',null);
###end_paragraph
