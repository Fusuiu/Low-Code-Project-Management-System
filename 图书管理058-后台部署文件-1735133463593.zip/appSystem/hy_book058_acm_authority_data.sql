DROP TABLE IF EXISTS `hy_book058_acm_authority_data`;
CREATE TABLE IF NOT EXISTS `hy_book058_acm_authority_data` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(32) NOT NULL COMMENT '权限名称',
  `code` varchar(32) NOT NULL COMMENT '权限编码',
  `desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `api_key` varchar(128) NOT NULL COMMENT 'Api信息标识，保存busmodel_api_metadata表的business_code',
  `permission_type` varchar(16) NOT NULL COMMENT '权限类型,(field字段权限;data数据权限)',
  `item_type` varchar(32) NOT NULL COMMENT '权限项类型（sys_default：系统默认（无授权数据时采用该权限）；sys：系统内置（配置人员配置的）；tmp：临时权限项，授权时增加进去的；）',
  `version` bigint(20) DEFAULT '1' COMMENT '乐观锁',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `delete_flag` tinyint(4) DEFAULT '0' COMMENT '逻辑删除 默认0，未删除，1已删除',
  `created_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `modified_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `template_id` bigint(20) DEFAULT NULL COMMENT '模板id',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据权限';
INSERT IGNORE INTO `hy_book058_acm_authority_data` (`id`,`name`,`code`,`desc`,`api_key`,`permission_type`,`item_type`,`version`,`created_by`,`gmt_create`,`modified_by`,`gmt_modified`,`delete_flag`,`created_user_name`,`modified_user_name`,`template_id`) VALUES ('1646805803438583808','用户管理_列表_数据权限','tfouC91681464074367','用户管理_列表_数据权限','1333649712808603648_list_1620293835460','data','sys_default',null,null,'2023-04-14 17:21:14.0','1543883730203062289','2023-06-14 14:57:15.0',null,null,'hy',null),('1646806047010205696','用户管理_查询_数据权限','ggf3pV1681464132439','用户管理_查询_数据权限','1333649712808603648_detail_1620293835389','data','sys_default',null,null,'2023-04-14 17:22:12.0','1543883730203062289','2023-06-14 15:13:31.0',null,null,'hy',null),('1646808099664834560','数据源详情_数据权限','R77sty1681464621830','数据源详情_数据权限','1539134748629282816_list_1655800289343','data','sys_default',null,'1543883730203062289','2023-04-14 17:30:21.0','1543883730203062289','2023-04-14 17:37:42.0',null,null,null,null),('1646809655378325504','用户日志操作_数据权限','2Ikl3R1681464992741','用户日志操作_数据权限','1535094014561366016_list_1658110242814','data','sys_default',null,'1543883730203062289','2023-04-14 17:36:32.0','1543883730203062289','2023-04-14 17:44:06.0',null,null,null,null),('1648565695514030080','角色管理_列表_数据权限','fM9B8y1681883665332','角色管理_列表_数据权限','1343519969148809216_list_1620293772563','data','sys_default',null,'1543883730203062289','2023-04-19 13:54:25.0','1543883730203062289','2023-06-14 16:52:28.0',null,null,'hy',null),('1648565875697135616','角色管理_查询_数据权限','BfdFWP1681883708295','角色管理_查询_数据权限','1343519969148809216_detail_1620293772493','data','sys_default',null,'1543883730203062289','2023-04-19 13:55:08.0','1543883730203062289','2023-06-14 16:52:39.0',null,null,'hy',null),('1648566441366138880','角色管理_更新_数据权限','H47R1B1681883843160','角色管理_更新_数据权限','1343519969148809216_update_1620293772425','data','sys_default',null,'1543883730203062289','2023-04-19 13:57:23.0','1543883730203062289','2023-06-14 17:03:49.0',null,null,'hy',null),('1648567056582455296','角色管理_删除_数据权限','TH9xeQ1681883989839','角色管理_删除_数据权限','1343519969148809216_del_1620293772283','data','sys_default',null,'1543883730203062289','2023-04-19 13:59:49.0','1295915065878388737','2023-06-05 11:51:58.0',null,null,null,null),('1648571112331816960','表格自定义样式_数据权限','Qhu9Yz1681884956805','表格自定义样式_数据权限','bis_api_1637652764172','data','sys_default',null,'1543883730203062289','2023-04-19 14:15:56.0','1543883730203062289','2023-04-19 14:15:56.0',null,null,null,null),('1665565236100476928','用户管理_更新_数据权限','PeG4hE1685936671645','用户管理_更新_数据权限','1333649712808603648_update_1620293835324','data','sys_default',null,'1295915065878388737','2023-06-05 11:44:31.0','1543883730203062289','2023-06-14 15:14:04.0',null,null,'hy',null),('1665566322341326848','用户管理_删除_数据权限','SnjHqd1685936930627','用户管理_删除_数据权限','1333649712808603648_del_1620293835189','data','sys_default',null,'1295915065878388737','2023-06-05 11:48:50.0','1543883730203062289','2023-06-14 15:13:25.0',null,null,'hy',null);
###end_paragraph
