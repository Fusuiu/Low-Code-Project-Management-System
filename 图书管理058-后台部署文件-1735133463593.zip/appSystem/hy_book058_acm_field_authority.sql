DROP TABLE IF EXISTS `hy_book058_acm_field_authority`;
CREATE TABLE IF NOT EXISTS `hy_book058_acm_field_authority` (
  `id` bigint(20) NOT NULL,
  `field_name` varchar(256) DEFAULT NULL,
  `api_code` varchar(128) NOT NULL,
  `api_name` varchar(128) DEFAULT NULL,
  `field_code` varchar(256) NOT NULL,
  `field_name_path` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
