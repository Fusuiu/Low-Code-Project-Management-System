DROP TABLE IF EXISTS `hy_book058_cepmodel_parse_result`;
CREATE TABLE IF NOT EXISTS `hy_book058_cepmodel_parse_result` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `chain_id` bigint(20) NOT NULL COMMENT '链id 外键',
  `code` varchar(128) DEFAULT NULL COMMENT '编码 唯一编码',
  `name` varchar(128) DEFAULT NULL COMMENT '名称 中文名称',
  `cep_type` varchar(16) DEFAULT NULL COMMENT 'cep类型',
  `cep_dsl_template` text COMMENT 'cep模板',
  `cep_source_code_template` text COMMENT 'cep源码模板',
  `json_schema` text COMMENT '参数json格式描述描述',
  `version` bigint(20) DEFAULT '1' COMMENT '乐观锁',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `delete_flag` int(11) DEFAULT NULL COMMENT '逻辑删除 默认0，未删除，1已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_chain_id` (`chain_id`) USING BTREE,
  KEY `idx_code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='链解析结果表 ';
