DROP TABLE IF EXISTS `hy_book058_imex_excel_template_api_relation`;
CREATE TABLE IF NOT EXISTS `hy_book058_imex_excel_template_api_relation` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `template_id` varchar(100) NOT NULL COMMENT '模板id',
  `chain_id` varchar(50) NOT NULL COMMENT 'apiid',
  `business_code` varchar(100) NOT NULL COMMENT '业务编码',
  `template_type` varchar(32) NOT NULL COMMENT 'API类型',
  `api_from` varchar(2) DEFAULT NULL COMMENT 'API来源 空或1为 模板触发  2为 数据源触发',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `chain_id_index` (`chain_id`) USING BTREE,
  KEY `idx_chain_id` (`chain_id`) USING BTREE,
  KEY `idx_template_id_template_type` (`template_id`,`template_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='模板API关联表';
