DROP TABLE IF EXISTS `hy_book058_md_tb_trigger`;
CREATE TABLE IF NOT EXISTS `hy_book058_md_tb_trigger` (
  `id` bigint(20) NOT NULL,
  `action_statement` text,
  `action_timing` varchar(16) DEFAULT NULL,
  `code` varchar(32) DEFAULT NULL,
  `event_manipulation` varchar(16) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `species` varchar(8) DEFAULT NULL,
  `table_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_code` (`code`) USING BTREE,
  KEY `FKa7qgye1khwvp6kdsf6a8w52lw3` (`table_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
