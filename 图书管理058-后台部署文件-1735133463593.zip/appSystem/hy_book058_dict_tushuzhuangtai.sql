DROP TABLE IF EXISTS `hy_book058_dict_tushuzhuangtai`;
CREATE TABLE IF NOT EXISTS `hy_book058_dict_tushuzhuangtai` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `level` int(3) NOT NULL COMMENT '层级',
  `code` varchar(32) NOT NULL COMMENT '编号',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `pid` bigint(20) DEFAULT NULL COMMENT '父节点',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '背景颜色',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字体颜色',
  PRIMARY KEY (`id`),
  KEY `idx_knhlmwgrv5` (`create_time`) USING BTREE,
  KEY `idx_97ophaewle` (`sequence`) USING BTREE,
  KEY `idx_nn9nijnf1e` (`code`) USING BTREE,
  KEY `idx_khtml2i2qo` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='图书状态';
INSERT IGNORE INTO `hy_book058_dict_tushuzhuangtai` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`path`,`level`,`code`,`name`,`pid`,`render_bg_color`,`render_font_color`) VALUES ('1864258830845501440','1','1863895470333386755',null,'2024-12-04 18:41:56.0','1863895470333386755',null,'2024-12-04 18:41:56.0','1',null,'1','1','上架',null,'#fff','#000'),('1864258830845501441','1','1863895470333386755',null,'2024-12-04 18:41:56.0','1863895470333386755',null,'2024-12-04 18:41:56.0','2',null,'1','2','下架',null,'#fff','#000');
###end_paragraph
