DROP TABLE IF EXISTS `hy_book058_acm_def_policy`;
CREATE TABLE IF NOT EXISTS `hy_book058_acm_def_policy` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `fid` bigint(20) NOT NULL COMMENT '授权模型定义id 关联“授权模型定义”表的主键',
  `subject_attr_code` varchar(64) NOT NULL COMMENT '授权主体属性编码 授权主体的属性编码（每个主体属性和资源属性关联定义一张授权结果表）',
  `resource_attr_code` varchar(64) NOT NULL COMMENT '授权资源属性编码 授权资源的属性编码（每个主体属性和资源属性关联定义一张授权结果表）',
  `authorize_table` varchar(64) NOT NULL COMMENT '权限授予结果表名 授权主体和授权资源的关联表名，即授权结果保存表名',
  `decision_code` varchar(64) DEFAULT NULL COMMENT '决策处理器编码 为空表示使用默认处理器',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源权限授予结果元数据定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
INSERT IGNORE INTO `hy_book058_acm_def_policy` (`id`,`fid`,`subject_attr_code`,`resource_attr_code`,`authorize_table`,`decision_code`) VALUES ('100001','1','ROLE','FUNCTION_ITEM','acm_policy_fun_role_code',null),('100003','2','ROLE','API_ITEM','acm_policy_data_role_code',null),('100004','3','ROLE','API_FUNCTION_ITEM','acm_policy_fun_role_code',null);
###end_paragraph
