DROP TABLE IF EXISTS `hy_book058_dict_biaoqianleixingzidian`;
CREATE TABLE IF NOT EXISTS `hy_book058_dict_biaoqianleixingzidian` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '字典项背景颜色',
  `code` varchar(32) NOT NULL COMMENT '字典项编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pid` decimal(20,0) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字典项字体颜色',
  `name` varchar(32) NOT NULL COMMENT '字典项名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_alozk1ji` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='标签类型字典';
INSERT IGNORE INTO `hy_book058_dict_biaoqianleixingzidian` (`create_user_id`,`render_bg_color`,`code`,`create_user_name`,`create_time`,`data_version`,`level`,`pid`,`last_update_user_id`,`last_update_time`,`sequence`,`path`,`render_font_color`,`name`,`id`,`last_update_user_name`) VALUES ('1295915065878388737','#fff','1',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','9',null,'#000','普通字段','1551735704462176256',null),('1295915065878388737','#fff','2',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','10',null,'#000','富文本字段','1551735704462176257',null),('1295915065878388737','#fff','3',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','11',null,'#000','图片','1551735704462176258',null),('1295915065878388737','#fff','4',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','12',null,'#000','word文档','1551735704462176259',null),('1295915065878388737','#fff','5',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','13',null,'#000','excel文档','1551735704462176260',null),('1295915065878388737','#fff','6',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','14',null,'#000','PDF文档','1551735704462176261',null),('1295915065878388737','#fff','7',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','15',null,'#000','普通值数组','1551735704462176262',null),('1295915065878388737','#fff','8',null,'2022-07-26 09:06:36.0','1','1',null,'1295915065878388737','2022-07-26 09:06:36.0','16',null,'#000','对象数组','1551735704462176263',null);
###end_paragraph
