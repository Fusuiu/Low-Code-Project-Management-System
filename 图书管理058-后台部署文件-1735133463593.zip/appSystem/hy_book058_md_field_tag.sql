DROP TABLE IF EXISTS `hy_book058_md_field_tag`;
CREATE TABLE IF NOT EXISTS `hy_book058_md_field_tag` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `field_id` bigint(20) DEFAULT NULL COMMENT '字段主键',
  `tag_id` bigint(20) DEFAULT NULL COMMENT '数据标签主键',
  `version` varchar(64) DEFAULT NULL COMMENT '版本号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_field_id` (`field_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表字段数据标签';
