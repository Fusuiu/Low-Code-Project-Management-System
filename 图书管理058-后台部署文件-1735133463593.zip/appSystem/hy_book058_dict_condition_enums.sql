DROP TABLE IF EXISTS `hy_book058_dict_condition_enums`;
CREATE TABLE IF NOT EXISTS `hy_book058_dict_condition_enums` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '字典项背景颜色',
  `code` varchar(32) NOT NULL COMMENT '字典项编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pid` decimal(20,0) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字典项字体颜色',
  `name` varchar(32) NOT NULL COMMENT '字典项名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`),
  KEY `idx_c9ntjeb2` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COMMENT='条件枚举';
INSERT IGNORE INTO `hy_book058_dict_condition_enums` (`create_user_id`,`render_bg_color`,`code`,`create_user_name`,`create_time`,`data_version`,`level`,`pid`,`last_update_user_id`,`last_update_time`,`sequence`,`path`,`render_font_color`,`name`,`id`,`last_update_user_name`) VALUES ('1295915065878388737','#fff','equ',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','16',null,'#000','等于','1565976786221805568',null),('1295915065878388737','#fff','notEqu',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','17',null,'#000','不等于','1565976786221805569',null),('1295915065878388737','#fff','greater',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','18',null,'#000','大于','1565976786221805570',null),('1295915065878388737','#fff','greaterEqu',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','19',null,'#000','大于等于','1565976786221805571',null),('1295915065878388737','#fff','less',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','20',null,'#000','小于','1565976786221805572',null),('1295915065878388737','#fff','lessEqu',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','21',null,'#000','小于等于','1565976786221805573',null),('1295915065878388737','#fff','like',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','22',null,'#000','包含','1565976786221805574',null),('1295915065878388737','#fff','notLike',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','23',null,'#000','不包含','1565976786221805575',null),('1295915065878388737','#fff','startWith',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','24',null,'#000','开头是','1565976786221805576',null),('1295915065878388737','#fff','startNotWith',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','25',null,'#000','开头不是','1565976786221805577',null),('1295915065878388737','#fff','endWith',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','26',null,'#000','结尾不是','1565976786221805578',null),('1295915065878388737','#fff','empty',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','27',null,'#000','为空','1565976786221805579',null),('1295915065878388737','#fff','notEmpty',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','28',null,'#000','不为空','1565976786221805580',null),('1295915065878388737','#fff','notIn',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','29',null,'#000','不属于','1565976786221805581',null),('1295915065878388737','#fff','in',null,'2022-09-03 16:15:34.0','1','1',null,'1295915065878388737','2022-09-03 16:15:34.0','30',null,'#000','属于','1565976786221805582',null);
###end_paragraph
