DROP TABLE IF EXISTS `hy_book058_acm_def_resource`;
CREATE TABLE IF NOT EXISTS `hy_book058_acm_def_resource` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `resource_table` varchar(64) NOT NULL COMMENT '资源表名',
  `id_field` varchar(64) NOT NULL DEFAULT 'id' COMMENT '标识字段名 资源表中能够唯一标识主体的字段名，默认id',
  `inherit_type` varchar(16) DEFAULT NULL COMMENT '继承类型 0：平级关系；1：树形层级关系。',
  `inherit_field_parent` varchar(64) DEFAULT 'id' COMMENT '继承字段_主键 inherit_type=1时有用',
  `inherit_field_child` varchar(64) DEFAULT 'pid' COMMENT '继承字段_外键 inherit_type=1时有用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源元数据定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
INSERT IGNORE INTO `hy_book058_acm_def_resource` (`id`,`resource_table`,`id_field`,`inherit_type`,`inherit_field_parent`,`inherit_field_child`) VALUES ('1001','acm_authority','code','FLATTEN','id','pid'),('1002','acm_authority_data','code','FLATTEN','id','pid'),('1003','acm_api_authority','id','FLATTEN','id','pid');
###end_paragraph
