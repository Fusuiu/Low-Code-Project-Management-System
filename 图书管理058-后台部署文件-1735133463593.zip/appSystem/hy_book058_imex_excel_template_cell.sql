DROP TABLE IF EXISTS `hy_book058_imex_excel_template_cell`;
CREATE TABLE IF NOT EXISTS `hy_book058_imex_excel_template_cell` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(128) DEFAULT NULL,
  `bg_color` int(3) DEFAULT NULL COMMENT '背景颜色',
  `font_color` int(3) DEFAULT NULL COMMENT '字体颜色',
  `postil` text,
  `formula` varchar(128) DEFAULT NULL,
  `select_item` text COMMENT '下拉项',
  `pid` bigint(20) DEFAULT NULL COMMENT '所属上级',
  `level` int(2) NOT NULL COMMENT '层级',
  `sequence` int(3) NOT NULL COMMENT '排序号',
  `sheet_id` bigint(20) NOT NULL COMMENT '关联excel_template_sheet主键',
  `template_id` bigint(20) NOT NULL COMMENT '关联excel_template主键',
  `item_data_type` varchar(10) DEFAULT NULL COMMENT '数据来源类型',
  `unique_sign` varchar(128) DEFAULT NULL COMMENT '唯一标识',
  `unique_sign_show_value` varchar(128) DEFAULT NULL COMMENT '唯一标识显示值',
  `query_criteria_str` text COMMENT '查询条件',
  `dict_select_all` varchar(10) DEFAULT NULL COMMENT '字典是否全选',
  `input_format` varchar(32) DEFAULT NULL COMMENT '输入格式',
  `data_table_field` mediumtext COMMENT '数据表及字段配置信息',
  `required` varchar(8) DEFAULT NULL COMMENT '是否必填 ',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_imex_excel_template_cell_template_id` (`template_id`) USING BTREE,
  KEY `idx_template_id` (`template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板cell列描述表';
INSERT IGNORE INTO `hy_book058_imex_excel_template_cell` (`id`,`name`,`bg_color`,`font_color`,`postil`,`formula`,`select_item`,`pid`,`level`,`sequence`,`sheet_id`,`template_id`,`item_data_type`,`unique_sign`,`unique_sign_show_value`,`query_criteria_str`,`dict_select_all`,`input_format`,`data_table_field`,`required`) VALUES ('1552945718157783040','错误详情信息',null,null,null,null,null,null,'1','1','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783041','所属业务模块',null,null,null,null,null,null,'1','2','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783042','操作人工号',null,null,null,null,null,null,'1','3','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783043','操作人姓名',null,null,null,null,null,null,'1','4','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783044','操作人IP地址',null,null,null,null,null,null,'1','5','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783045','日志时间',null,null,null,null,null,null,'1','6','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783046','作业行为',null,null,null,null,null,null,'1','7','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783047','作业对象关键信息',null,null,null,null,null,null,'1','8','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783048','作业对象名称',null,null,null,null,null,null,'1','9','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783049','作业结果',null,null,null,null,null,null,'1','10','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783050','操作人所属机构编号',null,null,null,null,null,null,'1','11','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783051','操作人所属机构名称',null,null,null,null,null,null,'1','12','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783052','操作页面',null,null,null,null,null,null,'1','13','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783053','操作人账号名',null,null,null,null,null,null,'1','14','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783054','操作人用户名',null,null,null,null,null,null,'1','15','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null),('1552945718157783055','启用禁用状态',null,null,null,null,null,null,'1','16','1552945717562191872','1552945717557997568',null,null,null,null,null,null,null,null);
###end_paragraph
