DROP TABLE IF EXISTS `hy_book058_page_info`;
CREATE TABLE IF NOT EXISTS `hy_book058_page_info` (
  `id` bigint(20) NOT NULL COMMENT '主键 记录的唯一标识',
  `name` varchar(128) NOT NULL COMMENT '页面名称',
  `type` int(11) NOT NULL COMMENT '页面类型 1，自定义页面；2，仪表盘页面；3，定制页面；4，流程壳',
  `current_version` bigint(20) NOT NULL COMMENT '当前版本',
  `published_version` bigint(20) DEFAULT NULL COMMENT '发布版本',
  `page_code` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '页面编码 自动生成。从1000开始，每次加1。',
  `page_content` longtext COMMENT '页面内容',
  `gmt_modified` datetime DEFAULT NULL COMMENT '更新时间 更新时间，建立普通索引',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `version` bigint(20) DEFAULT '1' COMMENT '乐观锁',
  `delete_flag` tinyint(4) DEFAULT '0' COMMENT '逻辑删除 默认0，未删除，1已删除',
  `page_template_type` varchar(64) DEFAULT NULL COMMENT '页面模板类型',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_page_code` (`page_code`) USING BTREE COMMENT '唯一索引',
  KEY `idx_gmt_modified` (`gmt_modified`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1865684065285201921 DEFAULT CHARSET=utf8 COMMENT='页面信息表 表名是动态的，需要表名重定位功能。';
