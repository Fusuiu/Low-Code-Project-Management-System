DROP TABLE IF EXISTS `hy_book058_msg_template_field`;
CREATE TABLE IF NOT EXISTS `hy_book058_msg_template_field` (
  `fid` decimal(20,0) NOT NULL COMMENT '外键',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `code` varchar(64) NOT NULL COMMENT '编码',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `name` varchar(64) DEFAULT NULL COMMENT '名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `field_type` varchar(32) DEFAULT NULL COMMENT '类型',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_tmh6vj5cgf` (`sequence`) USING BTREE,
  KEY `idx_4vwm0kq0` (`fid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='模板参数表';
INSERT IGNORE INTO `hy_book058_msg_template_field` (`fid`,`create_user_id`,`code`,`create_time`,`create_user_name`,`data_version`,`last_update_user_id`,`last_update_time`,`sequence`,`name`,`id`,`field_type`,`last_update_user_name`) VALUES ('1460501284581945344','1295915065878388737','var_pageInput_1_9k0x2aFN','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','1','流程实例主键','1463114360963608576',null,null),('1460501284581945344','1295915065878388737','var_pageInput_2_8aH8YLZi','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','2','流程展示类型','1463114360963608577',null,null),('1460501284581945344','1295915065878388737','var_pageInput_3_6EoBTR-7','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','3','任务主键','1463114360963608578',null,null),('1460501284581945344','1295915065878388737','var_pageInput_4_Pj_0Hwwe','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','4','流程模版标识','1463114360963608579',null,null),('1460501284581945344','1295915065878388737','var_pageInput_5_ZuPPn829','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','5','预留的额外变量','1463114360963608580',null,null),('1460501284581945344','1295915065878388737','title','2021-11-23 19:57:02.0',null,'1','1295915065878388737','2021-11-23 19:57:02.0','6','标题','1463114360963608581',null,null),('1458699873091203072','1295915065878388737','title','2021-12-04 14:03:49.0',null,'1','1295915065878388737','2021-12-04 14:03:49.0','1','标题','1467011737831223296',null,null),('1458699873091203072','1295915065878388737','var_pageInput_2_LnvVQzBw','2021-12-04 14:03:49.0',null,'1','1295915065878388737','2021-12-04 14:03:49.0','2','系统公告主键','1467011737831223297',null,null);
###end_paragraph
