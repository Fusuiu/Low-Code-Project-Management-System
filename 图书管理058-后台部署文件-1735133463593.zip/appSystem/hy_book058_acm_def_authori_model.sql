DROP TABLE IF EXISTS `hy_book058_acm_def_authori_model`;
CREATE TABLE IF NOT EXISTS `hy_book058_acm_def_authori_model` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `code` varchar(32) NOT NULL COMMENT '模型编码 例如“设备操作权限授权模型（ctrl）”，“机构树权限授权模型（org）”；每种授权模型对应的表都不同，尽量使用单个单词或缩写表示，方便作为授权结果表名的一部分',
  `subject_def_id` bigint(20) NOT NULL COMMENT '主体定义id 关联“主体元数据定义表”id',
  `resource_def_id` bigint(20) NOT NULL COMMENT '资源定义id 关联“资源元数据定义表”id',
  `operation_def_id` bigint(20) DEFAULT NULL COMMENT '操作项定义id 关联“操作项模型定义表”id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='授权模型定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
INSERT IGNORE INTO `hy_book058_acm_def_authori_model` (`id`,`code`,`subject_def_id`,`resource_def_id`,`operation_def_id`) VALUES ('1','FUNCTIONAL_PERM','101','1001',null),('2','BIZ_DATA_PERM','101','1002',null),('3','API_FUNCTIONAL_PERM','101','1003',null);
###end_paragraph
