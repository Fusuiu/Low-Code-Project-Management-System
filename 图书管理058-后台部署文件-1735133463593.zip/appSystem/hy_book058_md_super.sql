DROP TABLE IF EXISTS `hy_book058_md_super`;
CREATE TABLE IF NOT EXISTS `hy_book058_md_super` (
  `app_code` varchar(255) DEFAULT NULL,
  `lessee_code` varchar(255) DEFAULT NULL,
  `mapping_table_code` varchar(255) DEFAULT NULL,
  `table_id` bigint(20) NOT NULL,
  `transformed` varchar(255) DEFAULT NULL COMMENT '是否转换',
  PRIMARY KEY (`table_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
