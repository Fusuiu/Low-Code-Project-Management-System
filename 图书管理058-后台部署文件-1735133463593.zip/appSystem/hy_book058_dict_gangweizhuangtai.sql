DROP TABLE IF EXISTS `hy_book058_dict_gangweizhuangtai`;
CREATE TABLE IF NOT EXISTS `hy_book058_dict_gangweizhuangtai` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '字典项背景颜色',
  `code` varchar(32) NOT NULL COMMENT '字典项编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pid` decimal(20,0) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字典项字体颜色',
  `name` varchar(32) NOT NULL COMMENT '字典项名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_w5bJwTzp` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='岗位状态';
