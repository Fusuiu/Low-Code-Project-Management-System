DROP TABLE IF EXISTS `hy_book058_job_cfg_action`;
CREATE TABLE IF NOT EXISTS `hy_book058_job_cfg_action` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `system_code` varchar(32) DEFAULT NULL COMMENT '所属系统编码',
  `system_name` varchar(128) DEFAULT NULL COMMENT '所属系统名称',
  `job_cfg_id` decimal(20,0) DEFAULT NULL COMMENT '所属定时任务配置',
  `code` varchar(32) DEFAULT NULL COMMENT '动作编码',
  `name` varchar(32) DEFAULT NULL COMMENT '动作名称',
  `other_params` varchar(512) DEFAULT NULL COMMENT '其它参数json保存',
  `create_user_code` varchar(32) DEFAULT NULL COMMENT '创建人编码',
  `last_update_user_code` varchar(32) DEFAULT NULL COMMENT '最后修改人编码',
  PRIMARY KEY (`id`),
  KEY `idx_h9eouiwudc` (`create_time`) USING BTREE,
  KEY `idx_wia3lolgu7` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定时任务配置的动作参数';
