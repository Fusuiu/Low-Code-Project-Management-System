DROP TABLE IF EXISTS `hy_book058_job_exec_service_log`;
CREATE TABLE IF NOT EXISTS `hy_book058_job_exec_service_log` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `system_code` varchar(32) DEFAULT NULL COMMENT '所属系统编码',
  `system_name` varchar(128) DEFAULT NULL COMMENT '所属系统名称',
  `exec_record_id` decimal(20,0) DEFAULT NULL COMMENT '所属执行记录ID',
  `content` text COMMENT '日志内容',
  `recevice_data` text COMMENT '接收到的回调数据',
  `create_user_code` varchar(32) DEFAULT NULL COMMENT '创建人编码',
  `last_update_user_code` varchar(32) DEFAULT NULL COMMENT '最后修改人编码',
  PRIMARY KEY (`id`),
  KEY `idx_2zenf2oive` (`create_time`) USING BTREE,
  KEY `idx_sdq9wnsjf0` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='定时任务业务执行日志';
