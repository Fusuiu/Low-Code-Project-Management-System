DROP TABLE IF EXISTS `hy_pcm058_imex_excel_template_sheet`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_imex_excel_template_sheet` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(128) DEFAULT NULL,
  `is_explain_sheet` tinyint(2) NOT NULL COMMENT '是否说明页（1是2否）',
  `content` text COMMENT '说明内容',
  `head_row` int(2) DEFAULT NULL COMMENT '列头行数',
  `template_id` bigint(20) NOT NULL COMMENT '关联模板',
  `sequence` int(3) NOT NULL COMMENT '排序号',
  `import_operation_type` varchar(8) DEFAULT NULL COMMENT '操作类型',
  `by_field` text COMMENT '依据字段',
  `table_type` varchar(8) DEFAULT NULL COMMENT '工作表类型',
  `sheet_table_info` text COMMENT 'sheet页对应的数据表信息',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_imex_excel_template_sheet_template_id` (`template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板sheet描述表';
INSERT IGNORE INTO `hy_pcm058_imex_excel_template_sheet` (`id`,`name`,`is_explain_sheet`,`content`,`head_row`,`template_id`,`sequence`,`import_operation_type`,`by_field`,`table_type`,`sheet_table_info`) VALUES ('1552945717562191872','用户操作日志表','2',null,'1','1552945717557997568','1',null,null,null,null);
###end_paragraph
