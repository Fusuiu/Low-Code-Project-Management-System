DROP TABLE IF EXISTS `hy_pcm058_acm_def_subject`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_acm_def_subject` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `subject_table` varchar(64) NOT NULL COMMENT '主体表名',
  `id_field` varchar(64) NOT NULL DEFAULT 'id' COMMENT '标识字段名 主体表中能够唯一标识主体的字段名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主体元数据定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
INSERT IGNORE INTO `hy_pcm058_acm_def_subject` (`id`,`subject_table`,`id_field`) VALUES ('101','user_account','id');
###end_paragraph
