DROP TABLE IF EXISTS `hy_pcm058_bizgw_plugin_group`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_bizgw_plugin_group` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `pid` bigint(20) DEFAULT NULL COMMENT '父级主键',
  `path` varchar(256) DEFAULT NULL COMMENT '路径',
  `last_update_user_id` bigint(20) DEFAULT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  `create_user_id` bigint(20) DEFAULT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='业务组件分组信息';
INSERT IGNORE INTO `hy_pcm058_bizgw_plugin_group` (`id`,`name`,`pid`,`path`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`create_user_id`,`create_user_name`,`create_time`) VALUES ('1409436067760844800','定时服务',null,null,'1295915065878388737','管理员','2021-06-28 16:58:39.0','1295915065878388737','管理员','2021-06-28 16:58:39.0'),('1410429262397321216','流程服务',null,null,'1295915065878388737','管理员','2021-07-01 10:46:00.0','1295915065878388737','管理员','2021-07-01 10:45:15.0'),('1440875879889776640','流媒体服务',null,null,'1295915065878123404','李睿','2021-09-23 11:09:15.0','1295915065878123404','李睿','2021-09-23 11:09:15.0'),('1440938840943636480','物平台',null,null,'1295915065878388737','管理员','2021-09-23 15:19:26.0','1295915065878388737','管理员','2021-09-23 15:19:26.0'),('1514144041191747584','IM消息推送',null,null,'1295915065878388737','hy','2022-04-13 15:30:46.0','1295915065878388737','hy','2022-04-13 15:30:46.0'),('1526730316142751744','权限管理','1526053233817169920','1526053233817169920','1295915065878388737','hy','2022-05-18 09:04:07.0','1295915065878388737','hy','2022-05-18 09:04:07.0'),('1546673177319583744','对象存储服务',null,null,'1295915065878388737','hy','2022-07-12 09:49:56.0','1295915065878388737','hy','2022-07-12 09:49:56.0');
###end_paragraph
