DROP TABLE IF EXISTS `hy_pcm058_dict_xiangmuzhuangtaizidian`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_dict_xiangmuzhuangtaizidian` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `level` int(3) NOT NULL COMMENT '层级',
  `code` varchar(32) NOT NULL COMMENT '编号',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `pid` bigint(20) DEFAULT NULL COMMENT '父节点',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '背景颜色',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字体颜色',
  PRIMARY KEY (`id`),
  KEY `idx_ydfgftpw1t` (`create_time`) USING BTREE,
  KEY `idx_p5bzrqd7v8` (`sequence`) USING BTREE,
  KEY `idx_u9ngvd3mdy` (`code`) USING BTREE,
  KEY `idx_ng5rtqqccp` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='项目状态字典';
INSERT IGNORE INTO `hy_pcm058_dict_xiangmuzhuangtaizidian` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`path`,`level`,`code`,`name`,`pid`,`render_bg_color`,`render_font_color`) VALUES ('1865936550872637440','1','1863895470333386755',null,'2024-12-09 09:48:35.0','1863895470333386755',null,'2024-12-09 09:48:35.0','1',null,'1','0','未完成',null,'#fff','#000'),('1865936550872637441','1','1863895470333386755',null,'2024-12-09 09:48:35.0','1863895470333386755',null,'2024-12-09 09:48:35.0','2',null,'1','1','已完成',null,'#fff','#000');
###end_paragraph
