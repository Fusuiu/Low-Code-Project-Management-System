DROP TABLE IF EXISTS `hy_pcm058_data_permission_template`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_data_permission_template` (
  `id` bigint(20) NOT NULL,
  `type` varchar(100) DEFAULT NULL COMMENT '类型：字段filed，数据data',
  `creator_name` varchar(100) DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `name` varchar(256) DEFAULT NULL,
  `describe` text,
  `condition_content` text CHARACTER SET utf8 COMMENT '条件json内容，库表引擎使用',
  `condition_meta` text CHARACTER SET utf8 COMMENT '条件json描述,配置平台使用',
  `field_meta` text CHARACTER SET utf8 COMMENT '许可字段列配置信息',
  `api_list` text COMMENT 'api编码列表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
