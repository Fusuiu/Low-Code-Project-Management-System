DROP TABLE IF EXISTS `hy_pcm058_acm_share_relationship`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_acm_share_relationship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sharer_id` varchar(32) NOT NULL COMMENT '附加来源id',
  `target_id` varchar(32) NOT NULL COMMENT '附加目标id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `expiration` datetime DEFAULT NULL COMMENT '有效期',
  `status` int(2) DEFAULT NULL COMMENT '激活状态：0未激活，1激活',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
