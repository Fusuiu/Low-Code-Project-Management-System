DROP TABLE IF EXISTS `hy_pcm058_md_super_relation`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_md_super_relation` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `lessee_code` varchar(100) DEFAULT NULL COMMENT '租户编码',
  `app_code` varchar(100) DEFAULT NULL COMMENT '应用编码',
  `code` varchar(100) DEFAULT NULL COMMENT '表编码',
  `table_id` bigint(20) DEFAULT NULL COMMENT '表主键',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_table_id` (`table_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='超级表关联信息';
