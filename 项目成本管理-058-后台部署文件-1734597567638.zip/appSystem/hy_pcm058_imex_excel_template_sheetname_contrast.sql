DROP TABLE IF EXISTS `hy_pcm058_imex_excel_template_sheetname_contrast`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_imex_excel_template_sheetname_contrast` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `template_id` decimal(20,0) NOT NULL COMMENT '模板id',
  `sheet_id` decimal(20,0) NOT NULL COMMENT '模板shhet对应id',
  `name_in_template` varchar(255) DEFAULT NULL COMMENT 'sheetname在模板',
  `name_in_api` varchar(255) DEFAULT NULL COMMENT 'sheetname在api',
  `api_id` decimal(20,0) DEFAULT NULL COMMENT '备用（暂时不设数据）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_template_sheet_id_unique` (`template_id`,`sheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板与APIsheetname对照表';
