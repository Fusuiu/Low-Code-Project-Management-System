DROP TABLE IF EXISTS `hy_pcm058_dict_question_type_page_report`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_dict_question_type_page_report` (
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '字典项背景颜色',
  `code` varchar(32) NOT NULL COMMENT '字典项编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pid` bigint(20) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字典项字体颜色',
  `name` varchar(32) NOT NULL COMMENT '字典项名称',
  `id` bigint(20) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`),
  KEY `idx_code` (`code`) USING BTREE,
  KEY `idx_ly6ib6jd` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='问题类型';
INSERT IGNORE INTO `hy_pcm058_dict_question_type_page_report` (`create_user_id`,`render_bg_color`,`code`,`create_user_name`,`create_time`,`data_version`,`level`,`pid`,`last_update_user_id`,`last_update_time`,`sequence`,`path`,`render_font_color`,`name`,`id`,`last_update_user_name`) VALUES ('1295915065878388666','#fff','1',null,'2023-12-25 18:51:19.0','1','1',null,'1295915065878388666','2023-12-25 18:51:19.0','1',null,'#000','无异常','1739237378255630336',null),('1295915065878388666','#fff','2',null,'2023-12-25 18:51:19.0','1','1',null,'1295915065878388666','2023-12-25 18:51:19.0','2',null,'#000','页面单次调用API超过2个','1739237378255630337',null);
###end_paragraph
