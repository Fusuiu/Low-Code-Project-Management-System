DROP TABLE IF EXISTS `hy_pcm058_acm_def_operation`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_acm_def_operation` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `operation_name` varchar(64) NOT NULL COMMENT '操作类型名称',
  `operation_desc` varchar(64) DEFAULT NULL COMMENT '操作类型描述',
  `operation_res_type_rel` int(11) NOT NULL COMMENT '操作类型是否跟资源类型有关 0：无关 1：有关',
  `operation_def_table` varchar(64) NOT NULL COMMENT '操作类型描述表',
  `operation_ref_table` varchar(64) DEFAULT NULL COMMENT '操作类型关联表 operation_res_type_rel为0时为空，资源类型和操作项关联表',
  `res_type_field` varchar(64) DEFAULT NULL COMMENT '资源类型字段名 operation_res_type_rel为0时为空。资源主表中，资源类型对应字段名',
  `operation_rel_field` varchar(64) NOT NULL DEFAULT 'code' COMMENT '操作项标识字段 操作类型描述表中用于标识操作项的字段，默认是code，可以为id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='操作项模型定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
