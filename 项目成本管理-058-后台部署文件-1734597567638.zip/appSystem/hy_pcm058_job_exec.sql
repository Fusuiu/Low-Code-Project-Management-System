DROP TABLE IF EXISTS `hy_pcm058_job_exec`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_job_exec` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `system_code` varchar(32) DEFAULT NULL COMMENT '所属系统编码',
  `system_name` varchar(128) DEFAULT NULL COMMENT '所属系统名称',
  `job_cfg_id` decimal(20,0) DEFAULT NULL COMMENT '所属任务配置ID',
  `job_cfg_name` varchar(128) DEFAULT NULL COMMENT '所属任务配置名',
  `start_time` datetime DEFAULT NULL COMMENT '开始执行时间',
  `status` varchar(32) DEFAULT NULL COMMENT '执行状态',
  `send_event_time` datetime DEFAULT NULL COMMENT '发送业务事件时间',
  `create_user_code` varchar(32) DEFAULT NULL COMMENT '创建人编码',
  `last_update_user_code` varchar(32) DEFAULT NULL COMMENT '最后修改人编码',
  PRIMARY KEY (`id`),
  KEY `idx_5rtimgddif` (`create_time`) USING BTREE,
  KEY `idx_tjx1qzqr4o` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COMMENT='定时任务执行情况';
