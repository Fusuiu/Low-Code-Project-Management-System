DROP TABLE IF EXISTS `hy_pcm058_dict_xiangmujindufengxian`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_dict_xiangmujindufengxian` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `level` int(3) NOT NULL COMMENT '层级',
  `code` varchar(32) NOT NULL COMMENT '编号',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `pid` bigint(20) DEFAULT NULL COMMENT '父节点',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '背景颜色',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字体颜色',
  PRIMARY KEY (`id`),
  KEY `idx_kvwsa1ats6` (`create_time`) USING BTREE,
  KEY `idx_bgpdpweczq` (`sequence`) USING BTREE,
  KEY `idx_jc50q1fyxn` (`code`) USING BTREE,
  KEY `idx_aw3pumloby` (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='项目进度风险';
INSERT IGNORE INTO `hy_pcm058_dict_xiangmujindufengxian` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`path`,`level`,`code`,`name`,`pid`,`render_bg_color`,`render_font_color`) VALUES ('1868490156600061952','1','1863895470333386755',null,'2024-12-16 10:55:42.0','1863895470333386755',null,'2024-12-16 10:55:42.0','1',null,'1','1','正常',null,'#fff','#b8e986'),('1868490156600061953','1','1863895470333386755',null,'2024-12-16 10:55:42.0','1863895470333386755',null,'2024-12-16 10:55:42.0','2',null,'1','2','进度超前',null,'#fff','#4a90e2'),('1868490156600061954','1','1863895470333386755',null,'2024-12-16 10:55:42.0','1863895470333386755',null,'2024-12-16 10:55:42.0','3',null,'1','3','延期风险',null,'#fff','#d0021b');
###end_paragraph
