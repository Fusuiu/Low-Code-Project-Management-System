DROP TABLE IF EXISTS `hy_pcm058_imex_excel_template_table_ref`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_imex_excel_template_table_ref` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `template_id` bigint(20) NOT NULL COMMENT '模板主键（关联表excel_template主键）',
  `table_id` bigint(20) NOT NULL COMMENT '表主键（md_table表主键）',
  `use_table_ids` text NOT NULL COMMENT '模板所用的所有表id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_template_id` (`template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板与表关联表';
INSERT IGNORE INTO `hy_pcm058_imex_excel_template_table_ref` (`id`,`template_id`,`table_id`,`use_table_ids`) VALUES ('1552945718271029248','1552945717557997568','1535094014561366016','1535094014561366016');
###end_paragraph
