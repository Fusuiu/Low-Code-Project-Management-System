DROP TABLE IF EXISTS `hy_pcm058_md_json_custom_dict`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_md_json_custom_dict` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `dict_value` varchar(32) DEFAULT NULL COMMENT '字典值',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `dict_code` varchar(32) DEFAULT NULL COMMENT '字典编号',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `dynamic_field_id` decimal(20,0) NOT NULL COMMENT '动态字段表主键',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_lyteiukp` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='JSON自定义选项表';
