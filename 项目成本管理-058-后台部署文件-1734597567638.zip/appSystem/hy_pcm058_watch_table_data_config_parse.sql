DROP TABLE IF EXISTS `hy_pcm058_watch_table_data_config_parse`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_watch_table_data_config_parse` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `business_code` varchar(256) NOT NULL COMMENT '业务编码 业务的唯一编码',
  `bis_code_less_code` varchar(256) NOT NULL COMMENT 'businessCode使用了超级表时的租户号',
  `bis_code_app_code` varchar(256) NOT NULL COMMENT 'businessCode使用了超级表时的应用号',
  `table` varchar(128) NOT NULL COMMENT '表编码',
  `table_type` varchar(128) DEFAULT 'nomal' COMMENT '表类型：normal/super',
  `type` varchar(256) NOT NULL COMMENT '监听类型：insert/update/delete/replace,多个值用逗号隔开',
  `super_table_less_code` varchar(256) DEFAULT NULL COMMENT '超级表所在应用的租户号',
  `super_table_app_code` varchar(256) DEFAULT NULL COMMENT '超级表所在应用的应用号',
  `relate_super_table` varchar(256) DEFAULT NULL COMMENT '关联的超级表编号',
  `remark` text COMMENT '备注说明',
  `version` bigint(20) DEFAULT '1' COMMENT '乐观锁',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `delete_flag` tinyint(4) DEFAULT '0' COMMENT '逻辑删除 默认0，未删除，1已删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_business_code` (`business_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='表数据监听器配置解析表';
INSERT IGNORE INTO `hy_pcm058_watch_table_data_config_parse` (`id`,`business_code`,`bis_code_less_code`,`bis_code_app_code`,`table`,`table_type`,`type`,`super_table_less_code`,`super_table_app_code`,`relate_super_table`,`remark`,`version`,`created_by`,`gmt_create`,`modified_by`,`gmt_modified`,`delete_flag`) VALUES ('1628965038456975360','1587999319695437824_list_1667443755330','hy','8test8','s_flow_template','nomal','insert,delete,update,replace',null,null,null,'业务建模API查询类表监听配置解析结果',null,'1295915065878388737','2023-02-24 11:48:24.0','1295915065878388737','2023-02-24 11:48:24.0',null);
###end_paragraph
