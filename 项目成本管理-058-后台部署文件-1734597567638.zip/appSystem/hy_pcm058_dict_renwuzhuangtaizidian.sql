DROP TABLE IF EXISTS `hy_pcm058_dict_renwuzhuangtaizidian`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_dict_renwuzhuangtaizidian` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `level` int(3) NOT NULL COMMENT '层级',
  `code` varchar(32) NOT NULL COMMENT '编号',
  `name` varchar(32) NOT NULL COMMENT '名称',
  `pid` bigint(20) DEFAULT NULL COMMENT '父节点',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '背景颜色',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字体颜色',
  PRIMARY KEY (`id`),
  KEY `idx_4hagqqs9sw` (`pid`) USING BTREE,
  KEY `idx_bij0n1f69b` (`create_time`) USING BTREE,
  KEY `idx_ezh8bu7emj` (`sequence`) USING BTREE,
  KEY `idx_wuzesguw94` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='任务状态字典';
INSERT IGNORE INTO `hy_pcm058_dict_renwuzhuangtaizidian` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`path`,`level`,`code`,`name`,`pid`,`render_bg_color`,`render_font_color`) VALUES ('1867783220527230976','1','1863895470333386755',null,'2024-12-14 12:06:36.0','1863895470333386755',null,'2024-12-14 12:06:36.0','1',null,'1','1','未开始',null,'#fff','#000'),('1867783220527230977','1','1863895470333386755',null,'2024-12-14 12:06:36.0','1863895470333386755',null,'2024-12-14 12:06:36.0','2',null,'1','2','进行中',null,'#fff','#4a90e2'),('1867783220527230978','1','1863895470333386755',null,'2024-12-14 12:06:36.0','1863895470333386755',null,'2024-12-14 12:06:36.0','3',null,'1','3','取消',null,'#fff','#d0021b'),('1867783220527230979','1','1863895470333386755',null,'2024-12-14 12:06:36.0','1863895470333386755',null,'2024-12-14 12:06:36.0','4',null,'1','0','完工',null,'#fff','#000');
###end_paragraph
