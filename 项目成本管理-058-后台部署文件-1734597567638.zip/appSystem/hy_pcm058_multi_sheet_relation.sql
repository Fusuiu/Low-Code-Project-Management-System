DROP TABLE IF EXISTS `hy_pcm058_multi_sheet_relation`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_multi_sheet_relation` (
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `template_id` decimal(20,0) NOT NULL COMMENT '模板id',
  `sheet_id` decimal(20,0) NOT NULL COMMENT '列对应sheet主键',
  `cell_id` decimal(20,0) NOT NULL COMMENT '列主键',
  `ref_cell_id` decimal(20,0) NOT NULL COMMENT '被依赖列主键',
  `ref_sheet_id` decimal(20,0) NOT NULL COMMENT '被依赖列对应sheet主键',
  `cell_name` varchar(255) NOT NULL COMMENT '列名称',
  `ref_cell_name` varchar(255) NOT NULL COMMENT '被依赖列名称',
  `sheet_name` varchar(255) NOT NULL COMMENT 'sheet页名称',
  `ref_sheet_name` varchar(255) NOT NULL COMMENT '被依赖sheet页名称',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_template_sheet_id_unique` (`template_id`,`sheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多sheet页间关系表';
