DROP TABLE IF EXISTS `hy_pcm058_md_json_clips`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_md_json_clips` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `code` varchar(32) NOT NULL COMMENT '编号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `description` text COMMENT '描述',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `table_id` decimal(20,0) NOT NULL COMMENT '所属表主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `name` varchar(64) DEFAULT NULL COMMENT '名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `is_saas_show` varchar(2) DEFAULT NULL COMMENT '是否saas端显示',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_fs2yimfe5j` (`code`,`table_id`) USING BTREE,
  UNIQUE KEY `idx_unique_name` (`name`,`table_id`) USING BTREE,
  KEY `idx_663oug5w8d` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='JSON片段表';
