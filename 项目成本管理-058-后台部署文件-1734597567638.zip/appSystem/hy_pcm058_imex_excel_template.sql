DROP TABLE IF EXISTS `hy_pcm058_imex_excel_template`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_imex_excel_template` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(128) DEFAULT NULL,
  `module_id` bigint(20) DEFAULT NULL COMMENT '模块主键',
  `file_content` text COMMENT '文件内容',
  `format_layout` varchar(16) NOT NULL COMMENT '文件格式',
  `generate_file_type` int(2) NOT NULL COMMENT '文件生成类型 1.从模型对象生成文件；2.从文件生成模型对象',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `version` bigint(20) DEFAULT '1' COMMENT '乐观锁',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime(3) DEFAULT NULL COMMENT '创建时间',
  `modified_by` bigint(20) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime(3) DEFAULT NULL COMMENT '更新时间',
  `delete_flag` tinyint(2) DEFAULT '0' COMMENT '逻辑删除 0未删除，1已删除',
  `template_update_input` mediumtext COMMENT '更新模板入参保存',
  `template_type` varchar(8) DEFAULT NULL COMMENT '模板类型 1/null:旧，2：新',
  `execution_strategy` tinyint(4) DEFAULT NULL COMMENT '执行策略',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uni_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='模板描述表';
