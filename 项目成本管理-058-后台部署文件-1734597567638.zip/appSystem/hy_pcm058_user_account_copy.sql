DROP TABLE IF EXISTS `hy_pcm058_user_account_copy`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_user_account_copy` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `is_system_recode` int(8) DEFAULT NULL COMMENT '系统记录',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `pwd_status` int(8) DEFAULT NULL COMMENT '密码状态1重置状态其他正常状态',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `user_account_name` varchar(32) NOT NULL COMMENT '账号名',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_hyxgjdcqnu` (`sequence`) USING BTREE,
  KEY `idx_nmrjef4cij` (`user_account_name`) USING BTREE,
  KEY `idx_zwrwkrtpdu` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户账号表';
