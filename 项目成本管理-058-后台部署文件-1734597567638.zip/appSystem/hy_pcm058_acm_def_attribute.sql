DROP TABLE IF EXISTS `hy_pcm058_acm_def_attribute`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_acm_def_attribute` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `fid` bigint(20) NOT NULL COMMENT '元数据定义主键 主体定义主键或资源定义主键',
  `attr_code` varchar(64) NOT NULL COMMENT '属性编码 属性标识，可以是主体/资源主表的字段名，如果是中间表关联方式，可另外命名。例如：用户<->角色中间表，角色是用户的属性，在用户表没有角色字段，那么可命名role表示角色属性。',
  `attr_field` varchar(64) NOT NULL COMMENT '属性对应字段编码，当 attr_type=MAIN_TABLE或attr_type=REF_FIELD时，是表字段的编码；当 attr_type=MIDD_TABLE时，与attrCode保持一致',
  `attr_type` varchar(16) NOT NULL DEFAULT 'MIDD_TABLE' COMMENT '属性类型 0:主表属性值；1: 引用字段值；2:中间表关联属性值；',
  `attr_value_table` varchar(64) NOT NULL COMMENT '属性实际表 保存属性实际值的表名\r\nattr_type=0: 即主体/资源主表；\r\nattr_type=1: 引用目标表；\r\nattr_type=2: 中间表对应的副表；',
  `attr_id_field` varchar(64) NOT NULL DEFAULT 'id' COMMENT '属性实际表标识字段 attr_type=1或attr_type=2时启用\r\nattr_type=1: 引用目标表的标识字段，默认id；\r\nattr_type=2: 中间表对应的副表标识字段，默认id；',
  `attr_value_field` varchar(64) DEFAULT NULL COMMENT '属性实际表属性字段 attr_type=1或attr_type=2时启用，实际存储属性值的字段名\r\nattr_type=1: 引用目标表的标识字段，默认id；\r\nattr_type=2: 中间表对应的副表标识字段，默认id；',
  `ref_midd_table` varchar(64) DEFAULT NULL COMMENT '中间表表名 attr_type=2时启用，中间表的表名',
  `ref_main_field` varchar(64) DEFAULT NULL COMMENT '关联主表字段 attr_type=2时启用，中间表中，保存主表主键的字段名',
  `ref_sub_field` varchar(64) DEFAULT NULL COMMENT '关联副表字段 attr_type=2时启用，中间表中，保存分组key的字段名',
  `inherit_type` varchar(16) NOT NULL DEFAULT '0' COMMENT '继承类型 0：平级关系；1：树形层级关系。',
  `inherit_field_parent` varchar(64) DEFAULT 'id' COMMENT '继承字段_主键 inherit_type=1时有用',
  `inherit_field_child` varchar(64) DEFAULT 'pid' COMMENT '继承字段_外键 inherit_type=1时有用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='属性定义 关联资源实体、操作者实体、操作项实体、授权结果实体的表。';
INSERT IGNORE INTO `hy_pcm058_acm_def_attribute` (`id`,`fid`,`attr_code`,`attr_field`,`attr_type`,`attr_value_table`,`attr_id_field`,`attr_value_field`,`ref_midd_table`,`ref_main_field`,`ref_sub_field`,`inherit_type`,`inherit_field_parent`,`inherit_field_child`) VALUES ('1','101','ROLE','role','MIDD_TABLE','role_info','id','id','role_user','user_id','role_id','FLATTEN','id','pid'),('2','1001','FUNCTION_ITEM','code','MAIN_TABLE','acm_authority','id','code',null,null,null,'FLATTEN','id','pid'),('3','1002','API_ITEM','code','MAIN_TABLE','acm_authority_data','id','code',null,null,null,'FLATTEN','id','pid'),('4','1003','API_FUNCTION_ITEM','id','MAIN_TABLE','acm_api_authority','id','id',null,null,null,'FLATTEN','id','pid');
###end_paragraph
