DROP TABLE IF EXISTS `hy_pcm058_system_variable`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_system_variable` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `variable_name` varchar(100) NOT NULL COMMENT '变量名',
  `variable_code` varchar(100) NOT NULL COMMENT '编码',
  `variable_desc` varchar(100) NOT NULL COMMENT '变量描述',
  `variable_type` varchar(100) NOT NULL COMMENT '变量类型',
  `api_metadata_id` bigint(20) NOT NULL COMMENT '接口id',
  `status` tinyint(4) NOT NULL COMMENT '状态  1:启用  0:禁用',
  `created_by` bigint(20) DEFAULT NULL COMMENT '创建人',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `modified_by` varchar(100) DEFAULT NULL COMMENT '更新人',
  `gmt_modified` datetime DEFAULT NULL COMMENT '更新时间',
  `version` bigint(20) DEFAULT NULL COMMENT '乐观锁',
  `delete_flag` tinyint(4) DEFAULT NULL COMMENT '逻辑删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统变量';
INSERT IGNORE INTO `hy_pcm058_system_variable` (`id`,`variable_name`,`variable_code`,`variable_desc`,`variable_type`,`api_metadata_id`,`status`,`created_by`,`gmt_create`,`modified_by`,`gmt_modified`,`version`,`delete_flag`) VALUES ('1474023418448982016','祖父级机构编码','grandfather_code','祖父级机构编码','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:25.0','2',null),('1474023418465759232','祖父级机构名称','grandfather_name','祖父级机构名称','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:29.0','2',null),('1474023418478342144','上级级机构编码','superior_code','上级级机构编码','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:15.0','2',null),('1474023418495119360','上级级机构名称','superior_name','上级级机构名称','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:19.0','2',null),('1474023418511896576','当前机构编码','present_code','当前机构编码','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:22.0','2',null),('1474023418541256704','当前机构名称','present_name','当前机构名称','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:40.0','2',null),('1474023418553839616','下级机构编码','lower_code','下级机构编码','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:37.0','2',null),('1474023418599976960','下级机构名称','lower_name','下级机构名称','STRING','1473998710743642112','1','1295915065878388737','2021-12-23 22:25:43.0','1295915065878388737','2021-12-23 22:26:33.0','2',null),('1646771036991139840','当前岗位编号','pos_code','pos_code岗位编号','STRING','1646767535108009984','1','1543883730203062289','2023-04-14 15:03:05.0','1543883730203062289','2023-04-14 15:03:05.0','1',null),('1646771037020499968','当前岗位名称','pos_name','pos_name岗位名称','STRING','1646767535108009984','1','1543883730203062289','2023-04-14 15:03:05.0','1543883730203062289','2023-04-14 15:03:05.0','1',null),('1646780043373981696','当前分组id','group_id','group_id分组id','STRING_NUMBER','1646776169317675008','1','1543883730203062289','2023-04-14 15:38:52.0','1543883730203062289','2023-04-14 15:38:52.0','1',null),('1646783206760001536','当前人员编码','hr_member_code','hr_member_code人员code','STRING','1646782162940342272','1','1543883730203062289','2023-04-14 15:51:26.0','1543883730203062289','2023-04-14 15:51:26.0','1',null);
###end_paragraph
