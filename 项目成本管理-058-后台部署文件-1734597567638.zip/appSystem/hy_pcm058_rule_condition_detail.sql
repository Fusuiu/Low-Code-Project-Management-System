DROP TABLE IF EXISTS `hy_pcm058_rule_condition_detail`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_rule_condition_detail` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `fid` decimal(20,0) NOT NULL COMMENT '外键',
  `order_number` decimal(20,0) NOT NULL COMMENT '序号',
  `cell_or_function_variable` text COMMENT '列名/函数变量',
  `cond` varchar(10) NOT NULL COMMENT '条件',
  `value_type` varchar(128) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL COMMENT '值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='校验规则条件信息表';
