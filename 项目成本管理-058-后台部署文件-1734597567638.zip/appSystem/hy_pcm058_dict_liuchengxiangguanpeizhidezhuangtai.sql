DROP TABLE IF EXISTS `hy_pcm058_dict_liuchengxiangguanpeizhidezhuangtai`;
CREATE TABLE IF NOT EXISTS `hy_pcm058_dict_liuchengxiangguanpeizhidezhuangtai` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `render_bg_color` varchar(16) DEFAULT NULL COMMENT '字典项背景颜色',
  `code` varchar(32) NOT NULL COMMENT '字典项编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pid` decimal(20,0) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `render_font_color` varchar(16) DEFAULT NULL COMMENT '字典项字体颜色',
  `name` varchar(32) NOT NULL COMMENT '字典项名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_RFmDSrKy` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='流程相关配置的状态';
INSERT IGNORE INTO `hy_pcm058_dict_liuchengxiangguanpeizhidezhuangtai` (`create_user_id`,`render_bg_color`,`code`,`create_user_name`,`create_time`,`data_version`,`level`,`pid`,`last_update_user_id`,`last_update_time`,`sequence`,`path`,`render_font_color`,`name`,`id`,`last_update_user_name`) VALUES ('1295915065878388737','#fff','0',null,'2022-07-11 11:48:32.0','1','1',null,'1295915065878388737','2022-07-11 11:48:32.0','1',null,'#000','禁用','1546340639338278912',null),('1295915065878388737','#fff','1',null,'2022-07-11 11:48:32.0','1','1',null,'1295915065878388737','2022-07-11 11:48:32.0','2',null,'#000','启用','1546340639338278913',null);
###end_paragraph
