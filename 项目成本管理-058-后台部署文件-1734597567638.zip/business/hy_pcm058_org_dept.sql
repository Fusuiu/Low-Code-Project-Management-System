CREATE TABLE IF NOT EXISTS `hy_pcm058_org_dept` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `level` int(3) NOT NULL COMMENT '层级',
  `pcode` varchar(32) DEFAULT NULL COMMENT '上级机构编号',
  `pid` decimal(20,0) DEFAULT NULL COMMENT '父节点',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `_statusname` varchar(32) DEFAULT NULL COMMENT '机构状态显示值',
  `branch_leader_code` varchar(32) DEFAULT NULL COMMENT '分管领导编号',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `path` varchar(512) DEFAULT NULL COMMENT '路径',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `manager_id` decimal(20,0) DEFAULT NULL COMMENT '机构负责人id',
  `manager_code` varchar(32) DEFAULT NULL COMMENT '负责人编号',
  `name` varchar(32) DEFAULT NULL COMMENT '名称_不用无法删',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `org_name` varchar(32) NOT NULL COMMENT '机构名称',
  `org_code` varchar(32) NOT NULL COMMENT '机构编号',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `status` varchar(32) NOT NULL COMMENT '机构状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_pgsoo10cs4` (`sequence`) USING BTREE,
  KEY `idx_jM7k1wWe` (`org_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='机构信息表';
INSERT IGNORE INTO `hy_pcm058_org_dept` (`create_user_id`,`create_time`,`create_user_name`,`data_version`,`level`,`pcode`,`pid`,`last_update_user_id`,`_statusname`,`branch_leader_code`,`last_update_time`,`path`,`sequence`,`manager_id`,`manager_code`,`name`,`id`,`org_name`,`org_code`,`last_update_user_name`,`status`) VALUES ('1','2024-12-09 15:49:04.0','admin','0','1',null,null,'1','正常',null,'2024-12-09 15:50:20.0','','1',null,null,null,'1866027264331862017','业务系统一科','D001','admin','0'),('1','2024-12-09 15:49:21.0','admin','0','1',null,null,'1','正常',null,'2024-12-09 15:50:25.0','','2',null,null,null,'1866027335962185729','业务系统二科','D002','admin','0'),('1','2024-12-09 15:49:41.0','admin','0','1',null,null,'1','正常',null,'2024-12-09 15:50:32.0','','3',null,null,null,'1866027419558858753','业务系统三科','D003','admin','0');
###end_paragraph
