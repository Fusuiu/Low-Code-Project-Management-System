CREATE TABLE IF NOT EXISTS `hy_pcm058_role_user` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `role_id` decimal(20,0) NOT NULL COMMENT '角色主键',
  `user_id` decimal(20,0) NOT NULL COMMENT '用户主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_ouJZzBW5` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='用户角色关联表';
INSERT IGNORE INTO `hy_pcm058_role_user` (`create_user_id`,`last_update_time`,`sequence`,`create_user_name`,`create_time`,`role_id`,`user_id`,`data_version`,`id`,`last_update_user_id`,`last_update_user_name`) VALUES ('1','2024-12-15 21:31:54.0','12','admin','2024-12-15 21:31:54.0','1529358636768436224','1868285433114021888','0','1868287871682834433','1','admin'),('1','2024-12-15 21:31:54.0','13','admin','2024-12-15 21:31:54.0','1529358636768436224','1868285549502230528','0','1868287871682834434','1','admin'),('1','2024-12-15 21:31:54.0','14','admin','2024-12-15 21:31:54.0','1529358636768436224','1868285627471060992','0','1868287871682834435','1','admin'),('1','2024-12-15 21:31:54.0','15','admin','2024-12-15 21:31:54.0','1529358636768436224','1868285733380050944','0','1868287871682834436','1','admin'),('1','2024-12-15 21:31:54.0','16','admin','2024-12-15 21:31:54.0','1529358636768436224','1868287719153688576','0','1868287871682834437','1','admin'),('1','2024-12-15 21:31:54.0','17','admin','2024-12-15 21:31:54.0','1529358636768436224','1868287823507058688','0','1868287871682834438','1','admin');
###end_paragraph
