CREATE TABLE IF NOT EXISTS `hy_pcm058_third_user_relation` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `provider_id` varchar(32) DEFAULT NULL COMMENT '第三方服务商ID',
  `provider_user_id` varchar(32) DEFAULT NULL COMMENT '第三方服务商用户ID',
  `provider_union_id` varchar(32) DEFAULT NULL COMMENT '第三方服务商UnionID',
  `user_account_name` varchar(32) DEFAULT NULL COMMENT '我方账号名',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_jjsgsrx71g` (`sequence`) USING BTREE,
  KEY `idx_qpia9empat` (`provider_user_id`,`provider_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='平台与第三方用户关系表';
