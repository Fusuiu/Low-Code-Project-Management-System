CREATE TABLE IF NOT EXISTS `hy_pcm058_project_team_member_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `hr_code` varchar(32) DEFAULT NULL COMMENT '成员姓名',
  `role_code` varchar(32) DEFAULT NULL COMMENT '角色',
  `role_duty_explain` varchar(256) DEFAULT NULL COMMENT '职责',
  `team_explain` longtext COMMENT '备注',
  `project_code` varchar(32) DEFAULT NULL COMMENT '项目编号',
  `depart` varchar(32) DEFAULT NULL COMMENT '所在机构',
  PRIMARY KEY (`id`),
  KEY `idx_fxo7px3lsf` (`create_time`) USING BTREE,
  KEY `idx_i9wirx4n30` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='项目成员信息表';
INSERT IGNORE INTO `hy_pcm058_project_team_member_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`state`,`_statename`,`hr_code`,`role_code`,`role_duty_explain`,`team_explain`,`project_code`,`depart`) VALUES ('1866687389653618689','0','1','admin','2024-12-11 11:32:10.0','1','admin','2024-12-11 16:30:25.0','2','0','启用','HR-004','R-01','/1',null,null,'D003'),('1866760007788355585','0','1','admin','2024-12-11 16:20:43.0','1','admin','2024-12-11 16:20:43.0','7','0','启用','HR-001','R-02','1','1',null,null),('1866760212338475009','0','1','admin','2024-12-11 16:21:32.0','1','admin','2024-12-11 16:21:32.0','8','0','启用','HR-001','R-04','1','1',null,null),('1866762211762257921','0','1','admin','2024-12-11 16:29:29.0','1','admin','2024-12-11 16:29:29.0','9','0','启用','HR-003','R-03','1','1','P2412110004',null),('1866762333427367937','0','1','admin','2024-12-11 16:29:58.0','1','admin','2024-12-11 16:30:37.0','10','0','启用','HR-007','R-01','/1',null,null,'D001'),('1866762378404782081','0','1','admin','2024-12-11 16:30:08.0','1','admin','2024-12-11 16:30:08.0','11','0','启用','HR-003','R-02','1','1','P2412110005',null),('1866763429749022721','0','1','admin','2024-12-11 16:34:19.0','1','admin','2024-12-11 16:34:19.0','12','1','禁用','HR-001','R-02',null,null,'P2412110004',null),('1866819781383704577','0','1','admin','2024-12-11 20:18:14.0','1','admin','2024-12-11 20:18:14.0','13','1','禁用','HR-009','R-01','/1',null,'P2412110006','D002'),('1867079324664033281','0','1','admin','2024-12-12 13:29:34.0','1','admin','2024-12-12 13:29:34.0','14','0','启用','HR-009','R-01','/','/','P2412110005',null),('1867079405857370113','0','1','admin','2024-12-12 13:29:54.0','1','admin','2024-12-12 13:29:54.0','15','0','启用','HR-002','R-04','1','1','P2412110005',null),('1868458531450085377','0','1','admin','2024-12-16 08:50:03.0','1','admin','2024-12-16 08:50:03.0','17','0','启用','HR-012','R-02','/','/','P2412110002',null),('1868458592191995905','0','1','admin','2024-12-16 08:50:17.0','1','admin','2024-12-16 08:50:17.0','18','0','启用','HR-011','R-03','/','/','P2412110002',null),('1868460117935804417','0','1','admin','2024-12-16 08:56:21.0','1','admin','2024-12-16 08:56:21.0','19','0','启用','HR-008','R-01','/','/','P2412110002',null),('1868460221934952449','0','1','admin','2024-12-16 08:56:46.0','1','admin','2024-12-16 08:56:46.0','20','0','启用','HR-013','R-04','/','/','P2412110002',null),('1868486296509440001','0','1','admin','2024-12-16 10:40:23.0','1','admin','2024-12-16 10:40:23.0','21','1','禁用','HR-007','R-01','/1',null,'P2412160001','D001'),('1868587272166928385','0','1','admin','2024-12-16 17:21:37.0','1','admin','2024-12-16 17:21:37.0','22','1','禁用','HR-004','R-01','/1',null,'P2412160002','D003');
###end_paragraph
