CREATE TABLE IF NOT EXISTS `hy_pcm058_hr_price_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `hour_unit` decimal(8,2) DEFAULT NULL COMMENT '工时单价',
  `he_role` varchar(32) DEFAULT NULL COMMENT '人员角色',
  `task_type_name` varchar(32) DEFAULT NULL COMMENT '任务类型',
  `pr_explain` longtext COMMENT '备注说明',
  `_he_rolename` varchar(32) DEFAULT NULL COMMENT '人员角色显示值',
  PRIMARY KEY (`id`),
  KEY `idx_56osiuohju` (`create_time`) USING BTREE,
  KEY `idx_kxsrjplzkt` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='人员角色单价表';
INSERT IGNORE INTO `hy_pcm058_hr_price_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`state`,`_statename`,`hour_unit`,`he_role`,`task_type_name`,`pr_explain`,`_he_rolename`) VALUES ('1866023442381393921','0','1','admin','2024-12-09 15:33:52.0','1','admin','2024-12-16 09:31:26.0','4','0','启用','30.00','0','T001','/','实习'),('1866024725523845121','0','1','admin','2024-12-09 15:38:58.0','1','admin','2024-12-16 09:31:18.0','5','0','启用','40.00','1','T001','/','试用'),('1866024991190257665','0','1','admin','2024-12-09 15:40:02.0','1','admin','2024-12-16 09:31:23.0','6','0','启用','50.00','2','T001','/','正式'),('1866025048804020225','0','1','admin','2024-12-09 15:40:15.0','1','admin','2024-12-09 15:40:15.0','7','0','启用','30.00','0','T002','/','实习'),('1866025106340679681','0','1','admin','2024-12-09 15:40:29.0','1','admin','2024-12-09 15:40:29.0','8','0','启用','40.00','1','T002','/','试用'),('1866025150548643841','0','1','admin','2024-12-09 15:40:40.0','1','admin','2024-12-09 15:40:40.0','9','0','启用','50.00','2','T002','/','正式'),('1866025201719955457','0','1','admin','2024-12-09 15:40:52.0','1','admin','2024-12-09 15:40:57.0','10','0','启用','30.00','0','T003','/','实习'),('1866025312428609537','0','1','admin','2024-12-09 15:41:18.0','1','admin','2024-12-09 15:41:18.0','11','0','启用','40.00','1','T003','/','试用'),('1866025358673940481','0','1','admin','2024-12-09 15:41:29.0','1','admin','2024-12-09 15:41:29.0','12','0','启用','50.00','2','T003','/','正式');
###end_paragraph
