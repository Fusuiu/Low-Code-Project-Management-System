CREATE TABLE IF NOT EXISTS `hy_pcm058_menu_config` (
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `config` varchar(512) DEFAULT NULL COMMENT '菜单配置json',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_mgrredovsb` (`create_time`) USING BTREE,
  KEY `idx_1kxfm4jndj` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='菜单配置';
INSERT IGNORE INTO `hy_pcm058_menu_config` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`config`) VALUES ('1680817966884589569','0','1','admin','2023-07-17 13:53:26.0','1','admin','2023-07-17 13:53:26.0','1','{\"isFullScreen\":\"0\",\"isShowTopBar\":\"1\",\"isShowAppTab\":\"1\",\"isShowMenu\":\"1\",\"firstLevelMenuLocation\":\"left\"}');
###end_paragraph
