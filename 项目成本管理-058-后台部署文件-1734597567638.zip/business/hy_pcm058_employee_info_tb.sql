CREATE TABLE IF NOT EXISTS `hy_pcm058_employee_info_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `employee_name` varchar(32) DEFAULT NULL COMMENT '人员名称',
  `employee_code` varchar(32) DEFAULT NULL COMMENT '工号',
  `employee_status` varchar(32) DEFAULT NULL COMMENT '人员状态',
  `_employee_statusname` varchar(32) DEFAULT NULL COMMENT '人员身份显示值',
  `depart` varchar(32) DEFAULT NULL COMMENT '所在机构',
  `employee_explain` longtext COMMENT '备注说明',
  `joining_date` date DEFAULT NULL COMMENT '入职日期',
  `reg_date` date DEFAULT NULL COMMENT '转正日期',
  `employee_org` varchar(32) DEFAULT NULL COMMENT '岗位',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fx19lxqe2e` (`employee_code`),
  KEY `idx_agtqdumknl` (`create_time`) USING BTREE,
  KEY `idx_xtl0rcsyaa` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='人员信息表';
INSERT IGNORE INTO `hy_pcm058_employee_info_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`employee_name`,`employee_code`,`employee_status`,`_employee_statusname`,`depart`,`employee_explain`,`joining_date`,`reg_date`,`employee_org`) VALUES ('1866014069805649921','0','1','admin','2024-12-09 14:56:38.0','1','admin','2024-12-09 15:57:39.0','1','张飞','HR-001','0','实习','D001','/','2024-12-08','2025-12-06','W001'),('1866030532406906881','0','1','admin','2024-12-09 16:02:03.0','1','admin','2024-12-09 16:02:03.0','3','刘备','HR-003','2','正式','D003','/','2024-07-12','2024-09-13','W003'),('1866032490547892225','0','1','admin','2024-12-09 16:09:50.0','1','admin','2024-12-13 23:20:09.0','5','周瑜','HR-002','2','正式','D002','/','2024-10-10','2024-12-20','W002'),('1866032616325615617','0','1','admin','2024-12-09 16:10:20.0','1','admin','2024-12-09 16:10:20.0','6','曹操','HR-004','2','正式','D003','/','2024-05-09','2024-12-07','W003'),('1866032942488342529','0','1','admin','2024-12-09 16:11:37.0','1','admin','2024-12-09 16:11:53.0','7','黄盖','HR-005','1','试用','D001','/','2024-12-09','2025-01-04','W001'),('1866033168434434049','0','1','admin','2024-12-09 16:12:31.0','1','admin','2024-12-09 16:12:31.0','8','董卓','HR-006','1','试用','D002','/','2024-12-06','2025-01-03','W002'),('1866043249259548673','0','1','admin','2024-12-09 16:52:35.0','1','admin','2024-12-09 16:52:35.0','9','诸葛亮','HR-007','2','正式','D001','/','2023-12-07','2023-12-15','W003'),('1866044581832937473','0','1','admin','2024-12-09 16:57:52.0','1','admin','2024-12-09 16:57:52.0','10','关羽','HR-008','2','正式','D002','/','2023-10-27','2023-11-30','W002'),('1866819597792010241','0','1','admin','2024-12-11 20:17:31.0','1','admin','2024-12-12 14:41:06.0','11','马超','HR-009','2','正式','D002','/','2024-12-11','2024-12-24','W003'),('1867083830290247681','0','1','admin','2024-12-12 13:47:29.0','1','admin','2024-12-12 13:47:29.0','12','孙策','HR-010','2','正式','D002','/','2024-12-01','2024-12-08','W003'),('1867097450605535233','0','1','admin','2024-12-12 14:41:36.0','1','admin','2024-12-12 14:41:36.0','13','徐盛','HR-011','1','试用','D003','/','2024-12-05','2024-12-21','W001'),('1867097629337411585','0','1','admin','2024-12-12 14:42:18.0','1','admin','2024-12-13 23:31:21.0','14','貂蝉','HR-012','1','试用','D002','/','2024-12-01','2024-12-06','W002'),('1867593400527843329','0','1','admin','2024-12-13 23:32:20.0','1','admin','2024-12-13 23:32:20.0','15','徐庶','HR-013','0','实习','D002','/','2024-12-01','2024-12-06','W002');
###end_paragraph
