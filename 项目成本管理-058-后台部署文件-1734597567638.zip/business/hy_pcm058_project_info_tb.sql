CREATE TABLE IF NOT EXISTS `hy_pcm058_project_info_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `project_name` varchar(32) DEFAULT NULL COMMENT '项目名称',
  `project_code` varchar(64) DEFAULT NULL COMMENT '项目编号',
  `project_state` varchar(32) DEFAULT NULL COMMENT '项目状态',
  `_project_statename` varchar(32) DEFAULT NULL COMMENT '项目状态显示值',
  `project_start_date` date DEFAULT NULL COMMENT '开始日期',
  `project_expected_over_date` date DEFAULT NULL COMMENT '计划结束日期',
  `project_manager` varchar(32) DEFAULT NULL COMMENT '项目经理',
  `depart` varchar(32) DEFAULT NULL COMMENT '项目负责部门',
  `project_budget_cost` int(8) DEFAULT NULL COMMENT '项目预算成本',
  `introduce` longtext COMMENT '项目简介',
  PRIMARY KEY (`id`),
  KEY `idx_sngh54stok` (`create_time`) USING BTREE,
  KEY `idx_f1riczevr3` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='项目信息表';
INSERT IGNORE INTO `hy_pcm058_project_info_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`project_name`,`project_code`,`project_state`,`_project_statename`,`project_start_date`,`project_expected_over_date`,`project_manager`,`depart`,`project_budget_cost`,`introduce`) VALUES ('1866012847564230657','0','1','admin','2024-12-09 14:51:46.0','1','admin','2024-12-09 16:52:56.0','5','图书管理系统','P2412093003','0','未完成','2024-12-09','2025-01-28','HR-007','D001','1000','/'),('1866043715901296641','0','1','admin','2024-12-09 16:54:26.0','1','admin','2024-12-09 16:54:26.0','6','苍穹外卖','P2412092004','0','未完成','2024-12-09','2025-01-28','HR-004','D003','1500','/'),('1866044748611047425','0','1','admin','2024-12-09 16:58:32.0','1','admin','2024-12-09 16:58:41.0','7','虚拟教研室','P2412094002','0','未完成','2024-12-09','2025-01-28','HR-008','D002','2000','/'),('1866655221579370497','0','1','admin','2024-12-11 09:24:20.0','1','admin','2024-12-16 10:06:06.0','9','亚马逊网购平台','P2412110002','0','未完成','2024-12-11','2025-01-30','HR-008','D002','1290','/'),('1866687389175468033','0','1','admin','2024-12-11 11:32:10.0','1','admin','2024-12-14 12:30:05.0','11','财务管理系统','P2412110004','0','未完成','2024-12-11','2025-01-30','HR-004','D003','120','/'),('1866762333226041345','0','1','admin','2024-12-11 16:29:58.0','1','admin','2024-12-16 17:22:18.0','12','行政系统','P2412110005','0','未完成','2024-12-11','2025-01-30','HR-007','D001','200','/');
###end_paragraph
