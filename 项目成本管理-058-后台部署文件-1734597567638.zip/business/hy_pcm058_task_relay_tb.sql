CREATE TABLE IF NOT EXISTS `hy_pcm058_task_relay_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `task_code` varchar(32) DEFAULT NULL COMMENT '任务编号',
  `task_name` varchar(32) DEFAULT NULL COMMENT '任务名称',
  `start_date` date DEFAULT NULL COMMENT '开始时间',
  `end_date` date DEFAULT NULL COMMENT '结束时间',
  `relay_date` datetime DEFAULT NULL COMMENT '转交时间',
  `relay_person` varchar(32) DEFAULT NULL COMMENT '转交人',
  `accept_date` datetime DEFAULT NULL COMMENT '接受时间',
  `accept_person` varchar(32) DEFAULT NULL COMMENT '接受人',
  `accept_hours` decimal(8,2) DEFAULT NULL COMMENT '接受工时',
  `relay_explain` varchar(32) DEFAULT NULL COMMENT '转交说明',
  `project_code` varchar(32) DEFAULT NULL COMMENT '项目编号',
  PRIMARY KEY (`id`),
  KEY `idx_qdyoj5r6us` (`create_time`) USING BTREE,
  KEY `idx_qrcrw6uchw` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='任务转交记录表';
INSERT IGNORE INTO `hy_pcm058_task_relay_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`state`,`_statename`,`task_code`,`task_name`,`start_date`,`end_date`,`relay_date`,`relay_person`,`accept_date`,`accept_person`,`accept_hours`,`relay_explain`,`project_code`) VALUES ('1868281169247956993','0','1','admin','2024-12-15 21:05:16.0','1','admin','2024-12-15 21:20:50.0','1','0','已接受','327','测试','2024-12-01','2024-12-03','2024-12-15 21:03:39.0','HR-009','2024-12-15 21:12:50.0','admin','1.00',null,'P2412110005'),('1868287252503814145','0','1','admin','2024-12-15 21:29:27.0','1868287823507058688','刘备','2024-12-15 21:36:21.0','2','0','已接受','324','财务管理需求分析','2024-12-01','2024-12-04','2024-12-15 21:29:13.0','HR-001','2024-12-15 21:12:21.0','HR-003','2.00',null,'P2412110004'),('1868287369428426753','0','1','admin','2024-12-15 21:29:55.0','1868287719153688576','周瑜','2024-12-15 21:32:46.0','3','0','已接受','322','图书信息管理测试','2024-12-21','2024-12-31','2024-12-15 21:29:49.0','HR-009','2024-12-15 21:12:45.0','HR-002','0.20',null,'P2412110005'),('1868499464378667009','0','1','admin','2024-12-16 11:32:42.0','1','admin','2024-12-16 11:32:42.0','4','1','待接受','339','商品上下架测试','2024-12-25','2024-12-26','2024-12-16 11:32:37.0','HR-011',null,'HR-008','1.20',null,'P2412110002');
###end_paragraph
