CREATE TABLE IF NOT EXISTS `hy_pcm058_page_report_info_api` (
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `lessee_code` varchar(32) DEFAULT NULL COMMENT '租户编码',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `page_report_info_id` bigint(20) DEFAULT NULL COMMENT '页面报表id',
  `business_code` varchar(128) DEFAULT NULL COMMENT 'api编码',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `api_node_sum` varchar(32) DEFAULT NULL COMMENT '节点数',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `api_name` varchar(32) DEFAULT NULL COMMENT 'api名称',
  `id` bigint(20) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `app_code` varchar(32) DEFAULT NULL COMMENT '应用编码',
  PRIMARY KEY (`id`),
  KEY `idx_rjgjfbdl` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='页面报表api信息表';
