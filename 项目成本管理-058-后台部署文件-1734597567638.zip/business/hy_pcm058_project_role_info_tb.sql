CREATE TABLE IF NOT EXISTS `hy_pcm058_project_role_info_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `role_code` varchar(32) DEFAULT NULL COMMENT '角色编号',
  `role_name` varchar(32) DEFAULT NULL COMMENT '角色名称',
  `role_duty_explain` varchar(256) DEFAULT NULL COMMENT '角色职责说明',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ybuksiac40` (`role_code`),
  KEY `idx_pt2er9gi9h` (`create_time`) USING BTREE,
  KEY `idx_wzt65ay9vc` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='项目角色信息表';
INSERT IGNORE INTO `hy_pcm058_project_role_info_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`state`,`_statename`,`role_code`,`role_name`,`role_duty_explain`) VALUES ('1866677226846638081','0','1','admin','2024-12-11 10:51:47.0','1','admin','2024-12-11 10:52:20.0','1','0','启用','R-01','项目经理','/1'),('1866677440749621249','0','1','admin','2024-12-11 10:52:38.0','1','admin','2024-12-11 10:52:38.0','2','0','启用','R-02','产品经理','/2'),('1866677519841611777','0','1','admin','2024-12-11 10:52:57.0','1','admin','2024-12-11 10:52:57.0','3','0','启用','R-03','开发代表','/3'),('1866677619472683009','0','1','admin','2024-12-11 10:53:20.0','1','admin','2024-12-11 10:53:20.0','4','0','启用','R-04','页面配置工程师','/4');
###end_paragraph
