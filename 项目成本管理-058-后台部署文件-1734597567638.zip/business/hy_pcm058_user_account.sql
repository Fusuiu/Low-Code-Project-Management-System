CREATE TABLE IF NOT EXISTS `hy_pcm058_user_account` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `is_system_recode` int(8) DEFAULT NULL COMMENT '系统记录',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `pwd_status` int(8) DEFAULT NULL COMMENT '密码状态1重置状态其他正常状态',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `user_account_name` varchar(32) NOT NULL COMMENT '账号名',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `mobile` varchar(15) DEFAULT NULL COMMENT '手机号码',
  `email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_hyxgjdcqnu` (`sequence`) USING BTREE,
  KEY `idx_nmrjef4cij` (`user_account_name`) USING BTREE,
  KEY `idx_zwrwkrtpdu` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户账号表';
INSERT IGNORE INTO `hy_pcm058_user_account` (`create_user_id`,`is_system_recode`,`create_user_name`,`create_time`,`data_version`,`last_update_user_id`,`pwd_status`,`last_update_time`,`sequence`,`password`,`user_account_name`,`id`,`username`,`last_update_user_name`,`mobile`,`email`) VALUES ('1295915065878388737','1',null,'2022-05-07 13:56:41.0','1','1295915065878388737','2','2022-05-07 13:56:41.0','2','2bmngsSnC1wOy9uaZYBxGw==','admin','1','admin',null,null,null),('1',null,'admin','2024-12-15 21:22:13.0','0','1',null,'2024-12-15 21:22:13.0','4','2bmngsSnC1wOy9uaZYBxGw==','HR-013','1868285433114021888','徐庶','admin',null,null),('1',null,'admin','2024-12-15 21:22:41.0','0','1',null,'2024-12-15 21:22:41.0','5','2bmngsSnC1wOy9uaZYBxGw==','HR-012','1868285549502230528','貂蝉','admin',null,null),('1',null,'admin','2024-12-15 21:22:59.0','0','1',null,'2024-12-15 21:22:59.0','6','2bmngsSnC1wOy9uaZYBxGw==','HR-011','1868285627471060992','徐盛','admin',null,null),('1',null,'admin','2024-12-15 21:23:25.0','0','1',null,'2024-12-15 21:23:25.0','7','2bmngsSnC1wOy9uaZYBxGw==','HR-010','1868285733380050944','孙策','admin',null,null),('1',null,'admin','2024-12-15 21:31:18.0','0','1',null,'2024-12-15 21:31:18.0','8','2bmngsSnC1wOy9uaZYBxGw==','HR-002','1868287719153688576','周瑜','admin',null,null),('1',null,'admin','2024-12-15 21:31:43.0','0','1',null,'2024-12-15 21:31:43.0','9','2bmngsSnC1wOy9uaZYBxGw==','HR-003','1868287823507058688','刘备','admin',null,null);
###end_paragraph
