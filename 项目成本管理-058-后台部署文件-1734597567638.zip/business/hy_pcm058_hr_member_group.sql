CREATE TABLE IF NOT EXISTS `hy_pcm058_hr_member_group` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `group_id` decimal(20,0) NOT NULL COMMENT '分组id',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `hr_member_id` decimal(20,0) NOT NULL COMMENT '人员id',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_qo1cqjpzdw` (`group_id`) USING BTREE,
  KEY `idx_HXgCQnmP` (`sequence`) USING BTREE,
  KEY `idx_jmhwztoii7` (`hr_member_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='分组人员关联表';
