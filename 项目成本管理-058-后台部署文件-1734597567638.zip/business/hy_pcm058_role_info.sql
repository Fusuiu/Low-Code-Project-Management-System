CREATE TABLE IF NOT EXISTS `hy_pcm058_role_info` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `name` varchar(32) NOT NULL COMMENT '角色名称',
  `remark` text COMMENT '备注',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_FgR1N6Ee` (`name`) USING BTREE,
  KEY `idx_e3iZFXdq` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='角色信息表';
INSERT IGNORE INTO `hy_pcm058_role_info` (`create_user_id`,`last_update_time`,`sequence`,`create_user_name`,`create_time`,`data_version`,`name`,`remark`,`id`,`last_update_user_id`,`last_update_user_name`) VALUES ('1','2022-05-25 15:08:17.0','2','admin','2022-05-25 15:08:08.0','0','普通角色','普通角色','1529358636768436224','1','admin');
###end_paragraph
