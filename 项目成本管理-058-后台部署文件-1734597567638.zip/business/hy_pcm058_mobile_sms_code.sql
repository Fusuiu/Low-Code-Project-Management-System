CREATE TABLE IF NOT EXISTS `hy_pcm058_mobile_sms_code` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `sms_code` varchar(32) NOT NULL COMMENT '短信验证码',
  `mobile` varchar(32) NOT NULL COMMENT '手机号',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `send_time` datetime NOT NULL COMMENT '发送时间',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `sms_supplier` varchar(128) DEFAULT NULL COMMENT '短信提供商',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_j6iFBKmV` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手机短信验证码表';
