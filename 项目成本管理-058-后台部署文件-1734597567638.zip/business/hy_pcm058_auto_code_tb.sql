CREATE TABLE IF NOT EXISTS `hy_pcm058_auto_code_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `code_type` varchar(32) DEFAULT NULL COMMENT '编号类型',
  `scene_name` varchar(32) DEFAULT NULL COMMENT '场景名称',
  `folw_length` int(8) DEFAULT NULL COMMENT '流水长度',
  `prefix` varchar(32) DEFAULT NULL COMMENT '前缀',
  PRIMARY KEY (`id`),
  KEY `idx_brp2ogqcwh` (`create_time`) USING BTREE,
  KEY `idx_sz2lzoypbf` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自动编号';
