CREATE TABLE IF NOT EXISTS `hy_pcm058_hr_group` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `_typename` varchar(32) DEFAULT NULL COMMENT '分组类型显示值',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `type` varchar(32) DEFAULT NULL COMMENT '分组类型',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `name` varchar(32) DEFAULT NULL COMMENT '分组名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `belong_account_id` decimal(20,0) DEFAULT NULL COMMENT '所属账户',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_ej6xzukbgc` (`sequence`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='人员分组表';
