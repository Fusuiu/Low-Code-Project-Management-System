CREATE TABLE IF NOT EXISTS `hy_pcm058_table_style_definition` (
  `page_id` decimal(20,0) DEFAULT NULL COMMENT '页面主键',
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `widget_id` varchar(100) DEFAULT NULL COMMENT '控件主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `user_id` decimal(20,0) NOT NULL COMMENT '用户主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_u6kb2sj3v9` (`sequence`) USING BTREE,
  KEY `hy_8test8_table_style_definition_user_id_IDX` (`user_id`,`widget_id`,`page_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='表格样式主表';
INSERT IGNORE INTO `hy_pcm058_table_style_definition` (`page_id`,`create_user_id`,`last_update_time`,`sequence`,`widget_id`,`create_time`,`create_user_name`,`user_id`,`data_version`,`id`,`last_update_user_id`,`last_update_user_name`) VALUES ('1865942532117913600','1','2024-12-09 14:31:28.0','3','siIKmKsi','2024-12-09 14:31:28.0','admin','1','0','1866007737296605185','1','admin'),('1865969080652947456','1','2024-12-12 14:42:28.0','4','iYHJWBue','2024-12-12 14:42:28.0','admin','1','0','1867097670008664065','1','admin'),('1866015092650172416','1','2024-12-13 23:25:16.0','9','UuZdSxGD','2024-12-13 23:25:16.0','admin','1','0','1867591625364172801','1','admin'),('1867459555495374848','1','2024-12-16 10:47:26.0','14','jaWWCenJ','2024-12-16 10:47:26.0','admin','1','0','1868488073745096705','1','admin'),('1866740906878390272','1','2024-12-16 16:37:23.0','17','iaVRCLeB','2024-12-16 16:37:23.0','admin','1','0','1868576138379485185','1','admin'),('1866818187193831424','1','2024-12-16 17:23:35.0','19','gRKXFeIC','2024-12-16 17:23:35.0','admin','1','0','1868587767620001793','1','admin'),('1866651471054721024','1','2024-12-18 00:55:05.0','21','PoEVuodI','2024-12-18 00:55:05.0','admin','1','0','1869063778886447105','1','admin');
###end_paragraph
