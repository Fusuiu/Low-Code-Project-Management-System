CREATE TABLE IF NOT EXISTS `hy_pcm058_task_type_tb` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `state` varchar(32) DEFAULT NULL COMMENT '状态',
  `_statename` varchar(32) DEFAULT NULL COMMENT '状态显示值',
  `task_type_code` varchar(32) DEFAULT NULL COMMENT '任务类型编号',
  `task_type_name` varchar(32) DEFAULT NULL COMMENT '任务类型名称',
  `task_type_explain` longtext COMMENT '备注说明',
  `internship_hour` decimal(8,2) DEFAULT NULL COMMENT '实习生工时',
  `probation_hours` decimal(8,2) DEFAULT NULL COMMENT '试用生工时',
  `permanent_hours` decimal(8,2) DEFAULT NULL COMMENT '正式工工时',
  PRIMARY KEY (`id`),
  KEY `idx_weii2c0kmp` (`create_time`) USING BTREE,
  KEY `idx_kjvap0xoyx` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='任务类型表';
INSERT IGNORE INTO `hy_pcm058_task_type_tb` (`id`,`data_version`,`create_user_id`,`create_user_name`,`create_time`,`last_update_user_id`,`last_update_user_name`,`last_update_time`,`sequence`,`state`,`_statename`,`task_type_code`,`task_type_name`,`task_type_explain`,`internship_hour`,`probation_hours`,`permanent_hours`) VALUES ('1866018433655738369','0','1','admin','2024-12-09 15:13:58.0','1','admin','2024-12-16 09:19:44.0','1','1','未开始','T001','需求分析','需求分析','4.00','3.00','2.00'),('1866018843493765121','0','1','admin','2024-12-09 15:15:36.0','1','admin','2024-12-12 17:03:33.0','2','1','未开始','T002','开发','开发','4.00','3.00','2.00'),('1866018950109040641','0','1','admin','2024-12-09 15:16:01.0','1','admin','2024-12-12 17:03:22.0','3','1','未开始','T003','测试','测试','3.00','2.00','1.00');
###end_paragraph
