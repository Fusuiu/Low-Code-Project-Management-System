CREATE TABLE IF NOT EXISTS `hy_pcm058_hr_position` (
  `create_user_id` decimal(20,0) NOT NULL COMMENT '创建人主键',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `pos_code` varchar(32) DEFAULT NULL COMMENT '岗位编号',
  `last_update_user_id` decimal(20,0) NOT NULL COMMENT '最后修改人主键',
  `_statusname` varchar(32) DEFAULT NULL COMMENT '岗位状态显示值',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `pos_name` varchar(32) DEFAULT NULL COMMENT '岗位名称',
  `id` decimal(20,0) NOT NULL COMMENT '主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `status` varchar(32) DEFAULT NULL COMMENT '岗位状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_iggtyvvvqn` (`sequence`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='岗位信息表';
INSERT IGNORE INTO `hy_pcm058_hr_position` (`create_user_id`,`create_time`,`create_user_name`,`data_version`,`pos_code`,`last_update_user_id`,`_statusname`,`last_update_time`,`sequence`,`pos_name`,`id`,`last_update_user_name`,`status`) VALUES ('1','2024-12-09 15:47:15.0','admin','0','W001','1','正常','2024-12-09 15:50:06.0','1','部门经理','1866026809747935233','admin','0'),('1','2024-12-09 15:47:52.0','admin','0','W002','1','正常','2024-12-09 15:49:58.0','2','产品经理','1866026963151474689','admin','0'),('1','2024-12-09 15:48:05.0','admin','0','W003','1','正常','2024-12-09 15:49:53.0','3','数字化工程师','1866027016607879169','admin','0');
###end_paragraph
