CREATE TABLE IF NOT EXISTS `hy_pcm058_acm_policy_data_role_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subject_value` varchar(32) NOT NULL,
  `resource_value` varchar(32) NOT NULL,
  `res_type` varchar(32) DEFAULT NULL,
  `bit_code` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1869663581390245889 DEFAULT CHARSET=utf8;
INSERT IGNORE INTO `hy_pcm058_acm_policy_data_role_code` (`id`,`subject_value`,`resource_value`,`res_type`,`bit_code`) VALUES ('1868286937907859461','1529358636768436224','YvOqID1734269218603',null,null),('1869663581390245888','1529358636768436224','oxJlq71734597477275',null,null);
###end_paragraph
