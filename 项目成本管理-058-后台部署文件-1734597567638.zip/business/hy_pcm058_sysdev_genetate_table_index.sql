CREATE TABLE IF NOT EXISTS `hy_pcm058_sysdev_genetate_table_index` (
  `create_user_id` bigint(20) NOT NULL COMMENT '创建人主键',
  `last_update_time` datetime NOT NULL COMMENT '最后修改时间',
  `sequence` bigint(17) NOT NULL AUTO_INCREMENT COMMENT '排序序号',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `create_user_name` varchar(32) DEFAULT NULL COMMENT '创建人名称',
  `data_version` varchar(32) NOT NULL COMMENT '数据版本',
  `id` bigint(20) NOT NULL COMMENT '主键',
  `last_update_user_id` bigint(20) NOT NULL COMMENT '最后修改人主键',
  `last_update_user_name` varchar(32) DEFAULT NULL COMMENT '最后修改人名称',
  `table_code` varchar(128) DEFAULT NULL COMMENT '表编码',
  `api_code` varchar(128) DEFAULT NULL COMMENT 'api编码',
  `field_codes` varchar(128) DEFAULT NULL COMMENT '字段编码',
  PRIMARY KEY (`id`),
  KEY `idx_yfauxmfsfb` (`create_time`) USING BTREE,
  KEY `idx_j7admqophk` (`sequence`) USING BTREE,
  KEY `idx_u1jhdbqpeq` (`api_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='api生成索引记录表';
