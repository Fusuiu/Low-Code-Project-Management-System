var HYENVCONFIG = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // consumer-env-config.prod.ts
  var consumer_env_config_prod_exports = {};
  __export(consumer_env_config_prod_exports, {
    envConfig: () => envConfig
  });
  var envConfig = { "_version": 9, "_offline": false, "appVersion": "1.0.0", "authCenterUrl": "http://192.168.9.4:6060", "saasServerUrl": "http://192.168.9.4:7090", "flowSaasServerUrl": "http://192.168.9.4:12009", "wsSassServerUrl": "ws://192.168.9.4:7090", "comprehensiveUrl": "http://192.168.9.4:8990", "proxy": { "/auth": "http://192.168.9.4:6060", "/node-web": "http://192.168.14.166:22010/node-web" }, "serverProxy": { "/doc": "http://10.0.3.103:28080", "/fcsproxy": "http://10.0.3.103:29090" }, "syncExternalScripts": [], "deferExternalScripts": [], "buildTime": "2024-07-12T01:44:17.903Z", "deploy": true, "deployPrefix": "/bundles", "deployIsRel": true };
  return __toCommonJS(consumer_env_config_prod_exports);
})();
