var Page1526538711339249664 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1526538711339249664: () => Page1526538711339249664
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1526538711339249664 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1526538711339249664",
            pageName: "\u52A8\u6001\u5B57\u6BB5\u8868\u5355",
            apiMeta: {
              "1526530979429232640_list_1652789043572": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.dict_value": {
                    title: "\u5B57\u5178\u503C",
                    __key: "dict_value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.dict_code": {
                    title: "\u5B57\u5178\u7F16\u53F7",
                    __key: "dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.dynamic_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u4E3B\u952E",
                    __key: "dynamic_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  dict_value: {
                    title: "\u5B57\u5178\u503C"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  dict_code: {
                    title: "\u5B57\u5178\u7F16\u53F7"
                  },
                  dynamic_field_id: {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  }
                }
              },
              "1526530979349540864_detail_1652789030918": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.is_search": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                    __key: "is_search",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_search_json": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C_json",
                    __key: "_is_search_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_search_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_search_json"
                  },
                  "__root.result.data._is_search_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_search_json"
                  },
                  "__root.result.data.field_type_name": {
                    title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0",
                    __key: "field_type_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_system_name": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5\u540D\u79F0",
                    __key: "is_system_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_system": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5",
                    __key: "is_system",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u8868Id",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_code": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "field_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_unique": {
                    title: "\u662F\u5426\u552F\u4E00",
                    __key: "is_unique",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_edit": {
                    title: "\u662F\u5426\u53EF\u7F16\u8F91",
                    __key: "is_edit",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_show": {
                    title: "\u662F\u5426\u663E\u793A",
                    __key: "is_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_name": {
                    title: "\u5B57\u6BB5\u540D\u79F0",
                    __key: "field_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_form_show": {
                    title: "\u662F\u5426\u8868\u5355\u663E\u793A",
                    __key: "is_form_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_required": {
                    title: "\u662F\u5426\u5FC5\u586B",
                    __key: "is_required",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_remark": {
                    title: "\u5B57\u6BB5\u5907\u6CE8",
                    __key: "field_remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.check_box_type": {
                    title: "\u9009\u9879\u6846\u7C7B\u578B",
                    __key: "check_box_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_type": {
                    title: "\u5B57\u6BB5\u7C7B\u578B",
                    __key: "field_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_searchname": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C",
                    __key: "_is_searchname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              "1526530979349540864_update_1652789030180": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.data": {
                    title: "\u8868\u6570\u636E",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.data.is_search": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                    __key: "is_search",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.field_type_name": {
                    title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0",
                    __key: "field_type_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_system_name": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5\u540D\u79F0",
                    __key: "is_system_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_system": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5",
                    __key: "is_system",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u8868Id",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.field_code": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "field_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_unique": {
                    title: "\u662F\u5426\u552F\u4E00",
                    __key: "is_unique",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_edit": {
                    title: "\u662F\u5426\u53EF\u7F16\u8F91",
                    __key: "is_edit",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_show": {
                    title: "\u662F\u5426\u663E\u793A",
                    __key: "is_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.field_name": {
                    title: "\u5B57\u6BB5\u540D\u79F0",
                    __key: "field_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_form_show": {
                    title: "\u662F\u5426\u8868\u5355\u663E\u793A",
                    __key: "is_form_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_required": {
                    title: "\u662F\u5426\u5FC5\u586B",
                    __key: "is_required",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.field_remark": {
                    title: "\u5B57\u6BB5\u5907\u6CE8",
                    __key: "field_remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.check_box_type": {
                    title: "\u9009\u9879\u6846\u7C7B\u578B",
                    __key: "check_box_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.field_type": {
                    title: "\u5B57\u6BB5\u7C7B\u578B",
                    __key: "field_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data._is_searchname": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C",
                    __key: "_is_searchname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1526530979429232640_insert_1653450102180": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.dict_value": {
                    title: "\u5B57\u5178\u503C",
                    __key: "dict_value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.dict_code": {
                    title: "\u5B57\u5178\u7F16\u53F7",
                    __key: "dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.custom_dict_list": {
                    title: "\u81EA\u5B9A\u4E49\u9009\u9879\u96C6\u5408",
                    __key: "custom_dict_list",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root.custom_dict_list.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.custom_dict_list"
                  },
                  "__root.custom_dict_list.dict_value": {
                    title: "\u5B57\u5178\u503C",
                    __key: "dict_value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.custom_dict_list"
                  },
                  "__root.custom_dict_list.dict_code": {
                    title: "\u5B57\u5178\u7F16\u53F7",
                    __key: "dict_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.custom_dict_list"
                  },
                  "__root.custom_dict_list.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.custom_dict_list"
                  },
                  "__root.custom_dict_list._type": {
                    title: "\u6279\u91CF\u64CD\u4F5C\u7C7B\u578B",
                    __key: "_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.custom_dict_list"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1526530979349540864_insert_1653450088031": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._is_searchname": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C",
                    __key: "_is_searchname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_system": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5",
                    __key: "is_system",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u8868Id",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.field_code": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "field_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_unique": {
                    title: "\u662F\u5426\u552F\u4E00",
                    __key: "is_unique",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_edit": {
                    title: "\u662F\u5426\u53EF\u7F16\u8F91",
                    __key: "is_edit",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_show": {
                    title: "\u662F\u5426\u663E\u793A",
                    __key: "is_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.field_name": {
                    title: "\u5B57\u6BB5\u540D\u79F0",
                    __key: "field_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_form_show": {
                    title: "\u662F\u5426\u8868\u5355\u663E\u793A",
                    __key: "is_form_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_required": {
                    title: "\u662F\u5426\u5FC5\u586B",
                    __key: "is_required",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.field_remark": {
                    title: "\u5B57\u6BB5\u5907\u6CE8",
                    __key: "field_remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.check_box_type": {
                    title: "\u9009\u9879\u6846\u7C7B\u578B",
                    __key: "check_box_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_system_name": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5\u540D\u79F0",
                    __key: "is_system_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.field_type_name": {
                    title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0",
                    __key: "field_type_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.field_type": {
                    title: "\u5B57\u6BB5\u7C7B\u578B",
                    __key: "field_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_search": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                    __key: "is_search",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1526530979429232640_del_1652789042916": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E\u96C6\u5408",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  },
                  "__root.dynamic_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u4E3B\u952E",
                    __key: "dynamic_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1653562044050: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u4E3B\u952E",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1526530979492147200_insert_1697170074666": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.business_name": {
                    title: "\u5B57\u5178\u4E1A\u52A1\u540D\u79F0",
                    __key: "business_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.ref_table_name": {
                    title: "\u5173\u8054\u8868\u8868\u540D",
                    __key: "ref_table_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.ref_table_id": {
                    title: "\u5B57\u5178\u5173\u8054\u4E3B\u952E",
                    __key: "ref_table_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.business_code": {
                    title: "\u5B57\u5178\u4E1A\u52A1\u7F16\u7801",
                    __key: "business_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.condition_content": {
                    title: "\u6761\u4EF6\u5185\u5BB9",
                    __key: "condition_content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1712672532605317121: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1526530979492147200_detail_1697170075150": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.ref_table_name": {
                    title: "\u5173\u8054\u8868\u8868\u540D",
                    __key: "ref_table_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_name": {
                    title: "\u5B57\u5178\u4E1A\u52A1\u540D\u79F0",
                    __key: "business_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.condition_content": {
                    title: "\u6761\u4EF6\u5185\u5BB9",
                    __key: "condition_content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.ref_table_id": {
                    title: "\u5B57\u5178\u5173\u8054\u4E3B\u952E",
                    __key: "ref_table_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_code": {
                    title: "\u5B57\u5178\u4E1A\u52A1\u7F16\u7801",
                    __key: "business_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1712394246385971200_detail_1697101715711": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.data_dict_name": {
                    title: "\u6570\u636E\u5B57\u5178\u540D\u79F0",
                    __key: "data_dict_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sys_data_dict_id": {
                    title: "\u7CFB\u7EDF\u6570\u636E\u5B57\u5178\u8868\u4E3B\u952E",
                    __key: "sys_data_dict_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1712394246385971200_insert_1697101713970": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.data_dict_name": {
                    title: "\u6570\u636E\u5B57\u5178\u540D\u79F0",
                    __key: "data_dict_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.sys_data_dict_id": {
                    title: "\u7CFB\u7EDF\u6570\u636E\u5B57\u5178\u8868\u4E3B\u952E",
                    __key: "sys_data_dict_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.dynamic_field_id": {
                    title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                    __key: "dynamic_field_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, {
            var_pageInput_0_mode: "REPLACE",
            var_pageInput_1_id: null,
            var_pageInput_2_xdazTknt: null
          }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              showBottomBar: true,
              style: { backgroundColor: "transparent" },
              title: "\u52A8\u6001\u5B57\u6BB5\u8868\u5355",
              sockets: null,
              dss: [
                "1526530979429232640_list_1652789043572",
                "1526530979349540864_detail_1652789030918"
              ],
              requests: {
                "1526530979349540864_detail_1652789030918": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ],
                "1526530979429232640_list_1652789043572": [
                  {
                    field: "dynamic_id",
                    variable: "saveValV2_khTxQNaP",
                    type: "widget"
                  }
                ]
              }
            },
            LdYtbThF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "LdYtbThF",
              title: "\u5B57\u6BB5\u540D\u79F0",
              checkByExp: [],
              visible: true,
              required: true,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$3",
              field: "field_name",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.field_name"
              },
              readOnly: false,
              stringLength: 64,
              note: ""
            },
            eaAzLoxI: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "eaAzLoxI",
              title: "\u5B57\u6BB5\u7F16\u53F7",
              checkByExp: [],
              visible: true,
              required: true,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$2",
              field: "field_code",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.field_code"
              },
              readOnly: false,
              stringLength: 32,
              note: ""
            },
            RKAKoIAr: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "RKAKoIAr",
              title: "\u662F\u5426\u5FC5\u586B",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: true,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$8",
              field: "is_required",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_required"
              },
              readOnly: false,
              stringLength: 2,
              defRealVal: "0",
              linkage: null
            },
            MtAHlJUP: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "MtAHlJUP",
              title: "\u662F\u5426\u552F\u4E00",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: true,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$7",
              field: "is_unique",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_unique"
              },
              readOnly: false,
              stringLength: 2,
              defRealVal: "0",
              linkage: null
            },
            vZcxheOY: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "vZcxheOY",
              title: "\u662F\u5426\u9875\u9762\u663E\u793A",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: true,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$10",
              field: "is_show",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_show"
              },
              readOnly: false,
              stringLength: 2,
              defRealVal: "1",
              linkage: null
            },
            sMdbyFNc: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "sMdbyFNc",
              title: "\u5B57\u6BB5\u7C7B\u578B",
              options: {
                textBox: "\u6587\u672C\u6846",
                dropDownBox: "\u4E0B\u62C9\u6846",
                singleCheckBox: "\u5355\u9009\u6846",
                multiCheckBox: "\u591A\u9009\u6846",
                date: "\u65E5\u671F",
                time: "\u65F6\u95F4",
                dateTime: "\u65E5\u671F\u65F6\u95F4",
                digital: "\u6570\u5B57\u578B",
                multiLineTextBox: "\u591A\u884C\u6587\u672C",
                attachments: "\u9644\u4EF6",
                richTextBox: "\u5BCC\u6587\u672C"
              },
              checkByExp: [],
              visible: true,
              required: true,
              titleAlign: "left",
              style: {},
              readOnly: false,
              widgetCode: "DropdownSelector$1",
              field: "field_type",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.field_type"
              },
              fieldSearch: null,
              propOptions: {
                type: "custom",
                optionsConfig: [
                  { showVal: "\u6587\u672C\u6846", realVal: "textBox" },
                  { showVal: "\u4E0B\u62C9\u6846", realVal: "dropDownBox" },
                  { showVal: "\u5355\u9009\u6846", realVal: "singleCheckBox" },
                  { showVal: "\u591A\u9009\u6846", realVal: "multiCheckBox" },
                  { showVal: "\u65E5\u671F", realVal: "date" },
                  { showVal: "\u65F6\u95F4", realVal: "time" },
                  { showVal: "\u65E5\u671F\u65F6\u95F4", realVal: "dateTime" },
                  { showVal: "\u6570\u5B57\u578B", realVal: "digital" },
                  { showVal: "\u591A\u884C\u6587\u672C", realVal: "multiLineTextBox" },
                  { showVal: "\u9644\u4EF6", realVal: "attachments" },
                  { showVal: "\u5BCC\u6587\u672C", realVal: "richTextBox" }
                ]
              },
              eventTypesWithTags: []
            },
            aZznEeAe: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Radio",
              eventAttr: ["onChange", "onBlur", "onMouseEnter", "onMouseLeave"],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "aZznEeAe",
              title: "\u9009\u9879\u6846\u7C7B\u578B",
              options: {
                customChoice: "\u81EA\u5B9A\u4E49\u9009\u9879",
                dict: "\u7CFB\u7EDF\u5B57\u5178",
                customDict: "\u81EA\u5B9A\u4E49\u5B57\u5178"
              },
              checkByExp: [],
              titleAlign: "left",
              visible: false,
              required: false,
              displayFormat: "horizontal",
              style: {},
              readOnly: false,
              widgetCode: "Radio$1",
              field: "check_box_type",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.check_box_type"
              },
              fieldSearch: null,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1714576076619001856_1697621767966"
                }
              },
              dictMeta: {
                dictBusiCode: "1714576076619001856_1697621767966",
                type: "dict"
              },
              linkage: null,
              optionType: "default",
              checkCustomedRule: null,
              eventTypesWithTags: [],
              dictCondRel: "1",
              dictConditions: [
                { varAlias: 1, field: "code", paramAmount: 1, method: "in" }
              ],
              openDictLoad: false
            },
            QHgTljnq: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "QHgTljnq",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u7CFB\u7EDF\u5B57\u5178\u503C",
              checkByExp: [],
              visible: false,
              showTitleEffective: false,
              required: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$34",
              eventTypesWithTags: [],
              forbidChange: true
            },
            mPGgbWAL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "mPGgbWAL",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u81EA\u5B9A\u4E49\u5B57\u5178",
              checkByExp: [],
              visible: false,
              showTitleEffective: false,
              required: true,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$35",
              eventTypesWithTags: [],
              forbidChange: true
            },
            dUfjOpkM: {
              varMap: {
                dataVal: { type: "array" },
                actualVal: { type: "array" },
                colsVal: { type: "array" },
                displayVal: { type: "array" },
                curRow: { type: "object" },
                checkedRows: { type: "array" }
              },
              widgetRef: "SubformContainer",
              eventAttr: [
                "onRowAdd",
                "onRowDel",
                "onRowCopy",
                "onRowCopyEnd",
                "onRowInsertEnd",
                "onRowBatchDel",
                "onRowSort"
              ],
              isContainer: true,
              parseInReadOnly: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["NormalTable", "FormButton", "FormDivider"]
              },
              id: "dUfjOpkM",
              title: "\u81EA\u5B9A\u4E49\u9009\u9879\u503C",
              titleAlign: "left",
              visible: false,
              rowDirection: "horizonal",
              style: { height: "auto" },
              readOnly: false,
              widgetCode: "SubformContainer$1",
              newBtn: { visible: true },
              headerSticky: false,
              rowHasTitle: null,
              rowTitle: null,
              rowHasNum: true,
              headerBtns: [],
              headerBtnsConfig: [],
              field: "data",
              fieldInfo: {
                ds: "1526530979429232640_list_1652789043572",
                path: "__root.result.data"
              },
              fieldSearch: null,
              fieldColumn: null,
              type: "object",
              __key: "data",
              _type: "objectArray",
              __parent: "__root.result",
              key: "data",
              children: [
                {
                  _dateEngineFieldType: "INT",
                  _fieldSize: 20,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  _decimalSize: 0,
                  type: "string",
                  _remoteType: "string_number",
                  _type: "string",
                  title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                  __key: "create_user_id",
                  __parent: "__root.result.data",
                  key: "data.create_user_id",
                  children: []
                },
                {
                  _dateEngineFieldType: "DATE_TIME",
                  _fieldSize: 0,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  _type: "datetime",
                  type: "string",
                  title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                  __key: "last_update_time",
                  __parent: "__root.result.data",
                  key: "data.last_update_time",
                  children: []
                },
                {
                  _dateEngineFieldType: "INT",
                  _fieldSize: 17,
                  _species: "SYS",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _decimalSize: 0,
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _remoteType: "string_number",
                  _type: "string",
                  title: "\u6392\u5E8F\u5E8F\u53F7",
                  __key: "sequence",
                  __parent: "__root.result.data",
                  key: "data.sequence",
                  children: []
                },
                {
                  _dateEngineFieldType: "DATE_TIME",
                  _fieldSize: 0,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  _type: "datetime",
                  type: "string",
                  title: "\u521B\u5EFA\u65F6\u95F4",
                  __key: "create_time",
                  __parent: "__root.result.data",
                  key: "data.create_time",
                  children: []
                },
                {
                  _dateEngineFieldType: "STRING",
                  _fieldSize: 32,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _type: "string",
                  title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                  __key: "create_user_name",
                  __parent: "__root.result.data",
                  key: "data.create_user_name",
                  children: []
                },
                {
                  _dateEngineFieldType: "STRING",
                  _fieldSize: 32,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _type: "string",
                  title: "\u5B57\u5178\u503C",
                  __key: "dict_value",
                  __parent: "__root.result.data",
                  key: "data.dict_value",
                  children: []
                },
                {
                  _dateEngineFieldType: "INT",
                  _fieldSize: 20,
                  _species: "SYS",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _decimalSize: 0,
                  _dateEngineFieldDataType: "PK",
                  _fieldUse: 1,
                  type: "string",
                  _remoteType: "string_number",
                  _type: "string",
                  title: "\u4E3B\u952E",
                  __key: "id",
                  __parent: "__root.result.data",
                  key: "data.id",
                  children: []
                },
                {
                  _dateEngineFieldType: "INT",
                  _fieldSize: 20,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _decimalSize: 0,
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _remoteType: "string_number",
                  _type: "string",
                  title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                  __key: "last_update_user_id",
                  __parent: "__root.result.data",
                  key: "data.last_update_user_id",
                  children: []
                },
                {
                  _dateEngineFieldType: "STRING",
                  _fieldSize: 32,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _type: "string",
                  title: "\u5B57\u5178\u7F16\u53F7",
                  __key: "dict_code",
                  __parent: "__root.result.data",
                  key: "data.dict_code",
                  children: []
                },
                {
                  _dateEngineFieldType: "INT",
                  _fieldSize: 20,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  _decimalSize: 0,
                  type: "string",
                  _remoteType: "string_number",
                  _type: "string",
                  title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                  __key: "dynamic_field_id",
                  __parent: "__root.result.data",
                  key: "data.dynamic_field_id",
                  children: []
                },
                {
                  _dateEngineFieldType: "STRING",
                  _fieldSize: 32,
                  _species: "SYS_TMPL",
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  _dateEngineFieldDataType: "NORMAL",
                  type: "string",
                  _type: "string",
                  title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                  __key: "last_update_user_name",
                  __parent: "__root.result.data",
                  key: "data.last_update_user_name",
                  children: []
                }
              ],
              inlineBtnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "hYWrHpyc",
                  btnType: "delete",
                  groupId: "nxKkfDYF"
                }
              ],
              rowBtn: [],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "nxKkfDYF", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "dPaTFOKa", type: "inlineBtns" }
              ],
              bodyHeaders: [
                {
                  title: "\u81EA\u5B9A\u4E49\u9009\u9879\u4E3B\u952E",
                  id: "YuIZZkbe",
                  titleAlign: "left",
                  field: "id"
                },
                {
                  title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
                  id: "wfRQFySl",
                  titleAlign: "left",
                  field: "dynamic_field_id"
                },
                {
                  title: "\u7F16\u7801",
                  id: "gkMIsqMP",
                  titleAlign: "left",
                  field: "dict_code"
                },
                {
                  title: "\u9009\u9879\u503C",
                  id: "pQWixipa",
                  titleAlign: "left",
                  field: "dict_value"
                }
              ],
              childMap: {
                YuIZZkbe: { id: "YuIZZkbe" },
                wfRQFySl: { id: "wfRQFySl" },
                gkMIsqMP: { id: "gkMIsqMP" },
                pQWixipa: { id: "pQWixipa" }
              },
              bodyFields: {
                YuIZZkbe: "id",
                wfRQFySl: "dynamic_field_id",
                gkMIsqMP: "dict_code",
                pQWixipa: "dict_value"
              },
              bodyPaths: {
                id: ["YuIZZkbe"],
                dynamic_field_id: ["wfRQFySl"],
                dict_code: ["gkMIsqMP"],
                dict_value: ["pQWixipa"]
              },
              visibleCols: [false, false, true, true],
              treeNodePath: [0, 7]
            },
            YuIZZkbe: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "YuIZZkbe",
              title: "\u81EA\u5B9A\u4E49\u9009\u9879\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              titleAlign: "left",
              widgetCode: "FormInput$15",
              field: "id",
              fieldInfo: {
                ds: "1526530979429232640_list_1652789043572",
                path: "__root.result.data.id"
              },
              readOnly: false,
              linkage: null,
              stringLength: 20,
              _props: { title: "\u81EA\u5B9A\u4E49\u9009\u9879\u4E3B\u952E" }
            },
            wfRQFySl: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "wfRQFySl",
              title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              stringLength: 20,
              widgetCode: "FormInput$31",
              field: "dynamic_field_id",
              fieldInfo: {
                ds: "1526530979429232640_list_1652789043572",
                path: "__root.result.data.dynamic_field_id"
              },
              readOnly: false,
              linkage: null,
              _props: { title: "\u52A8\u6001\u5B57\u6BB5\u8868\u4E3B\u952E" }
            },
            gkMIsqMP: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "gkMIsqMP",
              title: "\u7F16\u7801",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$32",
              field: "dict_code",
              fieldInfo: {
                ds: "1526530979429232640_list_1652789043572",
                path: "__root.result.data.dict_code"
              },
              readOnly: false,
              _props: { title: "\u7F16\u7801" }
            },
            pQWixipa: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "pQWixipa",
              title: "\u9009\u9879\u503C",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$33",
              field: "dict_value",
              fieldInfo: {
                ds: "1526530979429232640_list_1652789043572",
                path: "__root.result.data.dict_value"
              },
              readOnly: false,
              _props: { title: "\u9009\u9879\u503C" }
            },
            nxKkfDYF: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "nxKkfDYF",
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              visible: true,
              btnsConfig: [],
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            dPaTFOKa: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "dPaTFOKa",
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              visible: true,
              customId: "dUfjOpkM_subFormInlineBtns",
              btnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "hYWrHpyc",
                  btnType: "delete",
                  groupId: "nxKkfDYF"
                }
              ]
            },
            hYWrHpyc: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "hYWrHpyc",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: {
                padding: "0px 4px 0px 4px",
                cursor: "pointer",
                borderRadius: "6px",
                height: "28px",
                lineHeight: "28px",
                fontSize: "12px",
                color: "#096dd9"
              },
              size: "middle",
              $lazyload: false,
              type: "link",
              groupBtnId: "nxKkfDYF"
            },
            XaepAfWL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "XaepAfWL",
              title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
              options: { 0: "\u5426", 1: "\u662F" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$2",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1579297419265454080_1665368821425"
                }
              },
              dictMeta: {
                dictBusiCode: "1579297419265454080_1665368821425",
                type: "dict"
              },
              autoComplete: {
                queryFields: [],
                listShowFields: [],
                splitMark: ",",
                customSplitMark: ""
              },
              field: "is_search",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_search"
              },
              fieldSearch: null,
              fieldColumn: null,
              type: "string",
              __key: "is_search",
              _type: "string",
              __parent: "__root.result.data",
              key: "data.is_search",
              children: [],
              _default: "0",
              _dateEngineFieldType: "STRING",
              _associatedReference: {
                fieldCode: "is_search",
                fieldName: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                refDisplayFieldCode: "name",
                refDisplayFieldId: 1576103853093433300,
                refDisplayFieldName: "\u5B57\u5178\u9879\u540D\u79F0",
                refFieldCode: "code",
                refFieldId: 1579353668774408200,
                refFieldName: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                refTableCode: "dict_shifou",
                refTableId: 1576103853051490300,
                refTableName: "\u662F\u5426",
                tableCode: "md_json_dynamic_fields",
                tableId: 1526530979349540900,
                tableName: "JSON\u52A8\u6001\u5B57\u6BB5\u8868"
              },
              _fieldSize: 32,
              _species: "BIS",
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              _dateEngineFieldDataType: "DICT",
              _dictionaryBusinessCode: "1579297419265454080_1665368821425",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              linkage: null
            },
            suipCGVw: {
              varMap: {
                saveValV2: { type: "number" },
                realValV2: { type: "number" }
              },
              widgetRef: "FormInputNumber",
              eventAttr: ["onChange", "onBlur", "onClick"],
              group: "formInput",
              widgetType: "form",
              id: "suipCGVw",
              title: "\u6392\u5E8F\u5E8F\u53F7",
              checkByExp: [],
              titleAlign: "left",
              required: false,
              visible: true,
              showTitleEffective: true,
              titleWeight: 400,
              labelColor: "#272727",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              readOnly: false,
              widgetCode: "FormInputNumber$2",
              field: "sequence",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.sequence"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 17
            },
            JyzEjeJZ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Textarea",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "JyzEjeJZ",
              title: "\u5B57\u6BB5\u5907\u6CE8",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$6",
              field: "field_remark",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.field_remark"
              },
              readOnly: false,
              stringLength: 32,
              rows: 3,
              note: ""
            },
            dPXEDloQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "dPXEDloQ",
              title: "\u662F\u5426\u8868\u5355\u663E\u793A",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$23",
              field: "is_form_show",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_form_show"
              },
              readOnly: false,
              stringLength: 2,
              defRealVal: "1",
              linkage: null
            },
            fmiderTS: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "Radio",
              eventAttr: ["onChange", "onBlur", "onMouseEnter", "onMouseLeave"],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "fmiderTS",
              title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5",
              options: { 0: "\u5426", 1: "\u662F" },
              checkByExp: [],
              titleAlign: "left",
              visible: false,
              isDataWidget: true,
              required: false,
              displayFormat: "horizontal",
              style: {},
              readOnly: false,
              widgetCode: "Radio$2",
              propOptions: {
                type: "custom",
                optionsConfig: [
                  { showVal: "\u5426", realVal: "0" },
                  { showVal: "\u662F", realVal: "1" }
                ]
              },
              field: "is_system",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.is_system"
              },
              fieldSearch: null,
              defRealVal: "0",
              linkage: null
            },
            rhFnpKof: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "rhFnpKof",
              title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$28",
              field: "field_type_name",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.field_type_name"
              },
              readOnly: false,
              stringLength: 64,
              linkage: null
            },
            VXdBHkwG: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "VXdBHkwG",
              title: "JSON\u7247\u6BB5\u8868Id",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$16",
              field: "json_clips_id",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.json_clips_id"
              },
              readOnly: false,
              stringLength: 20,
              linkage: null
            },
            khTxQNaP: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "khTxQNaP",
              title: "\u52A8\u6001\u5B57\u6BB5\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$17",
              field: "id",
              fieldInfo: {
                ds: "1526530979349540864_detail_1652789030918",
                path: "__root.result.data.id"
              },
              readOnly: false,
              stringLength: 20,
              linkage: null
            },
            RRkwfHaM: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "RRkwfHaM",
              contentAlign: "right",
              style: {}
            },
            vrywxxXV: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "vrywxxXV",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 },
              widgetCode: "FormButton$4",
              eventTypesWithTags: []
            },
            qYNoxJFL: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "qYNoxJFL",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 },
              type: "default",
              eventTypesWithTags: []
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "detail",
                            void 0
                          )) || false;
                          return $1$ || $2$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1526530979429232640_list_1652789043572",
                                      method: "post",
                                      range: [
                                        {
                                          dynamic_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                            {
                                              id: "khTxQNaP",
                                              fromPaths: pageCtx.fromPaths,
                                              propPath: ["saveValV2"]
                                            }
                                          )
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1526530979349540864_detail_1652789030918",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_WJHZamnD",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_1_id"
                            }),
                            null,
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "dict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1526530979492147200_detail_1697170075150",
                                  input: [
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.business_name",
                                      widgetId: "QHgTljnq",
                                      propPath: ["realValV2"]
                                    },
                                    {
                                      field: "__root.result.data.business_code",
                                      widgetId: "QHgTljnq",
                                      propPath: ["saveValV2"]
                                    },
                                    {
                                      field: "__root.result.data.ref_table_name",
                                      propPath: ["var_customed_1_bntQnYVM"]
                                    },
                                    {
                                      field: "__root.result.data.ref_table_id",
                                      propPath: ["var_customed_2_sCPEWzoS"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u67E5\u8BE2[JSON\u5B57\u5178\u5173\u8054\u8868]\u8868\u8BE6\u60C5" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_lMYoMZUx",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_1_id"
                            }),
                            null,
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "customDict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1712394246385971200_detail_1697101715711",
                                  input: [
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.data_dict_name",
                                      widgetId: "mPGgbWAL",
                                      propPath: ["realValV2"]
                                    },
                                    {
                                      field: "__root.result.data.sys_data_dict_id",
                                      widgetId: "mPGgbWAL",
                                      propPath: ["saveValV2"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u67E5\u8BE2[JSON\u7CFB\u7EDF\u6570\u636E\u5B57\u5178\u5173\u8054\u8868]\u8868\u8BE6\u60C5"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "detail",
                            void 0
                          )) || false;
                          return $1$ || $2$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1526530979429232640_list_1652789043572",
                                      method: "post",
                                      range: [
                                        {
                                          dynamic_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                            {
                                              id: "khTxQNaP",
                                              fromPaths: pageCtx.fromPaths,
                                              propPath: ["saveValV2"]
                                            }
                                          )
                                        }
                                      ]
                                    },
                                    {
                                      ds: "1526530979349540864_detail_1652789030918",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_WJHZamnD",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_1_id"
                            }),
                            null,
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "dict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: []
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_lMYoMZUx",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_1_id"
                            }),
                            null,
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "customDict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            sMdbyFNc: {
              onChange: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_KUpmGzvV" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "XaepAfWL",
                                    path: "saveValV2",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_KUpmGzvV",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            QHgTljnq: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "xiaTiMSf",
                                      path: [
                                        "lastSelectedRow",
                                        "business_code",
                                        "saveValV2"
                                      ]
                                    },
                                    {
                                      widgetId: "xiaTiMSf",
                                      path: [
                                        "lastSelectedRow",
                                        "business_name",
                                        "saveValV2"
                                      ]
                                    },
                                    {
                                      widgetId: "xiaTiMSf",
                                      path: [
                                        "lastSelectedRow",
                                        "table_name",
                                        "saveValV2"
                                      ]
                                    },
                                    {
                                      widgetId: "xiaTiMSf",
                                      path: [
                                        "lastSelectedRow",
                                        "table_id",
                                        "saveValV2"
                                      ]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1714577384063250432",
                                  appType: "currentApp",
                                  showCloseIcon: true,
                                  popupMode: "openModal",
                                  isMask: true,
                                  openType: "openModal",
                                  adsorbPosition: "topLeft",
                                  adsorbOffset: {
                                    horizontal: "8px",
                                    vertical: "8px"
                                  },
                                  closePopup: false,
                                  showTopBar: true,
                                  slidePlacement: "right",
                                  mini: false,
                                  fullscreen: true,
                                  Drag: false,
                                  pageNameCn: "\u9009\u62E9\u6570\u636E\u5B57\u5178",
                                  extraprops: { width: "70vw", height: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "saveValV2_QHgTljnq",
                                      widgetId: "QHgTljnq",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "xiaTiMSf",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "lastSelectedRow",
                                            "business_code",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_QHgTljnq",
                                      widgetId: "QHgTljnq",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "xiaTiMSf",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "lastSelectedRow",
                                            "business_name",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    },
                                    {
                                      key: "var_customed_1_bntQnYVM",
                                      widgetId: "",
                                      propPath: ["var_customed_1_bntQnYVM"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "xiaTiMSf",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "lastSelectedRow",
                                            "table_name",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    },
                                    {
                                      key: "var_customed_2_sCPEWzoS",
                                      widgetId: "",
                                      propPath: ["var_customed_2_sCPEWzoS"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "xiaTiMSf",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "lastSelectedRow",
                                            "table_id",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "XZLJVVZQ"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u52A8\u6001\u5B57\u6BB5\u9009\u62E9\u7CFB\u7EDF\u5B57\u5178" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            mPGgbWAL: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "ZYseVMsM",
                                      path: ["selectedData", "id"]
                                    },
                                    {
                                      widgetId: "ZYseVMsM",
                                      path: ["selectedData", "name"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1715336371511635968",
                                  appType: "currentApp",
                                  showCloseIcon: true,
                                  popupMode: "openModal",
                                  isMask: true,
                                  openType: "openModal",
                                  adsorbPosition: "topLeft",
                                  adsorbOffset: {
                                    horizontal: "8px",
                                    vertical: "8px"
                                  },
                                  closePopup: false,
                                  showTopBar: true,
                                  slidePlacement: "right",
                                  mini: false,
                                  fullscreen: true,
                                  Drag: false,
                                  pageNameCn: "\u81EA\u5B9A\u4E49\u5B57\u5178",
                                  extraprops: { width: "70vw", height: null },
                                  inputParams: [],
                                  outputParams: [
                                    {
                                      key: "saveValV2_mPGgbWAL",
                                      widgetId: "mPGgbWAL",
                                      propPath: ["saveValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "ZYseVMsM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "id"]
                                        }
                                      }
                                    },
                                    {
                                      key: "realValV2_mPGgbWAL",
                                      widgetId: "mPGgbWAL",
                                      propPath: ["realValV2"],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "ZYseVMsM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["selectedData", "name"]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "ghKaQKHW"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u6253\u5F00\u9875\u9762:\u52A8\u6001\u5B57\u6BB5\u9009\u62E9\u81EA\u5B9A\u4E49\u5B57\u5178"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            vrywxxXV: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "fmiderTS",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "0",
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "sMdbyFNc",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_UDxwofjv",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1712672532605317121",
                                  input: [
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u5220\u9664JSON\u52A8\u6001\u5B57\u6BB5\u9009\u9879\u6846\u5173\u8054\u4FE1\u606F" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_RXgUxHqn",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "sMdbyFNc",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_PquKAcZs",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "customChoice",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "dUfjOpkM",
                                      path: ["colsVal", "saveValV2_pQWixipa"]
                                    },
                                    {
                                      widgetId: "dUfjOpkM",
                                      path: ["colsVal", "saveValV2_gkMIsqMP"]
                                    },
                                    {
                                      widgetId: "dUfjOpkM",
                                      path: ["colsVal", "saveValV2_YuIZZkbe"]
                                    },
                                    {
                                      widgetId: "dUfjOpkM",
                                      path: ["colsVal", "_type"]
                                    },
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { formCheckBool: true, actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1526530979429232640_insert_1653450102180",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.custom_dict_list.dict_value": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "dUfjOpkM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_pQWixipa"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.custom_dict_list.dict_code": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "dUfjOpkM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_gkMIsqMP"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.custom_dict_list.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "dUfjOpkM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_YuIZZkbe"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.custom_dict_list._type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "dUfjOpkM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["colsVal", "_type"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.custom_dict_list.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: false,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u65B0\u589E\u81EA\u5B9A\u4E49\u9009\u9879" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f, _g, _h;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_kFjYdmjO",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "fmiderTS",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "0",
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "sMdbyFNc",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_BWAvDKix",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $4$ = ((_h = (_g = platform_utils_default).executeCond) == null ? void 0 : _h.call(
                            _g,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "dict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$ && $4$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] },
                                    { widgetId: "QHgTljnq", path: ["saveValV2"] },
                                    { widgetId: "QHgTljnq", path: ["realValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { formCheckBool: true, actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1526530979492147200_insert_1697170074666",
                                  input: [
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.ref_table_name": pageCtx.getDataByPath(
                                        {
                                          target: "customedVar",
                                          path: "var_customed_1_bntQnYVM"
                                        }
                                      )
                                    },
                                    {
                                      "__root.ref_table_id": pageCtx.getDataByPath(
                                        {
                                          target: "customedVar",
                                          path: "var_customed_2_sCPEWzoS"
                                        }
                                      )
                                    },
                                    {
                                      "__root.business_code": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "QHgTljnq",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.business_name": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "QHgTljnq",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["realValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u65B0\u589E[JSON\u5B57\u5178\u5173\u8054\u8868]\u8868\u4FE1\u606F" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d, _e, _f, _g, _h;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_mCalccha",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "fmiderTS",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "0",
                            void 0
                          )) || false;
                          const $3$ = ((_f = (_e = platform_utils_default).executeCond) == null ? void 0 : _f.call(
                            _e,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "sMdbyFNc",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_FYdLkZSc",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $4$ = ((_h = (_g = platform_utils_default).executeCond) == null ? void 0 : _h.call(
                            _g,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "aZznEeAe",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "customDict",
                            void 0
                          )) || false;
                          return $1$ && $2$ && $3$ && $4$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "mPGgbWAL", path: ["realValV2"] },
                                    { widgetId: "mPGgbWAL", path: ["saveValV2"] },
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: true
                                },
                                { formCheckBool: true, actionBeforeCheckTip: {} },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1712394246385971200_insert_1697101713970",
                                  insertType: "submitWholeForm",
                                  input: [],
                                  apiTip: false,
                                  allFormInput: [
                                    {
                                      "__root.data_dict_name": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "mPGgbWAL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["realValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.sys_data_dict_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "mPGgbWAL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u65B0\u589E[JSON\u7CFB\u7EDF\u6570\u636E\u5B57\u5178\u5173\u8054\u8868]\u8868\u4FE1\u606F"
                        }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "fmiderTS", path: ["saveValV2"] },
                                    { widgetId: "VXdBHkwG", path: ["saveValV2"] },
                                    { widgetId: "eaAzLoxI", path: ["saveValV2"] },
                                    { widgetId: "MtAHlJUP", path: ["saveValV2"] },
                                    { widgetId: "vZcxheOY", path: ["saveValV2"] },
                                    { widgetId: "LdYtbThF", path: ["saveValV2"] },
                                    { widgetId: "dPXEDloQ", path: ["saveValV2"] },
                                    { widgetId: "RKAKoIAr", path: ["saveValV2"] },
                                    { widgetId: "JyzEjeJZ", path: ["saveValV2"] },
                                    { widgetId: "aZznEeAe", path: ["saveValV2"] },
                                    { widgetId: "fmiderTS", path: ["realValV2"] },
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] },
                                    { widgetId: "sMdbyFNc", path: ["realValV2"] },
                                    { widgetId: "sMdbyFNc", path: ["saveValV2"] },
                                    { widgetId: "UPOpzeyD", path: ["saveValV2"] },
                                    { widgetId: "XaepAfWL", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  checkRule: { exp: "exp_FeZVeiBk" },
                                  checkTip: "\u5B57\u5178\u503C\u4E0D\u80FD\u4E3A\u7A7A",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1526530979349540864_insert_1653450088031",
                                  insertType: "submitFields",
                                  input: [
                                    {
                                      "__root.is_system": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "fmiderTS",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.json_clips_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "VXdBHkwG",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.field_code": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "eaAzLoxI",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_unique": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "MtAHlJUP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_show": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "vZcxheOY",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.field_name": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "LdYtbThF",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_form_show": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "dPXEDloQ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_required": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "RKAKoIAr",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.field_remark": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "JyzEjeJZ",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.check_box_type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "aZznEeAe",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_system_name": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "fmiderTS",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["realValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.field_type_name": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "sMdbyFNc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["realValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.field_type": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "sMdbyFNc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.sequence": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UPOpzeyD",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.is_search": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "XaepAfWL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  apiTip: true,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "VXdBHkwG", path: ["saveValV2"] },
                                    { widgetId: "khTxQNaP", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1653562044050",
                                  input: [
                                    {
                                      "__root.json_clips_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "VXdBHkwG",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.dynamic_field_id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "khTxQNaP",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u65B0\u589E\u52A8\u6001\u5B57\u6BB5,\u65B0\u589EJSON\u5B57\u6BB5\u6761\u4EF6" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: true
                                },
                                {
                                  formCheckBool: true,
                                  checkRule: { exp: "exp_GGVEmsTF" },
                                  checkTip: "\u5B57\u5178\u503C\u4E0D\u80FD\u4E3A\u7A7A",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.updateDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1526530979349540864_update_1652789030180",
                                  updateType: "submitWholeForm",
                                  input: [],
                                  conditionBasis: [
                                    {
                                      "__root.id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_1_id"
                                      })
                                    }
                                  ],
                                  apiTip: true,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u66F4\u65B0\u52A8\u6001\u5B57\u6BB5" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            qYNoxJFL: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "LdYtbThF",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "eaAzLoxI",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "RKAKoIAr",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "MtAHlJUP",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "vZcxheOY",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "sMdbyFNc",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "aZznEeAe",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "QHgTljnq",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "mPGgbWAL",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "dUfjOpkM",
                  children: [
                    {
                      id: "dUfjOpkM_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "nxKkfDYF",
                          parentToChild: "1:1",
                          type: "node",
                          children: []
                        }
                      ]
                    },
                    {
                      id: "dUfjOpkM_subFormInlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "dPaTFOKa",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "hYWrHpyc",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "dUfjOpkM_subFormBody",
                      type: "renderProp",
                      children: [
                        {
                          id: "YuIZZkbe",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "wfRQFySl",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "gkMIsqMP",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "pQWixipa",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "XaepAfWL",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "suipCGVw",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "JyzEjeJZ",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "dPXEDloQ",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "fmiderTS",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "rhFnpKof",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "VXdBHkwG",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "khTxQNaP",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "RRkwfHaM",
                  children: [
                    {
                      id: "vrywxxXV",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "qYNoxJFL",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_WJHZamnD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["update", "detail"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_lMYoMZUx: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["update", "detail"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_NuejQpXF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) === "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  LdYtbThF: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "LdYtbThF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_chrrgpAz: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$0) === "update";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  eaAzLoxI: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "eaAzLoxI",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_SIYowgyi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  RKAKoIAr: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "RKAKoIAr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_psEaPLdH: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  MtAHlJUP: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "MtAHlJUP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_tSDzjzZs: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vZcxheOY: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "vZcxheOY",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_VqrOydMF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) === "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  sMdbyFNc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "sMdbyFNc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_KUpmGzvV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["richTextBox", "attachments"].includes(param == null ? void 0 : param.$0) ? "0" : param == null ? void 0 : param.$1;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "sMdbyFNc" }] },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  XaepAfWL: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_OxpVZzrr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == "dropDownBox" || (param == null ? void 0 : param.$0) == "singleCheckBox" || (param == null ? void 0 : param.$0) == "multiCheckBox";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aZznEeAe: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "aZznEeAe",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { sMdbyFNc: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_GKsWFLCU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [
                    "dropDownBox",
                    "singleCheckBox",
                    "multiCheckBox"
                  ].includes(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aZznEeAe: [
                    {
                      path: "required",
                      defaultValue: false,
                      id: "aZznEeAe",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { sMdbyFNc: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_JqePMqcI: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) === "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aZznEeAe: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "aZznEeAe",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_lLkAHcFN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [
                    "dropDownBox",
                    "singleCheckBox",
                    "multiCheckBox"
                  ].includes(param == null ? void 0 : param.$0) ? ["customChoice", "dict", "customDict"].includes(param == null ? void 0 : param.$1) ? param == null ? void 0 : param.$1 : "" : "";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aZznEeAe: [
                    { path: "saveValV2", id: "aZznEeAe", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  aZznEeAe: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_VYBpHohp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == "1" ? ["customChoice", "dict"] : ["customChoice", "dict", "customDict"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aZznEeAe: [
                    {
                      path: "dictConditions.0.value",
                      id: "aZznEeAe",
                      type: "widget",
                      action: "changeDictConditions"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { fmiderTS: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_KbElDAKF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"].includes(
                    param == null ? void 0 : param.$0
                  ) && (param == null ? void 0 : param.$1) == "dict";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  QHgTljnq: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "QHgTljnq",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  aZznEeAe: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_IdvMgWTF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) == "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  QHgTljnq: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "QHgTljnq",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_mshfZhho: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"].includes(
                    param == null ? void 0 : param.$0
                  ) && (param == null ? void 0 : param.$1) == "customDict";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  mPGgbWAL: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "mPGgbWAL",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  aZznEeAe: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_wjDTwAUT: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) == "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  mPGgbWAL: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "mPGgbWAL",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_lpQyVuUr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"].includes(
                    param == null ? void 0 : param.$0
                  ) && (param == null ? void 0 : param.$1) == "customChoice";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  dUfjOpkM: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "dUfjOpkM",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  aZznEeAe: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_rgZPnIaA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  dUfjOpkM: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "dUfjOpkM",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_MGqOpnVI: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  YuIZZkbe: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "YuIZZkbe",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_QkhlJiMj: {
              method: (param, pageCtx) => __async(this, null, function* () {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.NoEmpty(param == null ? void 0 : param.$0) ? param == null ? void 0 : param.$0 : yield platform_exp_default.UUID(pageCtx);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              }),
              effect: {
                widget: {
                  YuIZZkbe: [
                    { path: "saveValV2", id: "YuIZZkbe", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  dUfjOpkM: {
                    "curRow.colsVal.saveValV2_YuIZZkbe": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_LOYOZpFM: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  wfRQFySl: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "wfRQFySl",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_mGMfgzQt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  wfRQFySl: [
                    { path: "saveValV2", id: "wfRQFySl", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { khTxQNaP: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_NwQYXzrm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "customChoice";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  gkMIsqMP: [
                    {
                      path: "required",
                      defaultValue: false,
                      id: "gkMIsqMP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { aZznEeAe: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_JDgVEchh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  gkMIsqMP: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "gkMIsqMP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_MacfGRJV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "customChoice";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  pQWixipa: [
                    {
                      path: "required",
                      defaultValue: false,
                      id: "pQWixipa",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { aZznEeAe: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_TGghKmDR: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  pQWixipa: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "pQWixipa",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_fnkdEVJF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || ["attachments", "richTextBox"].includes(param == null ? void 0 : param.$1);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  XaepAfWL: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "XaepAfWL",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { sMdbyFNc: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_rXFwLJlH: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  suipCGVw: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "suipCGVw",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_pcvivsoi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail" || (param == null ? void 0 : param.$1) === "1";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  JyzEjeJZ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "JyzEjeJZ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } },
                widget: { fmiderTS: { saveValV2: { paramKey: "$1" } } }
              }
            },
            exp_nkshIKrm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  dPXEDloQ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "dPXEDloQ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_pKbEAZGM: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  fmiderTS: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "fmiderTS",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_fqxRCcGc: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  rhFnpKof: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "rhFnpKof",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zwwddjgV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  rhFnpKof: [
                    { path: "saveValV2", id: "rhFnpKof", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { sMdbyFNc: { realValV2: { paramKey: "$0" } } }
              }
            },
            exp_YkPSbwoq: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VXdBHkwG: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "VXdBHkwG",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_KEVCwTVF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VXdBHkwG: [
                    { path: "saveValV2", id: "VXdBHkwG", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_2_xdazTknt: { paramKey: "$0" } }
              }
            },
            exp_YTBBbbjZ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  khTxQNaP: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "khTxQNaP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zNUQUAKA: {
              method: (param, pageCtx) => __async(this, null, function* () {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == null || (param == null ? void 0 : param.$0) == "" ? yield platform_exp_default.UUID(pageCtx) : param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              }),
              effect: {
                widget: {
                  khTxQNaP: [
                    { path: "saveValV2", id: "khTxQNaP", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_1_id: { paramKey: "$0" } }
              }
            },
            exp_fhgejlEf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vrywxxXV: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "vrywxxXV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_TDvLEiAK: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vrywxxXV: [
                    {
                      path: "disabled",
                      defaultValue: true,
                      id: "vrywxxXV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_UDxwofjv: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_RXgUxHqn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["insert", "update"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_PquKAcZs: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_kFjYdmjO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["insert", "update"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_BWAvDKix: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_mCalccha: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["insert", "update"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_FYdLkZSc: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["dropDownBox", "singleCheckBox", "multiCheckBox"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_FeZVeiBk: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !(["dropDownBox", "multiCheckBox", "singleCheckBox"].includes(
                    param == null ? void 0 : param.$0
                  ) && (param == null ? void 0 : param.$1) == "0") || (param == null ? void 0 : param.$2) === "customDict" && platform_exp_default.NoEmpty(param == null ? void 0 : param.$3) || (param == null ? void 0 : param.$2) === "dict" && platform_exp_default.NoEmpty(param == null ? void 0 : param.$4) || (param == null ? void 0 : param.$2) === "customChoice";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "exp_FeZVeiBk" }] },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  fmiderTS: { saveValV2: { paramKey: "$1" } },
                  aZznEeAe: { saveValV2: { paramKey: "$2" } },
                  mPGgbWAL: { saveValV2: { paramKey: "$3" } },
                  QHgTljnq: { saveValV2: { paramKey: "$4" } }
                }
              }
            },
            exp_GGVEmsTF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !(["dropDownBox", "multiCheckBox", "singleCheckBox"].includes(
                    param == null ? void 0 : param.$0
                  ) && (param == null ? void 0 : param.$1) == "0") || (param == null ? void 0 : param.$2) === "customDict" && platform_exp_default.NoEmpty(param == null ? void 0 : param.$3) || (param == null ? void 0 : param.$2) === "dict" && platform_exp_default.NoEmpty(param == null ? void 0 : param.$4) || (param == null ? void 0 : param.$2) === "customChoice";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "exp_GGVEmsTF" }] },
              dependentVar: {
                widget: {
                  sMdbyFNc: { saveValV2: { paramKey: "$0" } },
                  fmiderTS: { saveValV2: { paramKey: "$1" } },
                  aZznEeAe: { saveValV2: { paramKey: "$2" } },
                  mPGgbWAL: { saveValV2: { paramKey: "$3" } },
                  QHgTljnq: { saveValV2: { paramKey: "$4" } }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_NuejQpXF", type: "exp" },
                { id: "exp_chrrgpAz", type: "exp" },
                { id: "exp_SIYowgyi", type: "exp" },
                { id: "exp_psEaPLdH", type: "exp" },
                { id: "exp_tSDzjzZs", type: "exp" },
                { id: "exp_VqrOydMF", type: "exp" },
                { id: "exp_JqePMqcI", type: "exp" },
                { id: "exp_IdvMgWTF", type: "exp" },
                { id: "exp_wjDTwAUT", type: "exp" },
                { id: "exp_rgZPnIaA", type: "exp" },
                { id: "exp_MGqOpnVI", type: "exp" },
                { id: "exp_LOYOZpFM", type: "exp" },
                { id: "exp_JDgVEchh", type: "exp" },
                { id: "exp_TGghKmDR", type: "exp" },
                { id: "exp_fnkdEVJF", type: "exp" },
                { id: "exp_rXFwLJlH", type: "exp" },
                { id: "exp_pcvivsoi", type: "exp" },
                { id: "exp_nkshIKrm", type: "exp" },
                { id: "exp_pKbEAZGM", type: "exp" },
                { id: "exp_fqxRCcGc", type: "exp" },
                { id: "exp_YkPSbwoq", type: "exp" },
                { id: "exp_YTBBbbjZ", type: "exp" },
                { id: "exp_fhgejlEf", type: "exp" },
                { id: "exp_TDvLEiAK", type: "exp" }
              ],
              var_pageInput_2_xdazTknt: [{ id: "exp_KEVCwTVF", type: "exp" }],
              var_pageInput_1_id: [{ id: "exp_zNUQUAKA", type: "exp" }]
            },
            widget: {
              fmiderTS: {
                saveValV2: [
                  { id: "exp_NuejQpXF", type: "exp" },
                  { id: "exp_VqrOydMF", type: "exp" },
                  { id: "exp_JqePMqcI", type: "exp" },
                  { id: "exp_VYBpHohp", type: "exp" },
                  { id: "exp_IdvMgWTF", type: "exp" },
                  { id: "exp_wjDTwAUT", type: "exp" },
                  { id: "exp_pcvivsoi", type: "exp" }
                ]
              },
              sMdbyFNc: {
                saveValV2: [
                  { id: "exp_OxpVZzrr", type: "exp" },
                  { id: "exp_GKsWFLCU", type: "exp" },
                  { id: "exp_lLkAHcFN", type: "exp" },
                  { id: "exp_KbElDAKF", type: "exp" },
                  { id: "exp_mshfZhho", type: "exp" },
                  { id: "exp_lpQyVuUr", type: "exp" },
                  { id: "exp_fnkdEVJF", type: "exp" }
                ],
                realValV2: [{ id: "exp_zwwddjgV", type: "exp" }]
              },
              aZznEeAe: {
                saveValV2: [
                  { id: "exp_lLkAHcFN", type: "exp" },
                  { id: "exp_KbElDAKF", type: "exp" },
                  { id: "exp_mshfZhho", type: "exp" },
                  { id: "exp_lpQyVuUr", type: "exp" },
                  { id: "exp_NwQYXzrm", type: "exp" },
                  { id: "exp_MacfGRJV", type: "exp" }
                ]
              },
              dUfjOpkM: {
                "curRow.colsVal.saveValV2_YuIZZkbe": [
                  { id: "exp_QkhlJiMj", type: "exp" }
                ]
              },
              khTxQNaP: { saveValV2: [{ id: "exp_mGMfgzQt", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {
            var_customed_0_RiqKBCeo: "1",
            var_customed_1_bntQnYVM: null,
            var_customed_2_sCPEWzoS: null
          },
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$LdYtbThF`,
            key: `PC$$LdYtbThF`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$eaAzLoxI`,
            key: `PC$$eaAzLoxI`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$RKAKoIAr`,
            key: `PC$$RKAKoIAr`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$MtAHlJUP`,
            key: `PC$$MtAHlJUP`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$vZcxheOY`,
            key: `PC$$vZcxheOY`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$sMdbyFNc`,
            key: `PC$$sMdbyFNc`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$aZznEeAe`,
            key: `PC$$aZznEeAe`,
            pageCtx,
            widgetRef: "Radio"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$QHgTljnq`,
            key: `PC$$QHgTljnq`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$mPGgbWAL`,
            key: `PC$$mPGgbWAL`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$dUfjOpkM`,
            key: `PC$$dUfjOpkM`,
            pageCtx,
            widgetRef: "SubformContainer",
            customBtnRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$nxKkfDYF`,
                  key: `PC$$dUfjOpkM$$nxKkfDYF`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                }
              )
            ],
            inlineBtnsRenderer: ({
              index: dUfjOpkM_indexFromSubform,
              rowIndex: dUfjOpkM_rowIndexFromSubform
            }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$dPaTFOKa`,
                key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$dPaTFOKa`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$dPaTFOKa$$hYWrHpyc`,
                  key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$dPaTFOKa$$hYWrHpyc`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            bodyRenderer: ({
              index: dUfjOpkM_indexFromSubform,
              rowIndex: dUfjOpkM_rowIndexFromSubform
            }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$YuIZZkbe`,
                  key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$YuIZZkbe`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$wfRQFySl`,
                  key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$wfRQFySl`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$gkMIsqMP`,
                  key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$gkMIsqMP`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$pQWixipa`,
                  key: `PC$$dUfjOpkM$$%${dUfjOpkM_rowIndexFromSubform}%$$pQWixipa`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$XaepAfWL`,
            key: `PC$$XaepAfWL`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$suipCGVw`,
            key: `PC$$suipCGVw`,
            pageCtx,
            widgetRef: "FormInputNumber"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$JyzEjeJZ`,
            key: `PC$$JyzEjeJZ`,
            pageCtx,
            widgetRef: "Textarea"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$dPXEDloQ`,
            key: `PC$$dPXEDloQ`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$fmiderTS`,
            key: `PC$$fmiderTS`,
            pageCtx,
            widgetRef: "Radio"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$rhFnpKof`,
            key: `PC$$rhFnpKof`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$VXdBHkwG`,
            key: `PC$$VXdBHkwG`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$khTxQNaP`,
            key: `PC$$khTxQNaP`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$RRkwfHaM`,
            key: `PC$$RRkwfHaM`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$RRkwfHaM$$vrywxxXV`,
              key: `PC$$RRkwfHaM$$vrywxxXV`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$RRkwfHaM$$qYNoxJFL`,
              key: `PC$$RRkwfHaM$$qYNoxJFL`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        )
      );
    }
  };
  __publicField(Page1526538711339249664, "pageName", "\u52A8\u6001\u5B57\u6BB5\u8868\u5355");
  __publicField(Page1526538711339249664, "$pageKey", "XHzbREcm");
  __publicField(Page1526538711339249664, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
