var Page1694617459035877376 = (() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1694617459035877376: () => Page1694617459035877376
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1694617459035877376 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1694617459035877376",
            pageName: "\u6D88\u606F\u8BE6\u60C5\u9875\u9762",
            apiMeta: {
              bis_api_1694283784024895489: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.client_type": {
                    title: "\u8C03\u7528\u7C7B\u578B",
                    __key: "client_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.msg_type": {
                    title: "\u6D88\u606F\u7C7B\u578B",
                    __key: "msg_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.busi_code": {
                    title: "\u4E1A\u52A1\u7F16\u7801",
                    __key: "busi_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_name": {
                    title: "\u5E94\u7528\u540D\u79F0",
                    __key: "app_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u7F16\u7801",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.lessee_code": {
                    title: "\u79DF\u6237\u7F16\u7801",
                    __key: "lessee_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priorityname": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C",
                    __key: "_priorityname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._redirect_url_typename": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B\u663E\u793A\u503C",
                    __key: "_redirect_url_typename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name_1": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0_1",
                    __key: "last_update_user_name_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id_1": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E_1",
                    __key: "last_update_user_id_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id_1": {
                    title: "\u4E3B\u952E_1",
                    __key: "id_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.data_version_1": {
                    title: "\u6570\u636E\u7248\u672C_1",
                    __key: "data_version_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name_1": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0_1",
                    __key: "create_user_name_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time_1": {
                    title: "\u521B\u5EFA\u65F6\u95F4_1",
                    __key: "create_time_1",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence_1": {
                    title: "\u6392\u5E8F\u5E8F\u53F7_1",
                    __key: "sequence_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time_1": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4_1",
                    __key: "last_update_time_1",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id_1": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E_1",
                    __key: "create_user_id_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.template_code": {
                    title: "\u6A21\u677F\u7F16\u7801",
                    __key: "template_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_json": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C_json",
                    __key: "_priority_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._priority_json"
                  },
                  "__root.result.data._priority_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._priority_json"
                  },
                  "__root.result.data.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.url": {
                    title: "\u67E5\u770B\u5730\u5740",
                    __key: "url",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.content": {
                    title: "\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.jump_address_mode": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u65B9\u5F0F",
                    __key: "jump_address_mode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.redirect_url_type": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B",
                    __key: "redirect_url_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._redirect_url_type_json": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B\u663E\u793A\u503C_json",
                    __key: "_redirect_url_type_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._redirect_url_type_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._redirect_url_type_json"
                  },
                  "__root.result.data._redirect_url_type_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._redirect_url_type_json"
                  },
                  "__root.result.data.additional_param": {
                    title: "\u9644\u52A0\u53C2\u6570",
                    __key: "additional_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_readname": {
                    title: "\u662F\u5426\u5DF2\u8BFB2\u663E\u793A\u503C",
                    __key: "_is_readname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.data_version": {
                    title: "\u6570\u636E\u7248\u672C",
                    __key: "data_version",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.fid": {
                    title: "\u5916\u952E",
                    __key: "fid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._fid_json": {
                    title: "\u5916\u952E\u663E\u793A\u503C_json",
                    __key: "_fid_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._fid_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._fid_json"
                  },
                  "__root.result.data._fid_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._fid_json"
                  },
                  "__root.result.data.user_id": {
                    title: "\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_read": {
                    title: "\u662F\u5426\u5DF2\u8BFB",
                    __key: "is_read",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_read_json": {
                    title: "\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C_json",
                    __key: "_is_read_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_read_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_read_json"
                  },
                  "__root.result.data._is_read_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_read_json"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u6D88\u606F\u8BE6\u60C5\u9875\u9762",
              sockets: null,
              dss: ["bis_api_1694283784024895489"],
              requests: {
                bis_api_1694283784024895489: [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              },
              showBottomBar: true,
              $$key: "knjj74s3r9"
            },
            nxStGqdF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "nxStGqdF",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { fontSize: 18, fontWeight: 700 },
              title: "\u6807\u9898",
              checkByExp: [],
              visible: true,
              showTitleEffective: false,
              required: false,
              style: {
                width: "100%",
                overflow: "hidden",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                padding: "0px 0px 0px"
              },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px"
              },
              titleAlign: "left",
              stringLength: 255,
              widgetCode: "FormInput$1",
              field: "title",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.title"
              },
              readOnly: false,
              $$key: "cwct5sowrcn"
            },
            jilVqYwU: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "jilVqYwU",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u521B\u5EFA\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: false,
              style: { padding: "0px 0px 0px" },
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px"
              },
              stringLength: 0,
              widgetCode: "FormDateTimePicker$1",
              field: "create_time",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.create_time"
              },
              readOnly: false,
              $$key: "ieuqdcw7top"
            },
            fZBpPTfL: {
              varMap: {},
              widgetRef: "FormDivider",
              group: "actionControl",
              id: "fZBpPTfL",
              title: "\u5206\u5272\u7EBF",
              titleWeight: 400,
              labelColor: "#272727",
              visible: true,
              showTitleEffective: false,
              lineType: "solid",
              lineWidth: 1,
              type: "horizontalTitleInline",
              titleAlign: "left",
              style: { width: "100%" },
              widgetCode: "FormDivider$1",
              $$key: "a0kcklmw1rm"
            },
            gmgktNnj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              id: "gmgktNnj",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u6D88\u606F\u7C7B\u578B",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$3",
              field: "msg_type",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.msg_type"
              },
              readOnly: false,
              options: {
                text: "\u6587\u672C\u6D88\u606F",
                image: "\u56FE\u7247\u6D88\u606F",
                file: "\u6587\u4EF6\u6D88\u606F",
                link: "\u56FE\u6587\u94FE\u63A5"
              },
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1664168130806689792_1685603577688"
                }
              },
              dictMeta: {
                dictBusiCode: "1664168130806689792_1685603577688",
                type: "dict"
              },
              openDictLoad: false,
              reloadEvents: ["getOptions"],
              $$key: "0kcavvmho5h"
            },
            hSDypJfE: {
              varMap: { saveValV2: { type: "string" }, text: { type: "string" } },
              widgetRef: "RichEditor",
              eventAttr: ["onChange", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "hSDypJfE",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u5185\u5BB9",
              visible: false,
              showTitleEffective: false,
              required: false,
              style: { padding: "0px 0px 0px" },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$2",
              field: "content",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.content"
              },
              fieldSearch: null,
              fieldColumn: null,
              height: 500,
              $$key: "ze62tzj8dc"
            },
            qHXCwFhg: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "qHXCwFhg",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u9644\u52A0\u53C2\u6570",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$4",
              field: "additional_param",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.additional_param"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 65535,
              $$key: "9pcbzmu1rs"
            },
            EqSQrPyD: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "EqSQrPyD",
              titleWeight: 400,
              labelColor: "#272727",
              title: "fileInfo",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$7",
              linkage: null,
              $$key: "xdn1xqx5jca"
            },
            LhhvMvDV: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "LhhvMvDV",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u6A21\u677F\u7F16\u7801",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$9",
              field: "template_code",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.template_code"
              },
              readOnly: false,
              $$key: "ib2stqc6kh"
            },
            cAmFaGdc: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "cAmFaGdc",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u5E94\u7528\u7F16\u7801",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 64,
              widgetCode: "FormInput$8",
              field: "app_code",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.app_code"
              },
              readOnly: false,
              $$key: "p6003kiqalo"
            },
            aBcTAJQN: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "aBcTAJQN",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B",
              options: { IN_SYS: "\u7CFB\u7EDF\u5185", OUT_SYS: "\u7CFB\u7EDF\u5916" },
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1460496781686222848_1637044542300"
                }
              },
              dictMeta: {
                dictBusiCode: "1460496781686222848_1637044542300",
                type: "dict"
              },
              stringLength: 32,
              widgetCode: "DropdownSelector$2",
              field: "redirect_url_type",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.redirect_url_type"
              },
              readOnly: false,
              $$key: "40q2s5wxc1o"
            },
            VLIBOmKQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "VLIBOmKQ",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u8DF3\u8F6C\u5730\u5740\u65B9\u5F0F",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 32,
              widgetCode: "FormInput$10",
              field: "jump_address_mode",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.jump_address_mode"
              },
              readOnly: false,
              $$key: "b4hsznnq9g4"
            },
            nZCHzdUz: {
              varMap: { saveValV2: { type: "string" } },
              widgetRef: "StaticPicture",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              reloadEvents: [],
              id: "nZCHzdUz",
              title: "\u56FE\u7247\u5730\u5740",
              visible: false,
              style: { height: "auto" },
              showTitleEffective: false,
              titleWeight: 400,
              labelColor: "#272727",
              sizeType: "percentage",
              width: "",
              height: "",
              pictureReload: { count: 3, time: 1 },
              widgetCode: "StaticPicture$1",
              $$key: "66lzov6uegq"
            },
            ByRpdhCJ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" },
                fileName: { type: "stringArray" },
                fileIdentifier: { type: "stringArray" },
                fileSize: { type: "stringArray" },
                fileType: { type: "stringArray" },
                filePath: { type: "stringArray" },
                checkedItems: { type: "objectArray" },
                currentItem: { type: "object" }
              },
              widgetRef: "File",
              eventAttr: [
                "onFileUpload",
                "onChange",
                "onDrop",
                "onDownload",
                "onPreview",
                "onRead",
                "onRemove",
                "onChangeCheckedItems"
              ],
              group: "formInput",
              widgetType: "form",
              parseInReadOnly: true,
              reloadEvents: [],
              id: "ByRpdhCJ",
              title: "\u6587\u4EF6\u5730\u5740",
              visible: false,
              showTitleEffective: false,
              required: false,
              multiple: false,
              onlinePreview: false,
              uploadChunk: true,
              fileCheckMode: "notChecked",
              fileDefaultCheck: "",
              defaultChecked: false,
              changeDefaultChecked: false,
              titleWeight: 400,
              labelColor: "#272727",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              acceptLimit: {
                txt: "text/plain",
                pdf: "application/pdf",
                zip: "application/x-zip-compressed",
                doc: "application/msword",
                docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                xls: "application/vnd.ms-excel",
                xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                png: "image/png",
                jpg: "image/jpeg",
                jpeg: "image/jpeg",
                ppt: "application/vnd.ms-powerpoint",
                pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                rar: "application/x-rar-compressed",
                html: "text/html",
                rm: "application/vnd.rn-realmedia",
                avi: "video/x-msvideo",
                mid: "audio/midi,audio/x-midi",
                wav: "audio/wav",
                mp3: "audio/mpeg",
                bmp: "image/bmp",
                iso: "application/octet-stream",
                wps: "application/vnd.ms-works",
                mp4: "video/mp4",
                mov: "video/quicktime",
                flv: "video/x-flv",
                dwg: "application/x-autocad",
                psd: "application/octet-stream",
                eps: "application/postscript",
                ai: "application/postscript"
              },
              limitSize: "20M",
              maxCount: 10,
              readOnly: false,
              preview: true,
              edit: false,
              download: true,
              remove: false,
              widgetCode: "File$1",
              $$key: "5srt1221lql"
            },
            PyVuepmR: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "PyVuepmR",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u67E5\u770B\u5730\u5740",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              stringLength: 255,
              widgetCode: "FormInput$6",
              field: "url",
              fieldInfo: {
                ds: "bis_api_1694283784024895489",
                path: "__root.result.data.url"
              },
              readOnly: false,
              $$key: "mv9fidu12q"
            },
            DHfVpSMn: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              widgetType: "form",
              id: "DHfVpSMn",
              labelList: [""],
              style: { padding: "0px 0px 0px 5px" },
              titleSize: 14,
              titleWeight: 400,
              vGutter: 2,
              titleAlign: "left",
              iconType: "",
              visible: false,
              showTitleEffective: true,
              labelColor: "rgba(24,144,255,1)",
              title: "\u8DF3\u8F6C\u5904\u7406",
              widgetCode: "TextLabel$1",
              eventTypesWithTags: [],
              $$key: "257z6ibu0rjj"
            },
            upEEmiIB: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "upEEmiIB",
              contentAlign: "right",
              style: {},
              widgetCode: "FloatBar$1",
              $$key: "212u5dgbyk1"
            },
            uKFbSFMW: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "uKFbSFMW",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 },
              $$key: "9cpyuj0jcia"
            },
            UUmueLgI: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "UUmueLgI",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 },
              type: "default",
              eventTypesWithTags: [],
              widgetCode: "FormButton$4",
              $$key: "89qbal3pglr"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1694283784024895489",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "gmgktNnj",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_LFBjgZcQ",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "EqSQrPyD",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            null,
                            void 0
                          )) || false;
                          return $1$ && $2$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "EqSQrPyD", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "nZCHzdUz",
                                    path: "saveValV2",
                                    value: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                      {
                                        id: "EqSQrPyD",
                                        fromPaths: pageCtx.fromPaths,
                                        propPath: ["saveValV2"]
                                      }
                                    )
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u56DE\u586B:\u9759\u6001\u56FE\u7247_\u5B9E\u9645\u503C" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "gmgktNnj",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "file",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "EqSQrPyD", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "ByRpdhCJ",
                                    path: "saveValV2",
                                    value: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                      {
                                        id: "EqSQrPyD",
                                        fromPaths: pageCtx.fromPaths,
                                        propPath: ["saveValV2"]
                                      }
                                    )
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u56DE\u586B:\u6587\u4EF6\u4E0A\u4F20_\u5B9E\u9645\u503C" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1694283784024895489",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond11",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "gmgktNnj",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            yield pageCtx.getExpResult({
                              id: "exp_LFBjgZcQ",
                              source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                            }),
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond14",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "EqSQrPyD",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            null,
                            void 0
                          )) || false;
                          return $1$ && $2$;
                        }),
                        actionList: []
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "gmgktNnj",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "file",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            DHfVpSMn: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  var _a3, _b2;
                                  const {
                                    setState,
                                    getState,
                                    widgetEventCtx
                                  } = platformCtx;
                                  const title = getState("saveValV2_nxStGqdF");
                                  const templateCode = getState(
                                    "saveValV2_LhhvMvDV"
                                  );
                                  let sysnoticeparam = getState("saveValV2_qHXCwFhg") || "{}";
                                  const appCode = getState("saveValV2_cAmFaGdc");
                                  const link = getState("saveValV2_PyVuepmR");
                                  const openTypeFromData = getState(
                                    "saveValV2_VLIBOmKQ"
                                  );
                                  const urlType = getState("saveValV2_aBcTAJQN");
                                  const openTypeList = {
                                    current: "openModal",
                                    // 当前窗口打开
                                    menu: "newTabInApp",
                                    // 跳转到页面菜单
                                    tab: "newTabInBrowser"
                                    // 跳转到浏览器
                                  };
                                  let newParams = {};
                                  try {
                                    const { msgModal_param } = JSON.parse(
                                      sysnoticeparam
                                    );
                                    const extraParams = JSON.parse(msgModal_param).trigger.settings;
                                    console.debug("extraParams", extraParams);
                                    newParams = __spreadValues(__spreadValues({}, newParams), extraParams);
                                  } catch (error) {
                                    console.log(error);
                                  }
                                  try {
                                    switch (newParams == null ? void 0 : newParams.openType) {
                                      case "current":
                                        newParams.openType = "openModal";
                                        break;
                                      case "menu":
                                        newParams.openType = "newTabInApp";
                                        break;
                                      case "tab":
                                        newParams.openType = "newTabInBrowser";
                                        break;
                                      default:
                                        break;
                                    }
                                  } catch (error) {
                                  }
                                  if ((newParams == null ? void 0 : newParams.openType) === "slideModal") {
                                    newParams.openType = "openModal";
                                    newParams.popupMode = "slideModal";
                                  }
                                  let paramsUsed = {};
                                  try {
                                    if (newParams.paramMatch) {
                                      let maps = JSON.parse(sysnoticeparam);
                                      Object.keys(newParams.paramMatch).forEach(
                                        (key) => {
                                          if (maps == null ? void 0 : maps[`${key}`]) {
                                            paramsUsed[key] = maps[`${key}`];
                                          }
                                        }
                                      );
                                    }
                                  } catch (error) {
                                    console.log(error);
                                  }
                                  let extraprops = {};
                                  switch (newParams == null ? void 0 : newParams.windowSize) {
                                    case "smallPopup":
                                      extraprops = {
                                        width: "56vw",
                                        height: null
                                      };
                                      break;
                                    case "middlePopup":
                                      extraprops = {
                                        width: "70vw",
                                        height: null
                                      };
                                      break;
                                    case "largePopup":
                                      extraprops = {
                                        width: "90vw",
                                        height: null
                                      };
                                      break;
                                    default:
                                      extraprops = newParams.extraProps;
                                      break;
                                  }
                                  console.debug(
                                    "\u6253\u5F00\u53C2\u6570",
                                    newParams,
                                    paramsUsed,
                                    extraprops
                                  );
                                  (_b2 = (_a3 = platform_action_default) == null ? void 0 : _a3.openPage) == null ? void 0 : _b2.call(
                                    _a3,
                                    __spreadProps(__spreadValues({}, newParams), {
                                      params: [paramsUsed],
                                      extraprops,
                                      link,
                                      showCloseIcon: newParams == null ? void 0 : newParams.closeIcon,
                                      url: "",
                                      Drag: (newParams == null ? void 0 : newParams.isDrag) || false,
                                      //params: [JSON.parse(sysnoticeparam)],
                                      onCancel: () => __async(this, null, function* () {
                                      }),
                                      onClosePageInCancel: () => __async(this, null, function* () {
                                      })
                                    }),
                                    pageCtx
                                  );
                                  return;
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          }
                        ],
                        log: { objectBehavior: "\u8DF3\u8F6C\u76EE\u6807\u94FE\u63A5" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b, _c, _d;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "VLIBOmKQ",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "menu",
                            void 0
                          )) || false;
                          const $2$ = ((_d = (_c = platform_utils_default).executeCond) == null ? void 0 : _d.call(
                            _c,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "VLIBOmKQ",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["saveValV2"]
                            }),
                            "tab",
                            void 0
                          )) || false;
                          return $1$ || $2$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            UUmueLgI: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  const {
                                    setState,
                                    getState,
                                    widgetEventCtx,
                                    refreshMsgNum
                                  } = platformCtx;
                                  if (typeof refreshMsgNum == "function") {
                                    refreshMsgNum();
                                  } else {
                                    console.log(
                                      "refreshMsgNum\u65B9\u6CD5\u7F3A\u5931\uFF0C\u65E0\u6CD5\u66F4\u65B0\u6D88\u606F\u4E2D\u5FC3\u672A\u8BFB\u6D88\u606F\u6570\u91CF\uFF0C\u8BF7\u68C0\u67E5\uFF01"
                                    );
                                  }
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          }
                        ],
                        log: { objectBehavior: "\u66F4\u65B0\u6D88\u606F\u4E2D\u5FC3\u6570\u5B57\u56FE\u6807\u6570\u91CF" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "nxStGqdF",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "jilVqYwU",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "fZBpPTfL",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "gmgktNnj",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "hSDypJfE",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "qHXCwFhg",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "EqSQrPyD",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "LhhvMvDV",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "cAmFaGdc",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "aBcTAJQN",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "VLIBOmKQ",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "nZCHzdUz",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "ByRpdhCJ",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "PyVuepmR",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "DHfVpSMn",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "upEEmiIB",
                  children: [
                    {
                      id: "uKFbSFMW",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "UUmueLgI",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_LFBjgZcQ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["image", "link"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {}
            },
            exp_KARfUpvS: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  nxStGqdF: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "nxStGqdF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_lJSsIpyu: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  jilVqYwU: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "jilVqYwU",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_WIUOFmgn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  gmgktNnj: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "gmgktNnj",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_CNlinuBP: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["text", "link", "default"].includes(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hSDypJfE: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "hSDypJfE",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { gmgktNnj: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_fqUoVihD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hSDypJfE: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "hSDypJfE",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_XCNntJSC: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  qHXCwFhg: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "qHXCwFhg",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_JOBcdNxW: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EqSQrPyD: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "EqSQrPyD",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ztPrmhKs: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) ? (_a = JSON.parse(param == null ? void 0 : param.$0)) == null ? void 0 : _a.fileInfo : "";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  EqSQrPyD: [
                    { path: "saveValV2", id: "EqSQrPyD", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { qHXCwFhg: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_duaVpkNp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  LhhvMvDV: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "LhhvMvDV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_GXiAQARp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  cAmFaGdc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "cAmFaGdc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_YPTMlsfG: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  aBcTAJQN: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "aBcTAJQN",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_YKRzgYGk: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VLIBOmKQ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "VLIBOmKQ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_supAPiXO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["image", "link"].includes(param == null ? void 0 : param.$0) && !platform_exp_default.HasEmpty(param == null ? void 0 : param.$1);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  nZCHzdUz: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "nZCHzdUz",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  gmgktNnj: { saveValV2: { paramKey: "$0" } },
                  EqSQrPyD: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_WPhJzjGC: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["file"].includes(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ByRpdhCJ: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "ByRpdhCJ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { gmgktNnj: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_zkTshrJW: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ByRpdhCJ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ByRpdhCJ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_QodNWbRG: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ByRpdhCJ: [
                    {
                      path: "edit",
                      defaultValue: false,
                      id: "ByRpdhCJ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_DeZYBbtt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ByRpdhCJ: [
                    {
                      path: "remove",
                      defaultValue: false,
                      id: "ByRpdhCJ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_PtzCoEqu: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  PyVuepmR: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "PyVuepmR",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_GLcPZXeK: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["link"].includes(param == null ? void 0 : param.$0) && (param == null ? void 0 : param.$1);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  DHfVpSMn: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "DHfVpSMn",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  gmgktNnj: { saveValV2: { paramKey: "$0" } },
                  PyVuepmR: { saveValV2: { paramKey: "$1" } }
                }
              }
            },
            exp_EyFLdYjU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uKFbSFMW: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "uKFbSFMW",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_WIOzgqZP: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uKFbSFMW: [
                    {
                      path: "disabled",
                      defaultValue: true,
                      id: "uKFbSFMW",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_KARfUpvS", type: "exp" },
                { id: "exp_lJSsIpyu", type: "exp" },
                { id: "exp_WIUOFmgn", type: "exp" },
                { id: "exp_fqUoVihD", type: "exp" },
                { id: "exp_XCNntJSC", type: "exp" },
                { id: "exp_JOBcdNxW", type: "exp" },
                { id: "exp_duaVpkNp", type: "exp" },
                { id: "exp_GXiAQARp", type: "exp" },
                { id: "exp_YPTMlsfG", type: "exp" },
                { id: "exp_YKRzgYGk", type: "exp" },
                { id: "exp_zkTshrJW", type: "exp" },
                { id: "exp_QodNWbRG", type: "exp" },
                { id: "exp_DeZYBbtt", type: "exp" },
                { id: "exp_PtzCoEqu", type: "exp" },
                { id: "exp_EyFLdYjU", type: "exp" },
                { id: "exp_WIOzgqZP", type: "exp" }
              ]
            },
            widget: {
              gmgktNnj: {
                saveValV2: [
                  { id: "exp_CNlinuBP", type: "exp" },
                  { id: "exp_supAPiXO", type: "exp" },
                  { id: "exp_WPhJzjGC", type: "exp" },
                  { id: "exp_GLcPZXeK", type: "exp" }
                ]
              },
              qHXCwFhg: { saveValV2: [{ id: "exp_ztPrmhKs", type: "exp" }] },
              EqSQrPyD: { saveValV2: [{ id: "exp_supAPiXO", type: "exp" }] },
              PyVuepmR: { saveValV2: [{ id: "exp_GLcPZXeK", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$nxStGqdF`,
            key: `PC$$nxStGqdF`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$jilVqYwU`,
            key: `PC$$jilVqYwU`,
            pageCtx,
            widgetRef: "FormDateTimePicker"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$fZBpPTfL`,
            key: `PC$$fZBpPTfL`,
            pageCtx,
            widgetRef: "FormDivider"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$gmgktNnj`,
            key: `PC$$gmgktNnj`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$hSDypJfE`,
            key: `PC$$hSDypJfE`,
            pageCtx,
            widgetRef: "RichEditor"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$qHXCwFhg`,
            key: `PC$$qHXCwFhg`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$EqSQrPyD`,
            key: `PC$$EqSQrPyD`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$LhhvMvDV`,
            key: `PC$$LhhvMvDV`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$cAmFaGdc`,
            key: `PC$$cAmFaGdc`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$aBcTAJQN`,
            key: `PC$$aBcTAJQN`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$VLIBOmKQ`,
            key: `PC$$VLIBOmKQ`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$nZCHzdUz`,
            key: `PC$$nZCHzdUz`,
            pageCtx,
            widgetRef: "StaticPicture"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$ByRpdhCJ`,
            key: `PC$$ByRpdhCJ`,
            pageCtx,
            widgetRef: "File"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$PyVuepmR`,
            key: `PC$$PyVuepmR`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$DHfVpSMn`,
            key: `PC$$DHfVpSMn`,
            pageCtx,
            widgetRef: "TextLabel"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$upEEmiIB`,
            key: `PC$$upEEmiIB`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$upEEmiIB$$uKFbSFMW`,
              key: `PC$$upEEmiIB$$uKFbSFMW`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$upEEmiIB$$UUmueLgI`,
              key: `PC$$upEEmiIB$$UUmueLgI`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        )
      );
    }
  };
  __publicField(Page1694617459035877376, "pageName", "\u6D88\u606F\u8BE6\u60C5\u9875\u9762");
  __publicField(Page1694617459035877376, "$pageKey", "aPOPZxZv");
  __publicField(Page1694617459035877376, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
