var Page1423825106714636288 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1423825106714636288: () => Page1423825106714636288
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1423825106714636288 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1423825106714636288",
            pageName: "\u89D2\u8272\u529F\u80FD\u6388\u6743",
            apiMeta: {
              __system_get_app_menu__: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u8BF4\u660E\u4FE1\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u6570\u636E",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root.result.modifiedUserName": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u59D3\u540D",
                    __key: "modifiedUserName",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.gmtModified": {
                    title: "\u4FEE\u6539\u65F6\u95F4",
                    __key: "gmtModified",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.level": {
                    title: "\u5C42\u7EA7",
                    __key: "level",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.hasChildren": {
                    title: "\u662F\u5426\u5B58\u5728\u5B50\u96C6",
                    __key: "hasChildren",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root.result"
                  },
                  "__root.result.icon": {
                    title: "\u56FE\u6807",
                    __key: "icon",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.pid": {
                    title: "\u6240\u5C5E\u6A21\u5757",
                    __key: "pid",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.sort": {
                    title: "\u6392\u5E8F\u53F7",
                    __key: "sort",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.gmtCreate": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "gmtCreate",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.type": {
                    title: "0\u6A21\u57571\u9875\u9762",
                    __key: "type",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.version": {
                    title: "\u7248\u672C\u53F7",
                    __key: "version",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.pageName": {
                    title: "\u9875\u9762\u540D\u79F0",
                    __key: "pageName",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.deleteFlag": {
                    title: "\u903B\u8F91\u5220\u9664\u6807\u8BC6",
                    __key: "deleteFlag",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.result.path": {
                    title: "\u8DEF\u5F84",
                    __key: "path",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.createdUserName": {
                    title: "\u521B\u5EFA\u4EBA\u59D3\u540D",
                    __key: "createdUserName",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.createdBy": {
                    title: "\u521B\u5EFA\u4EBA",
                    __key: "createdBy",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.name": {
                    title: "\u83DC\u5355\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.modifiedBy": {
                    title: "\u4FEE\u6539\u4EBA",
                    __key: "modifiedBy",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.pageLink": {
                    title: "\u5173\u8054\u9875\u9762",
                    __key: "pageLink",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  },
                  "__root.result.status": {
                    title: "0(\u7981\u7528)\u6216\u80051(\u542F\u7528)",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  },
                  "__root.code": {
                    title: "\u54CD\u5E94\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u54CD\u5E94\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  }
                },
                cond: {
                  type: {
                    title: "\u83DC\u5355\u7C7B\u578B"
                  },
                  level: {
                    title: "\u5C42\u7EA7"
                  }
                }
              },
              bis_api_1627457952332: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.name": {
                    title: "\u8282\u70B9\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.code": {
                    title: "\u8282\u70B9\u7F16\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.authCode": {
                    title: "\u6743\u9650\u9879\u7F16\u7801",
                    __key: "authCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.terminalType": {
                    title: "\u7EC8\u7AEF\u7C7B\u578B",
                    __key: "terminalType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.parentCode": {
                    title: "\u7236\u8282\u70B9",
                    __key: "parentCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  module_id: {
                    title: "\u6A21\u5757\u4E3B\u952E"
                  }
                }
              },
              bis_api_1625016818919: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.authState": {
                    title: "\u6388\u6743\u72B6\u6001",
                    __key: "authState",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.code": {
                    title: "\u7F16\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.roleId": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "roleId",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.name": {
                    title: "\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.desc": {
                    title: "\u63CF\u8FF0",
                    __key: "desc",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pid": {
                    title: "\u7236\u8282\u70B9",
                    __key: "pid",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  module_id: {
                    title: "\u63A5\u53E3\u7F16\u7801"
                  },
                  permission_type: {
                    title: "\u6743\u9650\u7C7B\u578B"
                  }
                }
              },
              bis_api_1627463403645: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.authState": {
                    title: "\u6388\u6743\u72B6\u6001",
                    __key: "authState",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.code": {
                    title: "\u7F16\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.roleId": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "roleId",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.name": {
                    title: "\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.desc": {
                    title: "\u63CF\u8FF0",
                    __key: "desc",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pid": {
                    title: "\u7236\u8282\u70B9",
                    __key: "pid",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  module_id: {
                    title: "\u63A5\u53E3\u7F16\u7801"
                  },
                  role_id: {
                    title: "\u89D2\u8272\u4E3B\u952E"
                  },
                  permission_type: {
                    title: "\u6743\u9650\u7C7B\u578B"
                  }
                }
              },
              bis_api_1627463419037: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.authStatus": {
                    title: "\u6388\u6743\u72B6\u6001",
                    __key: "authStatus",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.name": {
                    title: "\u8282\u70B9\u540D\u79F0",
                    __key: "name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.code": {
                    title: "\u8282\u70B9\u7F16\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.authCode": {
                    title: "\u6743\u9650\u9879\u7F16\u7801",
                    __key: "authCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.terminalType": {
                    title: "\u7EC8\u7AEF\u7C7B\u578B",
                    __key: "terminalType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.parentCode": {
                    title: "\u7236\u8282\u70B9",
                    __key: "parentCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  module_id: {
                    title: "\u6A21\u5757\u4E3B\u952E"
                  },
                  role_id: {
                    title: "\u89D2\u8272\u4E3B\u952E"
                  }
                }
              },
              bis_api_1625019468650: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.item_info_list": {
                    title: "\u6388\u6743\u4FE1\u606F\u5217\u8868",
                    __key: "item_info_list",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root.item_info_list.apiKey": {
                    title: "\u63A5\u53E3\u7F16\u7801",
                    __key: "apiKey",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.item_info_list"
                  },
                  "__root.item_info_list.item_codes": {
                    title: "\u6743\u9650\u9879\u7F16\u7801\u5217\u8868",
                    __key: "item_codes",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root.item_info_list"
                  },
                  "__root.role_id": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "role_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.original": {
                    title: "\u539F\u59CB\u6388\u6743",
                    __key: "original",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  },
                  "__root.updated": {
                    title: "\u66F4\u65B0\u540E\u6388\u6743",
                    __key: "updated",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1627457965658: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.role_id": {
                    title: "\u89D2\u8272\u4E3B\u952E",
                    __key: "role_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.original": {
                    title: "\u539F\u59CB\u6388\u6743",
                    __key: "original",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  },
                  "__root.updated": {
                    title: "\u66F4\u65B0\u540E\u6388\u6743",
                    __key: "updated",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, {
            var_pageInput_0_mode: "REPLACE",
            var_pageInput_1_id: null,
            var_pageInput_2_0bcZqw_U: null
          }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              title: "\u89D2\u8272\u529F\u80FD\u6388\u6743",
              showBottomBar: true,
              style: {}
            },
            dpllWtog: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "dpllWtog",
              contentAlign: "right",
              widgetCode: "FloatBar$1"
            },
            rttlfaml: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "rttlfaml",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$2",
              eventTypesWithTags: []
            },
            Wtpdrmta: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "Wtpdrmta",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              eventTypesWithTags: []
            },
            yqwfAOGv: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "yqwfAOGv",
              hGutter: 12,
              vGutter: 0,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px",
                maxHeight: "100vh - 32px"
              },
              visible: true,
              widgetCode: "FlexLayoutContainer$4",
              title: "\u6805\u683C\u5E03\u5C404",
              gridByLine: [
                [
                  { span: 6, locked: false, id: "SWSkxswd" },
                  { span: 18, locked: false, id: "VOlmuOlY" }
                ]
              ]
            },
            SWSkxswd: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "SWSkxswd",
              span: 6,
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              },
              widgetCode: "FlexLayout$1"
            },
            RgigMChj: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "formInput",
              reloadEvents: ["onTreeQuery"],
              id: "RgigMChj",
              style: { padding: "0px", height: "600px" },
              multiCheck: false,
              title: "\u83DC\u5355\u6811",
              visible: true,
              showSearchBar: false,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: true,
              expandLevel: "",
              defaultSelectedNode: true,
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              widgetCode: "Tree$4",
              sortInfo: [],
              conditions: [
                {
                  varAlias: 1,
                  field: "level",
                  paramAmount: 1,
                  method: "equ",
                  value: ["1"]
                }
              ],
              formula: "1 ",
              tTitleKey: "name",
              tPIdKey: "pid",
              tIdKey: "id",
              ds: "__system_get_app_menu__",
              selectedNodes: [{ value: "1388009993298653184" }],
              treeHeaderIconBtns: [
                {
                  title: "\u5C55\u5F00/\u6536\u7F29",
                  type: "expandCollapse",
                  widgetId: "vQgSKssP",
                  icons: [
                    { iconType: "FiMaximize2", label: "" },
                    { iconType: "FiMinimize2", label: "" }
                  ]
                },
                { title: "\u5237\u65B0", type: "refresh", widgetId: "zlgsBCtG" }
              ],
              eventTypesWithTags: [],
              selectedNodesPaths: "",
              showTitleEffective: false
            },
            vQgSKssP: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "vQgSKssP",
              title: "",
              visible: true,
              disabled: false,
              iconType: "FiMinimize2",
              style: {
                padding: "4px 15px 4px 15px",
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              },
              size: "small",
              type: "link",
              $lazyload: false
            },
            zlgsBCtG: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "zlgsBCtG",
              title: "",
              visible: true,
              disabled: false,
              iconType: "FiRotateCw",
              style: {
                padding: "4px 15px 4px 15px",
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              },
              size: "small",
              type: "link",
              $lazyload: false
            },
            VOlmuOlY: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "VOlmuOlY",
              span: 18,
              title: "\u6805\u683C2",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              }
            },
            ftWlrgip: {
              varMap: { curTab: { type: "string" }, tapTab: { type: "string" } },
              widgetRef: "TabContainer",
              eventAttr: ["onTabChange", "onTabClick"],
              id: "ftWlrgip",
              title: "",
              visible: false,
              titleAlign: "left",
              tabsVisibleList: [true, true, true],
              curTab: "",
              tabsList: [
                { title: "\u529F\u80FD\u6743\u9650", icon: "", id: "meplfmfl" },
                { title: "\u5B57\u6BB5\u6743\u9650", icon: "", id: "ttlefioa" },
                { title: "\u6570\u636E\u6743\u9650", icon: "", id: "gpeotmel" }
              ],
              style: {
                width: "100%",
                height: "auto",
                border: "0px",
                padding: "0px"
              },
              widgetCode: "TabContainer$1",
              eventTypesWithTags: []
            },
            meplfmfl: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "meplfmfl",
              span: 24,
              title: "\u6807\u7B7E1\u5BB9\u5668",
              style: { height: "auto", border: "0px" }
            },
            lglaWadd: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "lglaWadd",
              hGutter: 12,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1",
              title: "\u6805\u683C\u5E03\u5C401",
              gridByLine: [
                [
                  { span: 12, locked: false, id: "dgttaWoo" },
                  { span: 12, locked: false, id: "WeWrottp" }
                ]
              ]
            },
            dgttaWoo: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "dgttaWoo",
              span: 12,
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              },
              widgetCode: "FlexLayout$1"
            },
            fpmWefii: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "formInput",
              reloadEvents: ["onTreeQuery"],
              id: "fpmWefii",
              style: { height: "550px" },
              multiCheck: true,
              title: "\u529F\u80FD\u6743\u9650\u6811",
              visible: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: true,
              expandLevel: "",
              defaultSelectedNode: false,
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              widgetCode: "Tree$1",
              treeHeaderIconBtns: [
                {
                  title: "\u5C55\u5F00/\u6536\u7F29",
                  type: "expandCollapse",
                  widgetId: "attiggmp",
                  icons: [
                    { iconType: "FiMaximize2", label: "" },
                    { iconType: "FiMinimize2", label: "" }
                  ]
                },
                { title: "\u5237\u65B0", type: "refresh", widgetId: "Wrgfefro" }
              ],
              sortInfo: [],
              conditions: [
                {
                  varAlias: "1",
                  field: "module_id",
                  paramAmount: 1,
                  method: "equ"
                }
              ],
              formula: "1",
              tTitleKey: "name",
              tPIdKey: "parentCode",
              tIdKey: "code",
              ds: "bis_api_1627457952332",
              eventTypesWithTags: [],
              readOnly: false,
              showTitleEffective: false
            },
            attiggmp: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "attiggmp",
              title: "",
              visible: true,
              disabled: false,
              iconType: "FiMinimize2",
              size: "small",
              type: "link",
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            Wrgfefro: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "Wrgfefro",
              iconType: "FiRotateCw",
              title: "",
              visible: true,
              disabled: false,
              size: "small",
              type: "link",
              widgetCode: "FormButton$2",
              eventTypesWithTags: [],
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            WeWrottp: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "WeWrottp",
              span: 12,
              title: "\u6805\u683C2",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              },
              widgetCode: "FlexLayout$1"
            },
            ttlefioa: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "ttlefioa",
              span: 24,
              title: "\u6807\u7B7E2\u5BB9\u5668",
              style: { height: "auto", border: "0px" }
            },
            emlddmWf: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "emlddmWf",
              hGutter: 12,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$2",
              title: "\u6805\u683C\u5E03\u5C402",
              gridByLine: [
                [
                  { span: 12, locked: false, id: "flfaiiia" },
                  { span: 12, locked: false, id: "YtzsdRrI" }
                ]
              ]
            },
            flfaiiia: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "flfaiiia",
              span: 12,
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              }
            },
            laglmpdr: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "formInput",
              reloadEvents: ["onTreeQuery"],
              id: "laglmpdr",
              style: { height: "550px" },
              multiCheck: true,
              title: "\u5B57\u6BB5\u6743\u9650\u6811",
              visible: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: true,
              expandLevel: "",
              defaultSelectedNode: false,
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              widgetCode: "Tree$2",
              treeHeaderIconBtns: [
                {
                  title: "\u5C55\u5F00/\u6536\u7F29",
                  type: "expandCollapse",
                  widgetId: "ittfimWm",
                  icons: [
                    { iconType: "FiMaximize2", label: "" },
                    { iconType: "FiMinimize2", label: "" }
                  ]
                },
                { title: "\u5237\u65B0", type: "refresh", widgetId: "igWgggff" }
              ],
              sortInfo: [],
              conditions: [
                {
                  varAlias: "1",
                  field: "permission_type",
                  paramAmount: 1,
                  method: "equ",
                  value: ["field"]
                },
                {
                  varAlias: "2",
                  field: "module_id",
                  paramAmount: 1,
                  method: "equ"
                }
              ],
              formula: "1 and 2",
              tTitleKey: "name",
              tPIdKey: "pid",
              tIdKey: "id",
              ds: "bis_api_1625016818919",
              eventTypesWithTags: [],
              readOnly: false,
              showTitleEffective: false
            },
            ittfimWm: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "ittfimWm",
              title: "",
              visible: true,
              disabled: false,
              iconType: "FiMinimize2",
              size: "small",
              type: "link",
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            igWgggff: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "igWgggff",
              iconType: "FiRotateCw",
              title: "",
              visible: true,
              disabled: false,
              size: "small",
              type: "link",
              widgetCode: "FormButton$2",
              eventTypesWithTags: [],
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            YtzsdRrI: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "YtzsdRrI",
              span: 12,
              visible: true,
              style: { padding: "0px 6px 0px 6px" },
              title: "\u6805\u683C2",
              widgetCode: "FlexLayout$1"
            },
            gpeotmel: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "gpeotmel",
              span: 24,
              title: "\u6807\u7B7E3\u5BB9\u5668",
              style: { height: "auto", border: "0px" }
            },
            iWfmptWm: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "iWfmptWm",
              hGutter: 12,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$3",
              title: "\u6805\u683C\u5E03\u5C403",
              gridByLine: [
                [
                  { span: 12, locked: false, id: "gidgltWo" },
                  { span: 12, locked: false, id: "gWefptma" }
                ]
              ]
            },
            gidgltWo: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "gidgltWo",
              span: 12,
              title: "\u6805\u683C1",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              }
            },
            iadllott: {
              varMap: {
                checkedDatas: { type: "objectArray" },
                checkedKeys: { type: "array" },
                selectedData: { type: "object" },
                selectedKey: { type: "string" },
                selectedNodes: { type: "objectArray" },
                searchText: { type: "string" },
                searchSelectedKeys: { type: "array" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                parentNode: { type: "object" },
                currentNodes: { type: "objectArray" },
                updatedNodes: { type: "objectArray" }
              },
              widgetRef: "Tree",
              eventAttr: [
                "onTreeQuery",
                "onTreeCheck",
                "onTreeClick",
                "onTreeDbClick",
                "onTreeDblClick",
                "onTreeExpand",
                "onTreeCollapse",
                "onTreeBeforeDrop",
                "onTreeDrop"
              ],
              group: "formInput",
              reloadEvents: ["onTreeQuery"],
              id: "iadllott",
              style: { height: "550px" },
              multiCheck: true,
              title: "\u6570\u636E\u6743\u9650\u6811",
              visible: true,
              showSearchBar: true,
              showRootNode: true,
              rootTitle: "\u5168\u90E8",
              defaultExpand: true,
              expandLevel: "",
              defaultSelectedNode: false,
              showLine: true,
              treeIconDisplay: true,
              env: "app",
              widgetCode: "Tree$3",
              treeHeaderIconBtns: [
                {
                  title: "\u5C55\u5F00/\u6536\u7F29",
                  type: "expandCollapse",
                  widgetId: "tmtWoWtl",
                  icons: [
                    { iconType: "FiMaximize2", label: "" },
                    { iconType: "FiMinimize2", label: "" }
                  ]
                },
                { title: "\u5237\u65B0", type: "refresh", widgetId: "frldttaa" }
              ],
              sortInfo: [],
              conditions: [
                {
                  varAlias: "1",
                  field: "permission_type",
                  paramAmount: 1,
                  method: "equ",
                  value: ["data"]
                },
                {
                  varAlias: "2",
                  field: "module_id",
                  paramAmount: 1,
                  method: "equ"
                }
              ],
              formula: "1 and 2",
              tTitleKey: "name",
              tPIdKey: "pid",
              tIdKey: "id",
              ds: "bis_api_1625016818919",
              eventTypesWithTags: [],
              readOnly: false,
              showTitleEffective: false
            },
            tmtWoWtl: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "tmtWoWtl",
              title: "",
              visible: true,
              disabled: false,
              iconType: "FiMinimize2",
              size: "small",
              type: "link",
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            frldttaa: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "frldttaa",
              iconType: "FiRotateCw",
              title: "",
              visible: true,
              disabled: false,
              size: "small",
              type: "link",
              widgetCode: "FormButton$2",
              eventTypesWithTags: [],
              $lazyload: false,
              style: {
                paddingLeft: "6px",
                paddingRight: "6px",
                minWidth: "40px"
              }
            },
            gWefptma: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "gWefptma",
              span: 12,
              title: "\u6805\u683C2",
              style: {
                height: "auto",
                border: "0px",
                padding: "0px 6px 0px 6px"
              },
              widgetCode: "FlexLayout$1"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ytcPVXqV" },
                                    { expId: "exp_WGCPBZEh" },
                                    { expId: "exp_qPviLwXa" },
                                    { expId: "exp_HlGMSsDh" },
                                    { expId: "exp_gbFtbQLr" },
                                    { expId: "exp_MYSsiYpL" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "ftWlrgip",
                                    path: "curTab",
                                    value: "\u529F\u80FD\u6743\u9650"
                                  },
                                  {
                                    path: "var_customed_12_CsqGaFOY",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_ytcPVXqV",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  },
                                  {
                                    path: "var_customed_13_rskpNzsf",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_WGCPBZEh",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  },
                                  {
                                    path: "var_customed_9_qbmziSOc",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_qPviLwXa",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  },
                                  {
                                    path: "var_customed_7_ZRNMEPAO",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_HlGMSsDh",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  },
                                  {
                                    path: "var_customed_5_dMwjqlKe",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_gbFtbQLr",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  },
                                  {
                                    path: "var_customed_3_iexlbaib",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_MYSsiYpL",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u521D\u59CB\u5F53\u524D\u9875\u9762\u6570\u636E" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            rttlfaml: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond9",
                            pageCtx.getDataByPath({
                              target: "customedVar",
                              path: "var_customed_16_KlmrreEK"
                            }),
                            "1",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_CoUlKwAf" },
                                    { expId: "exp_GLVEsBmk" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627457965658",
                                  input: [
                                    {
                                      "__root.original": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_CoUlKwAf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.role_id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_2_0bcZqw_U"
                                      })
                                    },
                                    {
                                      "__root.updated": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_GLVEsBmk",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: true,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4FDD\u5B58\u89D2\u8272\u529F\u80FD\u6743\u9650" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond9",
                            pageCtx.getDataByPath({
                              target: "customedVar",
                              path: "var_customed_16_KlmrreEK"
                            }),
                            "2",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_QcOMjxqw" },
                                    { expId: "exp_oPwmVeqL" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1625019468650",
                                  input: [
                                    {
                                      "__root.original": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_QcOMjxqw",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.role_id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_2_0bcZqw_U"
                                      })
                                    },
                                    {
                                      "__root.updated": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_oPwmVeqL",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: true,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4FDD\u5B58\u89D2\u8272\u5B57\u6BB5\u6743\u9650" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond9",
                            pageCtx.getDataByPath({
                              target: "customedVar",
                              path: "var_customed_16_KlmrreEK"
                            }),
                            "3",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ptkDmYbs" },
                                    { expId: "exp_LSVSHTxY" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1625019468650",
                                  input: [
                                    {
                                      "__root.role_id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_2_0bcZqw_U"
                                      })
                                    },
                                    {
                                      "__root.original": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ptkDmYbs",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.updated": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_LSVSHTxY",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: true,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4FDD\u5B58\u89D2\u8272\u6570\u636E\u6743\u9650" }
                      },
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            Wtpdrmta: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            RgigMChj: {
              onTreeCheck: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  return __async(this, null, function* () {
                                    const {
                                      setState,
                                      getState,
                                      widgetEventCtx
                                    } = platformCtx;
                                    if (typeof setState === "function") {
                                      return;
                                    }
                                    console.log(
                                      "============================start============================"
                                    );
                                    const var_customed_9_qbmziSOc = yield getState(
                                      "var_customed_9_qbmziSOc"
                                    );
                                    console.log(
                                      "\u83DC\u5355\u7EA7\u529F\u80FD\u9009\u9879\u96C6",
                                      "var_customed_9_qbmziSOc",
                                      var_customed_9_qbmziSOc
                                    );
                                    const var_customed_10_roeWduBk = yield getState(
                                      "var_customed_10_roeWduBk"
                                    );
                                    console.log(
                                      "\u4E0A\u83DC\u5355\u9879\u503C(\u5F53\u524D)",
                                      "var_customed_10_roeWduBk",
                                      var_customed_10_roeWduBk
                                    );
                                    console.log(
                                      "============================end============================"
                                    );
                                  });
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ppomtxpf" },
                                    { expId: "exp_optpmxpf" },
                                    { expId: "exp_fraprtrt" },
                                    { expId: "exp_lMUJwSBf" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463419037",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ppomtxpf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_optpmxpf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_fraprtrt",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_lMUJwSBf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.authCode",
                                      propPath: ["var_customed_2_DjjHIZXX"]
                                    },
                                    {
                                      field: "__root.result.data.authCode",
                                      propPath: ["var_customed_11_kvNtRxiJ"]
                                    },
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_11_kvNtRxiJ"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ppxppxlr" },
                                    { expId: "exp_ptolpmlo" },
                                    { expId: "exp_mftmplfp" },
                                    { expId: "exp_fuYdhxol" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463403645",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ppxppxlr",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ptolpmlo",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_mftmplfp",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2 and 3" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_fuYdhxol",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_0_CjUBz_08"]
                                    },
                                    {
                                      field: "__root.result.data.id",
                                      propPath: ["var_customed_14_fqdLVmFU"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_xExppfmf" },
                                    { expId: "exp_oEfppEoE" },
                                    { expId: "exp_olmrfrxt" },
                                    { expId: "exp_YgGJMGro" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463403645",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_xExppfmf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_oEfppEoE",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_olmrfrxt",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2 and 3" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_YgGJMGro",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_1_qPTVH9qo"]
                                    },
                                    {
                                      field: "__root.result.data.id",
                                      propPath: ["var_customed_15_wLibYuMs"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_ZSFUbfVu" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_10_roeWduBk",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_ZSFUbfVu",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_huiGaiQv" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_3_iexlbaib",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_huiGaiQv",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_dVubPEKt" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_7_ZRNMEPAO",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_dVubPEKt",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_glRcdWeH" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_5_dMwjqlKe",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_glRcdWeH",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  return __async(this, null, function* () {
                                    const {
                                      setState,
                                      getState,
                                      widgetEventCtx
                                    } = platformCtx;
                                    if (typeof setState === "function") {
                                      return;
                                    }
                                    console.log(
                                      "--------------------start----------------"
                                    );
                                    const var_customed_1_qPTVH9qo = yield getState(
                                      "var_customed_1_qPTVH9qo"
                                    );
                                    console.log(
                                      "",
                                      "var_customed_1_qPTVH9qo",
                                      var_customed_1_qPTVH9qo
                                    );
                                    const var_customed_2_DjjHIZXX = yield getState(
                                      "var_customed_2_DjjHIZXX"
                                    );
                                    console.log(
                                      "",
                                      "var_customed_2_DjjHIZXX",
                                      var_customed_2_DjjHIZXX
                                    );
                                    const var_customed_3_iexlbaib = yield getState(
                                      "var_customed_3_iexlbaib"
                                    );
                                    console.log(
                                      "\u539F\u603B\u89D2\u8272\u529F\u80FD\u6743\u9650\u96C6",
                                      "var_customed_3_iexlbaib",
                                      var_customed_3_iexlbaib
                                    );
                                    const var_customed_5_dMwjqlKe = yield getState(
                                      "var_customed_5_dMwjqlKe"
                                    );
                                    console.log(
                                      "\u539F\u603B\u89D2\u8272\u6570\u636E\u6743\u9650\u96C6",
                                      "var_customed_5_dMwjqlKe",
                                      var_customed_5_dMwjqlKe
                                    );
                                    const var_customed_7_ZRNMEPAO = yield getState(
                                      "var_customed_7_ZRNMEPAO"
                                    );
                                    console.log(
                                      "\u539F\u603B\u89D2\u8272\u5B57\u6BB5\u6743\u9650\u96C6",
                                      "var_customed_7_ZRNMEPAO",
                                      var_customed_7_ZRNMEPAO
                                    );
                                    const var_customed_9_qbmziSOc = yield getState(
                                      "var_customed_9_qbmziSOc"
                                    );
                                    console.log(
                                      "\u83DC\u5355\u7EA7\u529F\u80FD\u9009\u9879\u96C6",
                                      "var_customed_9_qbmziSOc",
                                      var_customed_9_qbmziSOc
                                    );
                                    const var_customed_10_roeWduBk = yield getState(
                                      "var_customed_10_roeWduBk"
                                    );
                                    console.log(
                                      "\u4E0A\u83DC\u5355\u9879\u503C(\u5F53\u524D)",
                                      "var_customed_10_roeWduBk",
                                      var_customed_10_roeWduBk
                                    );
                                    const var_customed_11_kvNtRxiJ = yield getState(
                                      "var_customed_11_kvNtRxiJ"
                                    );
                                    console.log(
                                      "\u89D2\u8272\u529F\u80FD\u6388\u6743\u6807\u8BC6\u96C6",
                                      "var_customed_11_kvNtRxiJ",
                                      var_customed_11_kvNtRxiJ
                                    );
                                    const var_customed_12_CsqGaFOY = yield getState(
                                      "var_customed_12_CsqGaFOY"
                                    );
                                    console.log(
                                      "\u83DC\u5355\u7EA7\u5B57\u6BB5\u9009\u9879\u96C6",
                                      "var_customed_12_CsqGaFOY",
                                      var_customed_12_CsqGaFOY
                                    );
                                    const var_customed_13_rskpNzsf = yield getState(
                                      "var_customed_13_rskpNzsf"
                                    );
                                    console.log(
                                      "\u83DC\u5355\u7EA7\u6570\u636E\u9009\u9879\u7EA7",
                                      "var_customed_13_rskpNzsf",
                                      var_customed_13_rskpNzsf
                                    );
                                    const var_customed_14_fqdLVmFU = yield getState(
                                      "var_customed_14_fqdLVmFU"
                                    );
                                    console.log(
                                      "\u89D2\u8272\u5B57\u6BB5\u6807\u8BC6\u96C6",
                                      "var_customed_14_fqdLVmFU",
                                      var_customed_14_fqdLVmFU
                                    );
                                    const var_customed_15_wLibYuMs = yield getState(
                                      "var_customed_15_wLibYuMs"
                                    );
                                    console.log(
                                      "\u89D2\u8272\u6570\u636E\u6807\u8BC6\u96C6",
                                      "var_customed_15_wLibYuMs",
                                      var_customed_15_wLibYuMs
                                    );
                                    const var_customed_16_KlmrreEK = yield getState(
                                      "var_customed_16_KlmrreEK"
                                    );
                                    console.log(
                                      "\u529F\u80FD\u66F4\u65B0\u9879\u96C6",
                                      "var_customed_16_KlmrreEK",
                                      var_customed_16_KlmrreEK
                                    );
                                    console.log(
                                      "--------------------end----------------"
                                    );
                                  });
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "fpmWefii",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "laglmpdr",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "iadllott",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u6253\u5370\u7B80\u5355\u65E5\u5FD7,\u83B7\u53D6\u89D2\u8272\u529F\u80FD\u6743\u9650\u9879,\u83B7\u53D6\u89D2\u8272\u5B57\u6BB5\u6743\u9650\u9879,\u83B7\u53D6\u89D2\u8272\u6570\u636E\u6743\u9650\u9879,\u8BB0\u5F55\u5F53\u524D\u83DC\u5355\u9879,\u8BB0\u5F55\u603B\u89D2\u8272\u529F\u80FD\u6743\u9650\u96C6,\u8BB0\u5F55\u603B\u89D2\u8272\u5B57\u6BB5\u6743\u9650\u96C6,\u8BB0\u5F55\u603B\u89D2\u8272\u6570\u636E\u6743\u9650\u96C6,\u6253\u5370\u65E5\u5FD7,\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u529F\u80FD\u6743\u9650\u6811,\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u5B57\u6BB5\u6743\u9650\u6811,\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u6570\u636E\u6743\u9650\u6811"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            Wrgfefro: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ppomtxpf" },
                                    { expId: "exp_optpmxpf" },
                                    { expId: "exp_fraprtrt" },
                                    { expId: "exp_lMUJwSBf" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463419037",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ppomtxpf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_optpmxpf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_fraprtrt",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_lMUJwSBf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.authCode",
                                      propPath: ["var_customed_2_DjjHIZXX"]
                                    },
                                    {
                                      field: "__root.result.data.authCode",
                                      propPath: ["var_customed_11_kvNtRxiJ"]
                                    },
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_11_kvNtRxiJ"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_KFNBNBBF" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "fpmWefii",
                                    path: "checkedDatas.code",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_KFNBNBBF",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u83B7\u53D6\u89D2\u8272\u529F\u80FD\u6743\u9650\u9879,\u56DE\u586B\u529F\u80FD\u6743\u9650"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            fpmWefii: {
              onTreeQuery: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_KFNBNBBF" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "fpmWefii",
                                    path: "checkedDatas.code",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_KFNBNBBF",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u56DE\u586B\u529F\u80FD\u6743\u9650" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onTreeCheck: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_RyTBxZtP" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_16_KlmrreEK",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_RyTBxZtP",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_tKjpGjVA" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_9_qbmziSOc",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_tKjpGjVA",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u66F4\u65B0\u529F\u80FD\u66F4\u65B0\u9879\u96C6,\u8BB0\u5F55\u5F53\u524D\u83DC\u5355\u7EA7\u529F\u80FD\u6570\u636E\u96C6"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            igWgggff: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_ppxppxlr" },
                                    { expId: "exp_ptolpmlo" },
                                    { expId: "exp_mftmplfp" },
                                    { expId: "exp_fuYdhxol" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463403645",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ppxppxlr",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_ptolpmlo",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_mftmplfp",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2 and 3" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_fuYdhxol",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_0_CjUBz_08"]
                                    },
                                    {
                                      field: "__root.result.data.id",
                                      propPath: ["var_customed_14_fqdLVmFU"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_cQUBXprO" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "laglmpdr",
                                    path: "checkedDatas.id",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_cQUBXprO",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u83B7\u53D6\u89D2\u8272\u5B57\u6BB5\u6743\u9650\u9879,\u56DE\u586B\u5B57\u6BB5\u6743\u9650"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            laglmpdr: {
              onTreeQuery: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_cQUBXprO" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "laglmpdr",
                                    path: "checkedDatas.id",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_cQUBXprO",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u56DE\u586B\u5B57\u6BB5\u6743\u9650" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onTreeCheck: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_RyTBxZtP" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_16_KlmrreEK",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_RyTBxZtP",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_rbYQUzGz" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_12_CsqGaFOY",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_rbYQUzGz",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u66F4\u65B0\u529F\u80FD\u66F4\u65B0\u9879\u96C6,\u8BB0\u5F55\u5F53\u524D\u83DC\u5355\u7EA7\u5B57\u6BB5\u6570\u636E\u96C6"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            frldttaa: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [
                                    { expId: "exp_xExppfmf" },
                                    { expId: "exp_oEfppEoE" },
                                    { expId: "exp_olmrfrxt" },
                                    { expId: "exp_YgGJMGro" }
                                  ],
                                  operateForm: false
                                },
                                { askText: "", checkRule: null, checkTip: "" },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1627463403645",
                                  input: [
                                    {
                                      "__root._cond.value": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_xExppfmf",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.method": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_oEfppEoE",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root._cond.field": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_olmrfrxt",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    { "__root._condRel": "1 and 2 and 3" },
                                    {
                                      "__root._needTotal": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_YgGJMGro",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.code",
                                      propPath: ["var_customed_1_qPTVH9qo"]
                                    },
                                    {
                                      field: "__root.result.data.id",
                                      propPath: ["var_customed_15_wLibYuMs"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u83B7\u53D6\u89D2\u8272\u6570\u636E\u6743\u9650\u9879" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            iadllott: {
              onTreeQuery: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_gUoXAcqj" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    widgetId: "iadllott",
                                    path: "checkedDatas.id",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_gUoXAcqj",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u56DE\u586B\u6570\u636E\u6743\u9650" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onTreeCheck: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_RyTBxZtP" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_16_KlmrreEK",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_RyTBxZtP",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_DbvXkXPI" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.setVariableData) == null ? void 0 : _b.call(
                                _a2,
                                [
                                  {
                                    path: "var_customed_13_rskpNzsf",
                                    value: yield pageCtx.getExpResult({
                                      id: "exp_DbvXkXPI",
                                      source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                    })
                                  }
                                ],
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u66F4\u65B0\u529F\u80FD\u66F4\u65B0\u9879\u96C6,\u8BB0\u5F55\u5F53\u524D\u83DC\u5355\u7EA7\u6570\u636E\u6570\u636E\u96C6"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            ftWlrgip: {
              onTabChange: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "ftWlrgip",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["tapTab"]
                            }),
                            "\u529F\u80FD\u6743\u9650",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "fpmWefii",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u529F\u80FD\u6743\u9650\u6811"
                        }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "ftWlrgip",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["curTab"]
                            }),
                            "\u5B57\u6BB5\u6743\u9650",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "laglmpdr",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u5B57\u6BB5\u6743\u9650\u6811"
                        }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "ftWlrgip",
                              fromPaths: pageCtx.fromPaths,
                              propPath: ["tapTab"]
                            }),
                            "\u6570\u636E\u6743\u9650",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.dataReload) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  reloadEvents: [
                                    {
                                      widgetId: "iadllott",
                                      eventType: "onTreeQuery",
                                      pageType: "firstPage"
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u91CD\u8F7D\u63A7\u4EF6\u7C7B\u578B: \u6811\u5F62\u63A7\u4EF6 | \u6807\u9898: \u6570\u636E\u6743\u9650\u6811"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "dpllWtog",
                  children: [
                    {
                      id: "rttlfaml",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "Wtpdrmta",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "yqwfAOGv",
                  children: [
                    {
                      id: "SWSkxswd",
                      children: [
                        {
                          id: "RgigMChj",
                          children: [
                            {
                              id: "RgigMChj_treeHeaderIconBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "vQgSKssP",
                                  parentToChild: "1:1",
                                  type: "node"
                                },
                                {
                                  id: "zlgsBCtG",
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "VOlmuOlY",
                      children: [
                        {
                          id: "ftWlrgip",
                          children: [
                            {
                              id: "meplfmfl",
                              children: [
                                {
                                  id: "lglaWadd",
                                  children: [
                                    {
                                      id: "dgttaWoo",
                                      children: [
                                        {
                                          id: "fpmWefii",
                                          children: [
                                            {
                                              id: "fpmWefii_treeHeaderIconBtns",
                                              type: "renderProp",
                                              children: [
                                                {
                                                  id: "attiggmp",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "Wrgfefro",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ]
                                            }
                                          ],
                                          parentToChild: "1:1",
                                          type: "node"
                                        }
                                      ],
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "WeWrottp",
                                      children: [],
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "ttlefioa",
                              children: [
                                {
                                  id: "emlddmWf",
                                  children: [
                                    {
                                      id: "flfaiiia",
                                      children: [
                                        {
                                          id: "laglmpdr",
                                          children: [
                                            {
                                              id: "laglmpdr_treeHeaderIconBtns",
                                              type: "renderProp",
                                              children: [
                                                {
                                                  id: "ittfimWm",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "igWgggff",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ]
                                            }
                                          ],
                                          parentToChild: "1:1",
                                          type: "node"
                                        }
                                      ],
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "YtzsdRrI",
                                      children: [],
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "gpeotmel",
                              children: [
                                {
                                  id: "iWfmptWm",
                                  children: [
                                    {
                                      id: "gidgltWo",
                                      children: [
                                        {
                                          id: "iadllott",
                                          children: [
                                            {
                                              id: "iadllott_treeHeaderIconBtns",
                                              type: "renderProp",
                                              children: [
                                                {
                                                  id: "tmtWoWtl",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                },
                                                {
                                                  id: "frldttaa",
                                                  parentToChild: "1:1",
                                                  type: "node"
                                                }
                                              ]
                                            }
                                          ],
                                          parentToChild: "1:1",
                                          type: "node"
                                        }
                                      ],
                                      parentToChild: "1:1",
                                      type: "node"
                                    },
                                    {
                                      id: "gWefptma",
                                      children: [],
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ],
                                  parentToChild: "1:1",
                                  type: "node"
                                }
                              ],
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_ytcPVXqV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_WGCPBZEh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_qPviLwXa: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_HlGMSsDh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_gbFtbQLr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_MYSsiYpL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {}
            },
            exp_tioaptdt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  rttlfaml: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "rttlfaml",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_CoUlKwAf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).reduce(
                    (acc, [code, list]) => (param == null ? void 0 : param.$1).map(([code2]) => code2).includes(code) ? acc.concat(list) : acc,
                    []
                  ).filter((item, idx, list) => list.indexOf(item) === idx);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: {
                  var_customed_3_iexlbaib: { paramKey: "$0" },
                  var_customed_9_qbmziSOc: { paramKey: "$1" }
                }
              }
            },
            exp_GLVEsBmk: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$0).filter(
                    (list) => Array.isArray(list) && list.length === 3 && !!list[0]
                  ).reduce(
                    (list, [code, items, _items]) => list.concat(_items),
                    []
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: { var_customed_9_qbmziSOc: { paramKey: "$0" } }
              }
            },
            exp_QcOMjxqw: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$1).reduce(
                    (acc, [code, list]) => (param == null ? void 0 : param.$0).map(([code2]) => code2).includes(code) ? acc.concat(list) : acc,
                    []
                  ).filter((item, idx, list) => list.indexOf(item) === idx);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: {
                  var_customed_12_CsqGaFOY: { paramKey: "$0" },
                  var_customed_7_ZRNMEPAO: { paramKey: "$1" }
                }
              }
            },
            exp_oPwmVeqL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$0).filter(
                    (list) => Array.isArray(list) && list.length === 3 && !!list[0]
                  ).reduce(
                    (list, [code, items, _items]) => list.concat(_items),
                    []
                  ).filter((val) => val);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: { var_customed_12_CsqGaFOY: { paramKey: "$0" } }
              }
            },
            exp_ptkDmYbs: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$1).reduce(
                    (acc, [code, list]) => (param == null ? void 0 : param.$0).map(([code2]) => code2).includes(code) ? acc.concat(list) : acc,
                    []
                  ).filter((item, idx, list) => list.indexOf(item) === idx);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: {
                  var_customed_13_rskpNzsf: { paramKey: "$0" },
                  var_customed_5_dMwjqlKe: { paramKey: "$1" }
                }
              }
            },
            exp_LSVSHTxY: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$0).filter(
                    (list) => Array.isArray(list) && list.length === 3 && !!list[0]
                  ).reduce(
                    (list, [code, items, _items]) => list.concat(_items),
                    []
                  ).filter((val) => val);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "rttlfaml" }] },
              dependentVar: {
                customed: { var_customed_13_rskpNzsf: { paramKey: "$0" } }
              }
            },
            exp_ppomtxpf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [(param == null ? void 0 : param.$2) || (param == null ? void 0 : param.$0), param == null ? void 0 : param.$1];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "Wrgfefro" }] },
              dependentVar: {
                customed: { var_customed_17_MQmAHsHO: { paramKey: "$0" } },
                pageInput: { var_pageInput_2_0bcZqw_U: { paramKey: "$1" } },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_optpmxpf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["equ", "equ"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "Wrgfefro" }] },
              dependentVar: {}
            },
            exp_fraprtrt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["module_id", "role_id"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "Wrgfefro" }] },
              dependentVar: {}
            },
            exp_lMUJwSBf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = false;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "Wrgfefro" }] },
              dependentVar: {}
            },
            exp_ppxppxlr: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [(param == null ? void 0 : param.$2) || (param == null ? void 0 : param.$0), "field", param == null ? void 0 : param.$1];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "igWgggff" }] },
              dependentVar: {
                customed: { var_customed_17_MQmAHsHO: { paramKey: "$0" } },
                pageInput: { var_pageInput_2_0bcZqw_U: { paramKey: "$1" } },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_ptolpmlo: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["equ", "equ", "equ"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "igWgggff" }] },
              dependentVar: {}
            },
            exp_mftmplfp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["module_id", "permission_type", "role_id"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "igWgggff" }] },
              dependentVar: {}
            },
            exp_fuYdhxol: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = false;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "igWgggff" }] },
              dependentVar: {}
            },
            exp_xExppfmf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [(param == null ? void 0 : param.$2) || (param == null ? void 0 : param.$0), "data", param == null ? void 0 : param.$1];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "frldttaa" }] },
              dependentVar: {
                customed: { var_customed_17_MQmAHsHO: { paramKey: "$0" } },
                pageInput: { var_pageInput_2_0bcZqw_U: { paramKey: "$1" } },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_oEfppEoE: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["equ", "equ", "equ"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "frldttaa" }] },
              dependentVar: {}
            },
            exp_olmrfrxt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = ["module_id", "permission_type", "role_id"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "frldttaa" }] },
              dependentVar: {}
            },
            exp_YgGJMGro: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = false;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "frldttaa" }] },
              dependentVar: {}
            },
            exp_ZSFUbfVu: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).join(",");
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "RgigMChj" }] },
              dependentVar: {
                widget: { RgigMChj: { checkedKeys: { paramKey: "$0" } } }
              }
            },
            exp_huiGaiQv: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$1).filter(([code]) => code !== (param == null ? void 0 : param.$0)).concat([[param == null ? void 0 : param.$0, param == null ? void 0 : param.$2]]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "RgigMChj" }] },
              dependentVar: {
                customed: {
                  var_customed_10_roeWduBk: { paramKey: "$0" },
                  var_customed_3_iexlbaib: { paramKey: "$1" },
                  var_customed_2_DjjHIZXX: { paramKey: "$2" }
                }
              }
            },
            exp_dVubPEKt: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$1).filter(([code]) => code !== (param == null ? void 0 : param.$0)).concat([[param == null ? void 0 : param.$0, param == null ? void 0 : param.$2]]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "RgigMChj" }] },
              dependentVar: {
                customed: {
                  var_customed_10_roeWduBk: { paramKey: "$0" },
                  var_customed_7_ZRNMEPAO: { paramKey: "$1" },
                  var_customed_0_CjUBz_08: { paramKey: "$2" }
                }
              }
            },
            exp_glRcdWeH: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$1).filter(([code]) => code !== (param == null ? void 0 : param.$0)).concat([[param == null ? void 0 : param.$0, param == null ? void 0 : param.$2]]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "RgigMChj" }] },
              dependentVar: {
                customed: {
                  var_customed_10_roeWduBk: { paramKey: "$0" },
                  var_customed_5_dMwjqlKe: { paramKey: "$1" },
                  var_customed_1_qPTVH9qo: { paramKey: "$2" }
                }
              }
            },
            exp_KFNBNBBF: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(
                    (param == null ? void 0 : param.$1).filter(([code, items]) => code === (param == null ? void 0 : param.$2)).concat([["", param == null ? void 0 : param.$0]]).slice(0, 1).reduce((list, [code, items]) => list.concat(items), [])
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "fpmWefii" }] },
              dependentVar: {
                customed: {
                  var_customed_11_kvNtRxiJ: { paramKey: "$0" },
                  var_customed_9_qbmziSOc: { paramKey: "$1" }
                },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_kYxcLgzG: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).length > 0 ? param == null ? void 0 : param.$0 : ["1388009993298653184"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  fpmWefii: [
                    {
                      path: "conditions.0.value",
                      id: "fpmWefii",
                      type: "widget",
                      action: "changeConditions"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { RgigMChj: { checkedKeys: { paramKey: "$0" } } }
              }
            },
            exp_RyTBxZtP: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$0, ["0", "0", "0"]).filter((item) => item).slice(0, 3).map(
                    (item, index) => ["\u529F\u80FD\u6743\u9650", "\u5B57\u6BB5\u6743\u9650", "\u6570\u636E\u6743\u9650"].indexOf(param == null ? void 0 : param.$1) === index ? "".concat(index + 1) : item
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "iadllott" }] },
              dependentVar: {
                customed: { var_customed_16_KlmrreEK: { paramKey: "$0" } },
                widget: { ftWlrgip: { curTab: { paramKey: "$1" } } }
              }
            },
            exp_tKjpGjVA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$3).filter(([code]) => code !== (param == null ? void 0 : param.$2)).concat([
                    [param == null ? void 0 : param.$2, [].concat(param == null ? void 0 : param.$1), [].concat(param == null ? void 0 : param.$0)]
                  ]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "fpmWefii" }] },
              dependentVar: {
                widget: {
                  fpmWefii: {
                    "checkedDatas.authCode": { paramKey: "$0" },
                    "checkedDatas.code": { paramKey: "$1" }
                  }
                },
                customed: {
                  var_customed_10_roeWduBk: { paramKey: "$2" },
                  var_customed_9_qbmziSOc: { paramKey: "$3" }
                }
              }
            },
            exp_cQUBXprO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(
                    (param == null ? void 0 : param.$0).filter(([code, items]) => code === (param == null ? void 0 : param.$2)).concat([["", param == null ? void 0 : param.$1]]).slice(0, 1).reduce((list, [code, items]) => list.concat(items), [])
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "laglmpdr" }] },
              dependentVar: {
                customed: {
                  var_customed_12_CsqGaFOY: { paramKey: "$0" },
                  var_customed_14_fqdLVmFU: { paramKey: "$1" }
                },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_HVDVYgwD: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).length > 0 ? param == null ? void 0 : param.$0 : ["1388009993298653184"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  laglmpdr: [
                    {
                      path: "conditions.1.value",
                      id: "laglmpdr",
                      type: "widget",
                      action: "changeConditions"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { RgigMChj: { checkedKeys: { paramKey: "$0" } } }
              }
            },
            exp_rbYQUzGz: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$2).filter(([code]) => code !== (param == null ? void 0 : param.$3)).concat([
                    [param == null ? void 0 : param.$3, [].concat(param == null ? void 0 : param.$0), [].concat(param == null ? void 0 : param.$1)]
                  ]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "laglmpdr" }] },
              dependentVar: {
                widget: {
                  laglmpdr: {
                    "checkedDatas.roleId": { paramKey: "$0" },
                    "checkedDatas.code": { paramKey: "$1" }
                  }
                },
                customed: {
                  var_customed_12_CsqGaFOY: { paramKey: "$2" },
                  var_customed_10_roeWduBk: { paramKey: "$3" }
                }
              }
            },
            exp_GblBaGjA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).length > 0 ? param == null ? void 0 : param.$0 : ["1388009993298653184"];
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  iadllott: [
                    {
                      path: "conditions.1.value",
                      id: "iadllott",
                      type: "widget",
                      action: "changeConditions"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { RgigMChj: { checkedKeys: { paramKey: "$0" } } }
              }
            },
            exp_gUoXAcqj: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(
                    (param == null ? void 0 : param.$0).filter(([code, items]) => code === (param == null ? void 0 : param.$2)).concat([["", param == null ? void 0 : param.$1]]).slice(0, 1).reduce((list, [code, items]) => list.concat(items), [])
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "iadllott" }] },
              dependentVar: {
                customed: {
                  var_customed_13_rskpNzsf: { paramKey: "$0" },
                  var_customed_15_wLibYuMs: { paramKey: "$1" }
                },
                widget: { RgigMChj: { selectedKey: { paramKey: "$2" } } }
              }
            },
            exp_DbvXkXPI: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = [].concat(param == null ? void 0 : param.$1).filter(([code]) => code !== (param == null ? void 0 : param.$2)).concat([
                    [param == null ? void 0 : param.$2, [].concat(param == null ? void 0 : param.$3), [].concat(param == null ? void 0 : param.$0)]
                  ]);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "iadllott" }] },
              dependentVar: {
                widget: {
                  iadllott: {
                    "checkedDatas.code": { paramKey: "$0" },
                    "checkedDatas.id": { paramKey: "$3" }
                  }
                },
                customed: {
                  var_customed_13_rskpNzsf: { paramKey: "$1" },
                  var_customed_10_roeWduBk: { paramKey: "$2" }
                }
              }
            },
            exp_uMsmRmZi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0).length > 0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ftWlrgip: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "ftWlrgip",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { RgigMChj: { checkedKeys: { paramKey: "$0" } } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [{ id: "exp_tioaptdt", type: "exp" }]
            },
            widget: {
              RgigMChj: {
                checkedKeys: [
                  { id: "exp_kYxcLgzG", type: "exp" },
                  { id: "exp_HVDVYgwD", type: "exp" },
                  { id: "exp_GblBaGjA", type: "exp" },
                  { id: "exp_uMsmRmZi", type: "exp" }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {
            var_customed_17_MQmAHsHO: "1388009993298653184",
            var_customed_0_CjUBz_08: null,
            var_customed_1_qPTVH9qo: null,
            var_customed_2_DjjHIZXX: null,
            var_customed_3_iexlbaib: null,
            var_customed_5_dMwjqlKe: null,
            var_customed_7_ZRNMEPAO: null,
            var_customed_9_qbmziSOc: null,
            var_customed_10_roeWduBk: null,
            var_customed_11_kvNtRxiJ: null,
            var_customed_12_CsqGaFOY: null,
            var_customed_13_rskpNzsf: null,
            var_customed_14_fqdLVmFU: null,
            var_customed_15_wLibYuMs: null,
            var_customed_16_KlmrreEK: null
          },
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$dpllWtog`,
            key: `PC$$dpllWtog`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$dpllWtog$$rttlfaml`,
              key: `PC$$dpllWtog$$rttlfaml`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$dpllWtog$$Wtpdrmta`,
              key: `PC$$dpllWtog$$Wtpdrmta`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$yqwfAOGv`,
            key: `PC$$yqwfAOGv`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$yqwfAOGv$$SWSkxswd`,
              key: `PC$$yqwfAOGv$$SWSkxswd`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj`,
                key: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj`,
                pageCtx,
                widgetRef: "Tree",
                treeHeaderIconBtnsRenderer: (props) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj$$vQgSKssP`,
                      key: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj$$vQgSKssP`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj$$zlgsBCtG`,
                      key: `PC$$yqwfAOGv$$SWSkxswd$$RgigMChj$$zlgsBCtG`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                ]
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$yqwfAOGv$$VOlmuOlY`,
              key: `PC$$yqwfAOGv$$VOlmuOlY`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip`,
                key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip`,
                pageCtx,
                widgetRef: "TabContainer"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl`,
                  key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd`,
                    key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd`,
                    pageCtx,
                    widgetRef: "FlexLayoutContainer"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii`,
                        key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii`,
                        pageCtx,
                        widgetRef: "Tree",
                        treeHeaderIconBtnsRenderer: (props) => [
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii$$attiggmp`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii$$attiggmp`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii$$Wrgfefro`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$dgttaWoo$$fpmWefii$$Wrgfefro`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          )
                        ]
                      }
                    )
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$WeWrottp`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$meplfmfl$$lglaWadd$$WeWrottp`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    }
                  )
                )
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa`,
                  key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf`,
                    key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf`,
                    pageCtx,
                    widgetRef: "FlexLayoutContainer"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr`,
                        key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr`,
                        pageCtx,
                        widgetRef: "Tree",
                        treeHeaderIconBtnsRenderer: (props) => [
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr$$ittfimWm`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr$$ittfimWm`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr$$igWgggff`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$flfaiiia$$laglmpdr$$igWgggff`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          )
                        ]
                      }
                    )
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$YtzsdRrI`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$ttlefioa$$emlddmWf$$YtzsdRrI`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    }
                  )
                )
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel`,
                  key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel`,
                  pageCtx,
                  widgetRef: "FlexLayout"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm`,
                    key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm`,
                    pageCtx,
                    widgetRef: "FlexLayoutContainer"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    },
                    /* @__PURE__ */ react_default.createElement(
                      COMPCONTROL.CompEntry,
                      {
                        path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott`,
                        key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott`,
                        pageCtx,
                        widgetRef: "Tree",
                        treeHeaderIconBtnsRenderer: (props) => [
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott$$tmtWoWtl`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott$$tmtWoWtl`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          ),
                          /* @__PURE__ */ react_default.createElement(
                            COMPCONTROL.CompEntry,
                            {
                              path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott$$frldttaa`,
                              key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gidgltWo$$iadllott$$frldttaa`,
                              pageCtx,
                              widgetRef: "FormButton"
                            }
                          )
                        ]
                      }
                    )
                  ),
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gWefptma`,
                      key: `PC$$yqwfAOGv$$VOlmuOlY$$ftWlrgip$$gpeotmel$$iWfmptWm$$gWefptma`,
                      pageCtx,
                      widgetRef: "FlexLayout"
                    }
                  )
                )
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1423825106714636288, "pageName", "\u89D2\u8272\u529F\u80FD\u6388\u6743");
  __publicField(Page1423825106714636288, "$pageKey", "AJaAKiYU");
  __publicField(Page1423825106714636288, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
