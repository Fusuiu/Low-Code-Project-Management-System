var Page1547765588041019392 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1547765588041019392: () => Page1547765588041019392
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1547765588041019392 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1547765588041019392",
            pageName: "\u5E94\u7528\u5168\u5C40\u914D\u7F6E\u9875\u9762",
            apiMeta: {
              "1547754615196495872_detail_1657851013684": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.cfg_type": {
                    title: "cfg_type",
                    __key: "cfg_type",
                    _remoteType: "string_number",
                    _type: "number",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_desc": {
                    title: "\u63CF\u8FF0\u4FE1\u606F",
                    __key: "cfg_desc",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_val": {
                    title: "cfg_val",
                    __key: "cfg_val",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_key": {
                    title: "cfg_key",
                    __key: "cfg_key",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              "1547754615196495872_list_1657851014820": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.cfg_type": {
                    title: "cfg_type",
                    __key: "cfg_type",
                    _remoteType: "string_number",
                    _type: "number",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_desc": {
                    title: "\u63CF\u8FF0\u4FE1\u606F",
                    __key: "cfg_desc",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_val": {
                    title: "cfg_val",
                    __key: "cfg_val",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.cfg_key": {
                    title: "cfg_key",
                    __key: "cfg_key",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  cfg_type: {
                    title: "cfg_type"
                  },
                  cfg_desc: {
                    title: "\u63CF\u8FF0\u4FE1\u606F"
                  },
                  cfg_val: {
                    title: "cfg_val"
                  },
                  cfg_key: {
                    title: "cfg_key"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  }
                }
              },
              "1547754615196495872_del_1657851012922": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E\u96C6\u5408",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              title: "\u5E94\u7528\u5168\u5C40\u914D\u7F6E\u9875\u9762",
              sockets: null,
              dss: ["1547754615196495872_detail_1657851013684"],
              requests: {
                "1547754615196495872_detail_1657851013684": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              }
            },
            jqiDfjMa: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "jqiDfjMa",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              style: { height: "100%" },
              headerBtns: [{ title: "\u65B0\u589E", btnType: "create" }],
              headerBtnsConfig: [
                { title: "\u65B0\u589E", amIFold: false, widgetId: "iqWszhSb" }
              ],
              inlineBtnsConfig: [
                {
                  title: "\u4FEE\u6539",
                  amIFold: false,
                  widgetId: "raMVSKHn",
                  show: "exp",
                  type: "update",
                  groupId: "ENDBofee"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "pjpoeBLr",
                  show: "exp",
                  type: "custom_FHGreNMe",
                  groupId: "ENDBofee"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "elqLpHLY",
                  show: "visible",
                  type: "delete",
                  groupId: "ENDBofee"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "cfg_key",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "BXaZYmNb",
                  widgetRef: "FormInput",
                  title: "\u914D\u7F6E\u952E",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "cfg_val",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "yRkloYtN",
                  widgetRef: "FormInput",
                  title: "\u914D\u7F6E\u503C",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "cfg_desc",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "wwsUOhne",
                  widgetRef: "FormInput",
                  title: "\u63CF\u8FF0\u4FE1\u606F",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "cfg_type",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "tAnxSwxp",
                  widgetRef: "FormInputNumber",
                  title: "\u914D\u7F6E\u7C7B\u578B",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "create_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "1",
                  showSortBtn: true,
                  widgetId: "PKWIswsz",
                  widgetRef: "FormDateTimePicker",
                  title: "\u521B\u5EFA\u65F6\u95F4",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "last_update_time",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "1",
                  showSortBtn: true,
                  widgetId: "YREMziWQ",
                  widgetRef: "FormDateTimePicker",
                  title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              tagKey: "",
              keyshow: false,
              ds: "1547754615196495872_list_1657851014820",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "cfg_type",
                "cfg_desc",
                "cfg_val",
                "cfg_key",
                "create_user_id",
                "last_update_time",
                "sequence",
                "create_time",
                "create_user_name",
                "id",
                "last_update_user_id",
                "last_update_user_name"
              ]
            },
            wZTQXpig: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "wZTQXpig",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            XRgOGOiv: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "XRgOGOiv",
              visible: true,
              customId: "jqiDfjMa_headerBtns",
              btnsConfig: [
                { title: "\u65B0\u589E", amIFold: false, widgetId: "iqWszhSb" }
              ],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            iqWszhSb: {
              title: "\u65B0\u589E",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "iqWszhSb",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              size: "middle",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              type: "primary"
            },
            ENDBofee: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "ENDBofee",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "jqiDfjMa_inlineBtns",
              btnsConfig: [
                {
                  title: "\u4FEE\u6539",
                  amIFold: false,
                  widgetId: "raMVSKHn",
                  show: "exp",
                  type: "update",
                  groupId: "ENDBofee"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "pjpoeBLr",
                  show: "exp",
                  type: "custom_FHGreNMe",
                  groupId: "ENDBofee"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "elqLpHLY",
                  show: "visible",
                  type: "delete",
                  groupId: "ENDBofee"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            raMVSKHn: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "raMVSKHn",
              title: "\u4FEE\u6539",
              visible: false,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            pjpoeBLr: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "pjpoeBLr",
              title: "\u4FEE\u6539",
              visible: false,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            elqLpHLY: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "elqLpHLY",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            BXaZYmNb: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "BXaZYmNb",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "cfg_key",
              fieldColumn: { field: "cfg_key", title: "cfg_key" },
              widgetCode: "FormInput$1",
              $lazyload: false,
              columnName: "cfg_key"
            },
            yRkloYtN: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "yRkloYtN",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "cfg_val",
              fieldColumn: { field: "cfg_val", title: "cfg_val" },
              widgetCode: "FormInput$1",
              $lazyload: false,
              columnName: "cfg_val"
            },
            wwsUOhne: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "wwsUOhne",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "cfg_desc",
              fieldColumn: { field: "cfg_desc", title: "\u63CF\u8FF0\u4FE1\u606F" },
              $lazyload: false,
              columnName: "cfg_desc"
            },
            tAnxSwxp: {
              varMap: {
                saveValV2: { type: "number" },
                realValV2: { type: "number" }
              },
              widgetRef: "FormInputNumber",
              eventAttr: ["onChange", "onBlur", "onClick"],
              group: "formInput",
              id: "tAnxSwxp",
              checkByExp: [],
              titleAlign: "left",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              precision: 0,
              maxPrecision: 0,
              field: "cfg_type",
              fieldColumn: { field: "cfg_type", title: "cfg_type" },
              widgetCode: "FormInputNumber$1",
              $lazyload: false,
              columnName: "cfg_type"
            },
            PKWIswsz: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "PKWIswsz",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              field: "create_time",
              fieldColumn: { field: "create_time", title: "\u521B\u5EFA\u65F6\u95F4" },
              $lazyload: false,
              columnName: "create_time"
            },
            YREMziWQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              id: "YREMziWQ",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              field: "last_update_time",
              fieldColumn: { field: "last_update_time", title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4" },
              $lazyload: false,
              columnName: "last_update_time"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1547754615196495872_detail_1657851013684",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1547754615196495872_detail_1657851013684",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            iqWszhSb: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b, _c;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1547767785998921728",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "QLgfXpyn",
                                  pageNameCn: "\u65B0\u589E\u6570\u636E",
                                  params: [{ var_pageInput_0_mode: "insert" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "iqWszhSb"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
                return yield (_c = platform_action_default) == null ? void 0 : _c.eventExecute(
                  {
                    events: [
                      {
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1547767785998921728",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "QLgfXpyn",
                                  pageNameCn: "\u65B0\u589E\u6570\u636E",
                                  params: [{ var_pageInput_0_mode: "insert" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "iqWszhSb"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            raMVSKHn: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b, _c;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "jqiDfjMa",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1547767785998921728",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "PcjoctUR",
                                  pageNameCn: "\u4FEE\u6539_\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "jqiDfjMa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "raMVSKHn"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
                return yield (_c = platform_action_default) == null ? void 0 : _c.eventExecute(
                  {
                    events: [
                      {
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "jqiDfjMa",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1547767785998921728",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "PcjoctUR",
                                  pageNameCn: "\u4FEE\u6539_\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "jqiDfjMa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "raMVSKHn"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            pjpoeBLr: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "jqiDfjMa",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1556487823463428096",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: "currentApp",
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: true,
                                  showTopBar: void 0,
                                  id: "PijPICWx",
                                  pageNameCn: "\u5E26\u4E0B\u62C9\u6846\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355",
                                  params: [
                                    { var_pageInput_0_mode: "update" },
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "jqiDfjMa",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b2;
                                                  return yield (_b2 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b2.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "pjpoeBLr"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u6253\u5F00\u9875\u9762:\u5E26\u4E0B\u62C9\u6846\u5E94\u7528\u914D\u7F6E\u8868\u8868\u5355"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            elqLpHLY: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "jqiDfjMa",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  selectRowCheckBool: true,
                                  askText: "\u786E\u5B9A\u5220\u9664\u5417\uFF1F",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "1547754615196495872_del_1657851012922",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "elqLpHLY"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "jqiDfjMa",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "jqiDfjMa",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["lastSelectedRowKey"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5220\u9664[\u5E94\u7528\u914D\u7F6E\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "jqiDfjMa",
                  children: [
                    { id: "wZTQXpig", children: [] },
                    {
                      id: "jqiDfjMa_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "XRgOGOiv",
                          parentToChild: "1:1",
                          type: "node",
                          children: [
                            {
                              id: "iqWszhSb",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "jqiDfjMa_inlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "ENDBofee",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "raMVSKHn",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "pjpoeBLr",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "elqLpHLY",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "jqiDfjMa_columns",
                      type: "renderProp",
                      children: [
                        {
                          id: "BXaZYmNb",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "yRkloYtN",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "wwsUOhne",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "tAnxSwxp",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "PKWIswsz",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "YREMziWQ",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_iFhKXQNd: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "storage_type";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  raMVSKHn: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "raMVSKHn",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  jqiDfjMa: {
                    "currentRow.cfg_key.realValV2": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_HvcKyXEh: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "storage_type";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  pjpoeBLr: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "pjpoeBLr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  jqiDfjMa: {
                    "currentRow.cfg_key.realValV2": { paramKey: "$0" }
                  }
                }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            widget: {
              jqiDfjMa: {
                "currentRow.cfg_key.realValV2": [
                  { id: "exp_iFhKXQNd", type: "exp" },
                  { id: "exp_HvcKyXEh", type: "exp" }
                ]
              }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$jqiDfjMa`,
            key: `PC$$jqiDfjMa`,
            pageCtx,
            widgetRef: "NormalTable",
            headerBtnsRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$XRgOGOiv`,
                  key: `PC$$jqiDfjMa$$XRgOGOiv`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$jqiDfjMa$$XRgOGOiv$$iqWszhSb`,
                    key: `PC$$jqiDfjMa$$XRgOGOiv$$iqWszhSb`,
                    pageCtx,
                    widgetRef: "FormButton"
                  }
                )
              )
            ],
            inlineBtnsRenderer: ({ index: indexFromjqiDfjMa, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee`,
                key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$raMVSKHn`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$raMVSKHn`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$pjpoeBLr`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$pjpoeBLr`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$elqLpHLY`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$ENDBofee$$elqLpHLY`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            columnsRenderer: ({ index: indexFromjqiDfjMa }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$BXaZYmNb`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$BXaZYmNb`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$yRkloYtN`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$yRkloYtN`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$wwsUOhne`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$wwsUOhne`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$tAnxSwxp`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$tAnxSwxp`,
                  pageCtx,
                  widgetRef: "FormInputNumber"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$PKWIswsz`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$PKWIswsz`,
                  pageCtx,
                  widgetRef: "FormDateTimePicker"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$YREMziWQ`,
                  key: `PC$$jqiDfjMa$$%${indexFromjqiDfjMa}%$$YREMziWQ`,
                  pageCtx,
                  widgetRef: "FormDateTimePicker"
                }
              )
            ]
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$jqiDfjMa$$wZTQXpig`,
              key: `PC$$jqiDfjMa$$wZTQXpig`,
              pageCtx,
              widgetRef: "GridLayoutSearch"
            }
          )
        )
      );
    }
  };
  __publicField(Page1547765588041019392, "pageName", "\u5E94\u7528\u5168\u5C40\u914D\u7F6E\u9875\u9762");
  __publicField(Page1547765588041019392, "$pageKey", "lrAmObfx");
  __publicField(Page1547765588041019392, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
