var Page1611352642708189184 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1611352642708189184: () => Page1611352642708189184
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1611352642708189184 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1611352642708189184",
            pageName: "lizehai\u5E94\u7528\u6CE8\u518C\u9875\u9762",
            apiMeta: {
              bis_api_1652867751078: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "data",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.apply_key": {
                    title: "\u5FAE\u5E94\u7528key",
                    __key: "apply_key",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.agent_id": {
                    title: "\u5FAE\u5E94\u7528ID",
                    __key: "agent_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.apply_secret": {
                    title: "\u5FAE\u5E94\u7528\u5BC6\u94A5",
                    __key: "apply_secret",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.apply_type": {
                    title: "\u5FAE\u5E94\u7528\u7C7B\u578B",
                    __key: "apply_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.apply_code": {
                    title: "\u5E94\u7528\u7F16\u7801",
                    __key: "apply_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.app_code": {
                    title: "\u5E94\u7528",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1653035996675: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "lizehai\u5E94\u7528\u6CE8\u518C\u9875\u9762"
            },
            cvhXZIJA: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "cvhXZIJA",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: true,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              refresh: true,
              columnSet: true,
              customSetSave: true,
              fullscreen: true,
              style: { height: "100%" },
              titleWeight: 400,
              labelColor: "#272727",
              showFilterCond: false,
              headerBtns: [{ title: "\u6CE8\u518C", btnType: "create" }],
              headerBtnsConfig: [{ title: "\u6CE8\u518C", widgetId: "CiFLOwCL" }],
              inlineBtnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: true,
                  widgetId: "JOXQQbjG",
                  show: "visible",
                  type: "delete",
                  groupId: "jZZQBGPY",
                  pageType: "curPage"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "apply_key",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  showSortBtn: false,
                  widgetId: "xCvsLHDd",
                  widgetRef: "FormInput",
                  title: "\u5FAE\u5E94\u7528key",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "agent_id",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  showSortBtn: false,
                  widgetId: "wdfIMjtV",
                  widgetRef: "FormInput",
                  title: "\u5FAE\u5E94\u7528ID",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "apply_secret",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  showSortBtn: false,
                  widgetId: "CZfDvumj",
                  widgetRef: "FormInput",
                  title: "\u5FAE\u5E94\u7528\u5BC6\u94A5",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "apply_type",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  showSortBtn: false,
                  title: "\u5FAE\u5E94\u7528\u7C7B\u578B",
                  widgetId: "VOpsHlKS",
                  widgetRef: "DropdownSelector",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                },
                {
                  dataIndex: "apply_code",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: false,
                  editType: "0",
                  showSortBtn: false,
                  widgetId: "gWzJixOa",
                  widgetRef: "FormInput",
                  title: "\u5E94\u7528\u7F16\u7801",
                  renderType: "defaultRender",
                  color: "#272727",
                  configShow: true
                }
              ],
              sortInfo: [],
              tagKey: "",
              keyshow: false,
              ds: "bis_api_1652867751078",
              rowKey: "id",
              socket: null,
              tableSortFieldList: []
            },
            PurUgiWH: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["FilterCond"]
              },
              id: "PurUgiWH",
              title: "\u641C\u7D22\u533A\u57DF",
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            pkaxtKPF: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "pkaxtKPF",
              visible: true,
              customId: "cvhXZIJA_headerBtns",
              btnsConfig: [{ title: "\u6CE8\u518C", widgetId: "CiFLOwCL" }],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            CiFLOwCL: {
              title: "\u6CE8\u518C",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "CiFLOwCL",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              fontStyle: { fontWeight: 400 },
              size: "middle",
              widgetCode: "FormButton$1",
              type: "primary"
            },
            jZZQBGPY: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "jZZQBGPY",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "cvhXZIJA_inlineBtns",
              btnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: true,
                  widgetId: "JOXQQbjG",
                  show: "visible",
                  type: "delete",
                  groupId: "jZZQBGPY",
                  pageType: "curPage"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            JOXQQbjG: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "JOXQQbjG",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              fontStyle: { fontWeight: 400 },
              size: "small",
              widgetCode: "FormButton$1",
              $lazyload: false,
              type: "link"
            },
            xCvsLHDd: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "xCvsLHDd",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$1",
              field: "apply_key",
              fieldColumn: { field: "apply_key", title: "\u5FAE\u5E94\u7528key" },
              $lazyload: false,
              columnName: "apply_key"
            },
            wdfIMjtV: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "wdfIMjtV",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$2",
              field: "agent_id",
              fieldColumn: { field: "agent_id", title: "\u5FAE\u5E94\u7528ID" },
              $lazyload: false,
              columnName: "agent_id"
            },
            CZfDvumj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "CZfDvumj",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$3",
              field: "apply_secret",
              fieldColumn: { field: "apply_secret", title: "\u5FAE\u5E94\u7528\u5BC6\u94A5" },
              $lazyload: false,
              columnName: "apply_secret"
            },
            VOpsHlKS: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              id: "VOpsHlKS",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$4",
              field: "apply_type",
              fieldColumn: { field: "apply_type", title: "\u5FAE\u5E94\u7528\u7C7B\u578B" },
              linkage: null,
              options: { 0: "\u4F01\u4E1A\u9489\u9489", 1: "\u4F01\u4E1A\u5FAE\u4FE1" },
              listHeight: "120",
              propOptions: {
                type: "custom",
                optionsConfig: [
                  { showVal: "\u4F01\u4E1A\u9489\u9489", realVal: "0" },
                  { showVal: "\u4F01\u4E1A\u5FAE\u4FE1", realVal: "1" }
                ]
              },
              $lazyload: false,
              bodyContainer: true,
              columnName: "apply_type",
              reloadEvents: ["getOptions"]
            },
            gWzJixOa: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "gWzJixOa",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$5",
              field: "apply_code",
              fieldColumn: { field: "apply_code", title: "\u5E94\u7528\u7F16\u7801" },
              $lazyload: false,
              columnName: "apply_code"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            CiFLOwCL: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1527577948935303168",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "TNIOuUbm",
                                  pageNameCn: "\u6CE8\u518C\u5E94\u7528",
                                  params: [{ var_pageInput_0_mode: "" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "CiFLOwCL"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5FAE\u5E94\u7528\u6CE8\u518C\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1527577948935303168",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "TNIOuUbm",
                                  pageNameCn: "\u6CE8\u518C\u5E94\u7528",
                                  params: [{ var_pageInput_0_mode: "" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "CiFLOwCL"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5FAE\u5E94\u7528\u6CE8\u518C\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            JOXQQbjG: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "cvhXZIJA",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  askText: "\u786E\u5B9A\u5220\u9664\u5417\uFF1F",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "bis_api_1653035996675",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "JOXQQbjG"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "cvhXZIJA",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "cvhXZIJA",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["lastSelectedRowKey"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5220\u9664\u5E94\u7528\u6CE8\u518C\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "cvhXZIJA",
                  children: [
                    { id: "PurUgiWH", children: [] },
                    {
                      id: "cvhXZIJA_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "pkaxtKPF",
                          parentToChild: "1:1",
                          type: "node",
                          children: [
                            {
                              id: "CiFLOwCL",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "cvhXZIJA_inlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "jZZQBGPY",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "JOXQQbjG",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "cvhXZIJA_columns",
                      type: "renderProp",
                      children: [
                        {
                          id: "xCvsLHDd",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "wdfIMjtV",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "CZfDvumj",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "VOpsHlKS",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "gWzJixOa",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {},
          // 表达式初始化信息
          monitor: { widget: {} },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$cvhXZIJA`,
            key: `PC$$cvhXZIJA`,
            pageCtx,
            widgetRef: "NormalTable",
            headerBtnsRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$pkaxtKPF`,
                  key: `PC$$cvhXZIJA$$pkaxtKPF`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$cvhXZIJA$$pkaxtKPF$$CiFLOwCL`,
                    key: `PC$$cvhXZIJA$$pkaxtKPF$$CiFLOwCL`,
                    pageCtx,
                    widgetRef: "FormButton"
                  }
                )
              )
            ],
            inlineBtnsRenderer: ({ index: indexFromcvhXZIJA, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$jZZQBGPY`,
                key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$jZZQBGPY`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$jZZQBGPY$$JOXQQbjG`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$jZZQBGPY$$JOXQQbjG`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            columnsRenderer: ({ index: indexFromcvhXZIJA }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$xCvsLHDd`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$xCvsLHDd`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$wdfIMjtV`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$wdfIMjtV`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$CZfDvumj`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$CZfDvumj`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$VOpsHlKS`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$VOpsHlKS`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$gWzJixOa`,
                  key: `PC$$cvhXZIJA$$%${indexFromcvhXZIJA}%$$gWzJixOa`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              )
            ]
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$cvhXZIJA$$PurUgiWH`,
              key: `PC$$cvhXZIJA$$PurUgiWH`,
              pageCtx,
              widgetRef: "GridLayoutSearch"
            }
          )
        )
      );
    }
  };
  __publicField(Page1611352642708189184, "pageName", "lizehai\u5E94\u7528\u6CE8\u518C\u9875\u9762");
  __publicField(Page1611352642708189184, "$pageKey", "XDZuNYNN");
  __publicField(Page1611352642708189184, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
