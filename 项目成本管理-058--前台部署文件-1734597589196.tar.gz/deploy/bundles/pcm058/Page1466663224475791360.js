var Page1466663224475791360 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1466663224475791360: () => Page1466663224475791360
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1466663224475791360 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1466663224475791360",
            pageName: "\u6D88\u606F\u4E2D\u5FC3",
            apiMeta: {
              bis_api_1638411246039: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.additional_param_1": {
                    title: "\u9644\u52A0\u53C2\u6570_1",
                    __key: "additional_param_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.redirect_url_type_1": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B_1",
                    __key: "redirect_url_type_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._redirect_url_type_1_json": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B_1\u663E\u793A\u503C_json",
                    __key: "_redirect_url_type_1_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._redirect_url_type_1_json._saveValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._redirect_url_type_1_json"
                  },
                  "__root.result.data._redirect_url_type_1_json._showValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._redirect_url_type_1_json"
                  },
                  "__root.result.data.jump_address_mode_1": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u65B9\u5F0F_1",
                    __key: "jump_address_mode_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.content_1": {
                    title: "\u5185\u5BB9_1",
                    __key: "content_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_1": {
                    title: "\u72B6\u6001_1",
                    __key: "status_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.url_1": {
                    title: "\u67E5\u770B\u5730\u5740_1",
                    __key: "url_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title_1": {
                    title: "\u6807\u9898_1",
                    __key: "title_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority_1": {
                    title: "\u4F18\u5148\u7EA7_1",
                    __key: "priority_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_1_json": {
                    title: "\u4F18\u5148\u7EA7_1\u663E\u793A\u503C_json",
                    __key: "_priority_1_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_1_json._saveValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._priority_1_json"
                  },
                  "__root.result.data._priority_1_json._showValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._priority_1_json"
                  },
                  "__root.result.data.template_code_1": {
                    title: "\u6A21\u677F\u7F16\u7801_1",
                    __key: "template_code_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id_1": {
                    title: "\u4E3B\u952E_1",
                    __key: "id_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_read": {
                    title: "\u662F\u5426\u5DF2\u8BFB",
                    __key: "is_read",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_read_json": {
                    title: "\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C_json",
                    __key: "_is_read_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_read_json._saveValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_read_json"
                  },
                  "__root.result.data._is_read_json._showValue": {
                    title: "\u5B58\u50A8\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_read_json"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              bis_api_1636602373113: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.additional_param_2": {
                    title: "\u9644\u52A0\u53C2\u6570_2",
                    __key: "additional_param_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.redirect_url_type_2": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B_2",
                    __key: "redirect_url_type_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.jump_address_mode_2": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u65B9\u5F0F_2",
                    __key: "jump_address_mode_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.content_2": {
                    title: "\u5185\u5BB9_2",
                    __key: "content_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.url_2": {
                    title: "\u67E5\u770B\u5730\u5740_2",
                    __key: "url_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title_2": {
                    title: "\u6807\u9898_2",
                    __key: "title_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority_2": {
                    title: "\u4F18\u5148\u7EA7_2",
                    __key: "priority_2",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.template_code_2": {
                    title: "\u6A21\u677F\u7F16\u7801_2",
                    __key: "template_code_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_2": {
                    title: "\u72B6\u6001_2",
                    __key: "status_2",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id_2": {
                    title: "\u4E3B\u952E_2",
                    __key: "id_2",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.": {
                    title: void 0,
                    __key: "",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              },
              bis_api_1638409040332: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.content": {
                    title: "\u6D88\u606F\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.read_num": {
                    title: "\u5DF2\u8BFB\u6570\u91CF",
                    __key: "read_num",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.msg_instance_id": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "msg_instance_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_type": {
                    title: "\u63A8\u9001\u65B9\u5F0F",
                    __key: "push_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_time": {
                    title: "\u63A8\u9001\u65F6\u95F4",
                    __key: "push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.time_push": {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
                    __key: "time_push",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.on_time_push_time": {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
                    __key: "on_time_push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_id": {
                    title: "\u5B9A\u65F6\u4EFB\u52A1\u4E3B\u952E",
                    __key: "task_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_status": {
                    title: "\u63A8\u9001\u72B6\u6001",
                    __key: "push_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {
                  content: {
                    title: "\u6D88\u606F\u5185\u5BB9"
                  },
                  read_num: {
                    title: "\u5DF2\u8BFB\u6570\u91CF"
                  },
                  msg_instance_id: {
                    title: "\u6D88\u606F\u4E3B\u952E"
                  },
                  push_type: {
                    title: "\u63A8\u9001\u65B9\u5F0F"
                  },
                  push_status: {
                    title: "\u63A8\u9001\u72B6\u6001"
                  },
                  push_time: {
                    title: "\u63A8\u9001\u65F6\u95F4"
                  },
                  time_push: {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001"
                  },
                  on_time_push_time: {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4"
                  },
                  task_id: {
                    title: "\u5B9A\u65F6\u4EFB\u52A1\u4E3B\u952E"
                  },
                  title: {
                    title: "\u6807\u9898"
                  },
                  priority: {
                    title: "\u4F18\u5148\u7EA7"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  _push_typename: {
                    title: "\u63A8\u9001\u65B9\u5F0F\u663E\u793A\u503C"
                  }
                }
              },
              bis_api_1637314611780: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.additional_param_1": {
                    title: "\u9644\u52A0\u53C2\u6570_1",
                    __key: "additional_param_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.redirect_url_type_1": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u7C7B\u578B_1",
                    __key: "redirect_url_type_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.jump_address_mode_1": {
                    title: "\u8DF3\u8F6C\u5730\u5740\u65B9\u5F0F_1",
                    __key: "jump_address_mode_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.content_1": {
                    title: "\u5185\u5BB9_1",
                    __key: "content_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_1": {
                    title: "\u72B6\u6001_1",
                    __key: "status_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.url_1": {
                    title: "\u67E5\u770B\u5730\u5740_1",
                    __key: "url_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title_1": {
                    title: "\u6807\u9898_1",
                    __key: "title_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority_1": {
                    title: "\u4F18\u5148\u7EA7_1",
                    __key: "priority_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.template_code_1": {
                    title: "\u6A21\u677F\u7F16\u7801_1",
                    __key: "template_code_1",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id_1": {
                    title: "\u4E3B\u952E_1",
                    __key: "id_1",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              },
              bis_api_1636106614928: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              },
              bis_api_1675687825300926465: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.isRead": {
                    title: "\u662F\u5426\u5DF2\u8BFB",
                    __key: "isRead",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root.result"
                  },
                  "__root.result.msgId": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "msgId",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.msgId": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "msgId",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              title: "\u6D88\u606F\u4E2D\u5FC3"
            },
            QwfSUnXN: {
              varMap: { curTab: { type: "string" }, tapTab: { type: "string" } },
              widgetRef: "TabContainer",
              eventAttr: ["onTabChange", "onTabClick"],
              id: "QwfSUnXN",
              title: "",
              visible: true,
              titleAlign: "left",
              tabsVisibleList: [true, true, true, true],
              curTab: "",
              tabsList: [
                {
                  title: "\u5168\u90E8\u6D88\u606F",
                  icon: "",
                  id: "DixOLDEP",
                  style: { height: "auto" }
                },
                {
                  title: "\u672A\u8BFB\u6D88\u606F",
                  icon: "",
                  id: "kBLCfDOz",
                  style: { height: "auto" }
                },
                {
                  title: "\u7CFB\u7EDF\u516C\u544A",
                  icon: "",
                  id: "lorCPnoZ",
                  style: { height: "auto" }
                },
                {
                  title: "\u6D41\u7A0B\u6D88\u606F",
                  icon: "",
                  id: "dxIhnVxr",
                  style: { height: "auto" }
                }
              ],
              style: { width: "100%", height: "auto", border: "0px" },
              widgetCode: "TabContainer$1"
            },
            DixOLDEP: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "DixOLDEP",
              span: 24,
              title: "\u6807\u7B7E1\u5BB9\u5668",
              style: { height: "auto", border: "0px" },
              visible: true,
              widgetCode: "FlexLayout$1"
            },
            iVEeUFME: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "iVEeUFME",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              style: {},
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "WtjAnnOd",
                  show: "visible",
                  type: "detail",
                  groupId: "XIsRZzQw"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "title_1",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  showSortBtn: true,
                  editableDataType: false,
                  widgetId: "cuSXRqsK",
                  widgetRef: "FormInput",
                  title: "\u6807\u9898",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [],
              tagKey: "",
              ds: "bis_api_1638411246039",
              rowKey: "id_1",
              socket: null,
              tableSortFieldList: [
                "additional_param_1",
                "redirect_url_type_1",
                "jump_address_mode_1",
                "content_1",
                "status_1",
                "url_1",
                "title_1",
                "priority_1",
                "template_code_1",
                "id_1"
              ],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "WHjJxoUZ", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "XIsRZzQw", type: "inlineBtns" }
              ]
            },
            OphghLDV: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "OphghLDV",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            WHjJxoUZ: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "WHjJxoUZ",
              visible: true,
              customId: "iVEeUFME_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            XIsRZzQw: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "XIsRZzQw",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "iVEeUFME_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "WtjAnnOd",
                  show: "visible",
                  type: "detail",
                  groupId: "XIsRZzQw"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            WtjAnnOd: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "WtjAnnOd",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            cuSXRqsK: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "cuSXRqsK",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$1",
              field: "title_1",
              fieldColumn: { field: "title_1" },
              $lazyload: false
            },
            kBLCfDOz: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "kBLCfDOz",
              span: 24,
              title: "\u6807\u7B7E2\u5BB9\u5668",
              style: { height: "auto", border: "0px" },
              visible: true,
              widgetCode: "FlexLayout$1"
            },
            atgEydTL: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "atgEydTL",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              style: {},
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "kqhFsqST",
                  show: "visible",
                  type: "detail",
                  groupId: "MWVlkmgF"
                }
              ],
              widgetCode: "NormalTable$2",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "title_2",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  showSortBtn: true,
                  editableDataType: false,
                  widgetId: "JFlcefnI",
                  widgetRef: "FormInput",
                  title: "\u6807\u9898",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [],
              tagKey: "",
              ds: "bis_api_1636602373113",
              rowKey: "id_2",
              socket: null,
              tableSortFieldList: [
                "additional_param_2",
                "redirect_url_type_2",
                "jump_address_mode_2",
                "content_2",
                "url_2",
                "title_2",
                "priority_2",
                "template_code_2",
                "status_2",
                "id_2"
              ],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "FHVlNSHZ", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "MWVlkmgF", type: "inlineBtns" }
              ]
            },
            XAZppEZT: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "XAZppEZT",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            FHVlNSHZ: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "FHVlNSHZ",
              visible: true,
              customId: "atgEydTL_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            MWVlkmgF: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "MWVlkmgF",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "atgEydTL_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  amIFold: false,
                  widgetId: "kqhFsqST",
                  show: "visible",
                  type: "detail",
                  groupId: "MWVlkmgF"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            kqhFsqST: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "kqhFsqST",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            JFlcefnI: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "JFlcefnI",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$1",
              field: "title_2",
              fieldColumn: { field: "title_2" },
              $lazyload: false
            },
            lorCPnoZ: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "lorCPnoZ",
              span: 24,
              title: "\u6807\u7B7E3\u5BB9\u5668",
              style: { height: "auto", border: "0px" },
              visible: true,
              widgetCode: "FlexLayout$1"
            },
            kLvlPJjA: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "kLvlPJjA",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              style: {},
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "AxaTTayT",
                  show: "visible",
                  type: "detail",
                  groupId: "pRMDBTit"
                }
              ],
              widgetCode: "NormalTable$3",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "title",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  showSortBtn: true,
                  widgetId: "sLBfrBTj",
                  widgetRef: "FormInput",
                  title: "\u6807\u9898",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [],
              tagKey: "",
              ds: "bis_api_1638409040332",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "content",
                "read_num",
                "msg_instance_id",
                "push_type",
                "push_status",
                "push_time",
                "time_push",
                "on_time_push_time",
                "task_id",
                "title",
                "priority",
                "create_user_id",
                "sequence",
                "create_time",
                "create_user_name",
                "id"
              ],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "FciAdokF", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "pRMDBTit", type: "inlineBtns" }
              ]
            },
            AEKjqGVe: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "AEKjqGVe",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            FciAdokF: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "FciAdokF",
              visible: true,
              customId: "kLvlPJjA_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            pRMDBTit: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "pRMDBTit",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "kLvlPJjA_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "AxaTTayT",
                  show: "visible",
                  type: "detail",
                  groupId: "pRMDBTit"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            AxaTTayT: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "AxaTTayT",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            sLBfrBTj: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "sLBfrBTj",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "title",
              fieldColumn: { field: "title" },
              $lazyload: false
            },
            dxIhnVxr: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "dxIhnVxr",
              span: 24,
              title: "\u6807\u7B7E4\u5BB9\u5668",
              style: { height: "auto", border: "0px" },
              visible: true
            },
            PosSPuEk: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "PosSPuEk",
              title: "\u8868\u683C",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              style: {},
              headerBtns: [],
              headerBtnsConfig: [],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "RviIgglS",
                  show: "visible",
                  type: "detail",
                  groupId: "FwqWHPLR"
                }
              ],
              widgetCode: "NormalTable$4",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "title_1",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  showSortBtn: true,
                  editableDataType: false,
                  widgetId: "mWHRONGa",
                  widgetRef: "FormInput",
                  title: "\u6807\u9898",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [],
              tagKey: "",
              ds: "bis_api_1637314611780",
              rowKey: "id_1",
              socket: null,
              tableSortFieldList: [
                "additional_param_1",
                "redirect_url_type_1",
                "jump_address_mode_1",
                "content_1",
                "status_1",
                "url_1",
                "title_1",
                "priority_1",
                "template_code_1",
                "id_1"
              ],
              eventTypesWithTags: [],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "eTbkOwrz", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "FwqWHPLR", type: "inlineBtns" }
              ]
            },
            SPQnVcTo: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "SPQnVcTo",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            eTbkOwrz: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "eTbkOwrz",
              visible: true,
              customId: "PosSPuEk_headerBtns",
              btnsConfig: [],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            FwqWHPLR: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "FwqWHPLR",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "PosSPuEk_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "RviIgglS",
                  show: "visible",
                  type: "detail",
                  groupId: "FwqWHPLR"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            RviIgglS: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "RviIgglS",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            mWHRONGa: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "mWHRONGa",
              checkByExp: [],
              visible: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$1",
              field: "title_1",
              fieldColumn: { field: "title_1" },
              $lazyload: false
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            WtjAnnOd: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  var _a3, _b2, _c, _d;
                                  const {
                                    setState,
                                    getState,
                                    widgetEventCtx
                                  } = platformCtx;
                                  const value = getState(
                                    "currentRow_iVEeUFME.url_1"
                                  );
                                  const title = getState(
                                    "currentRow_iVEeUFME.title_1"
                                  );
                                  const template = getState(
                                    "currentRow_iVEeUFME.template_code_1"
                                  );
                                  const id = getState(
                                    "currentRow_iVEeUFME.additional_param_1"
                                  );
                                  var sysnoticeparam = JSON.parse(id);
                                  if (template == "SYS_NOTICE") {
                                    (_b2 = (_a3 = platform_action_default) == null ? void 0 : _a3.openPage) == null ? void 0 : _b2.call(
                                      _a3,
                                      {
                                        url: "",
                                        openType: "openModal",
                                        link: value,
                                        pageArea: "pageInApp",
                                        pageNameCn: title,
                                        params: [sysnoticeparam],
                                        onCancel: () => __async(this, null, function* () {
                                        }),
                                        onClosePageInCancel: () => __async(this, null, function* () {
                                        })
                                      },
                                      pageCtx
                                    );
                                  } else {
                                    (_d = (_c = platform_action_default) == null ? void 0 : _c.openPage) == null ? void 0 : _d.call(
                                      _c,
                                      {
                                        url: "",
                                        openType: "openModal",
                                        link: value,
                                        pageArea: "pageInApp",
                                        pageNameCn: title,
                                        params: [sysnoticeparam],
                                        onCancel: () => __async(this, null, function* () {
                                        }),
                                        onClosePageInCancel: () => __async(this, null, function* () {
                                        })
                                      },
                                      pageCtx
                                    );
                                  }
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          }
                        ],
                        log: { objectBehavior: "\u67E5\u770B\u5168\u90E8\u6D88\u606F\u5F39\u7A97" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            kqhFsqST: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "atgEydTL",
                                      path: ["currentRow", "id_2", "saveValV2"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1636106614928",
                                  input: [
                                    {
                                      "__root.id": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "atgEydTL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "currentRow",
                                            "id_2",
                                            "saveValV2"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6D88\u606F\u5DF2\u8BFB" }
                      },
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  var _a3, _b2, _c, _d;
                                  const {
                                    setState,
                                    getState,
                                    widgetEventCtx
                                  } = platformCtx;
                                  const value = getState(
                                    "currentRow_atgEydTL.url_2"
                                  );
                                  const title = getState(
                                    "currentRow_atgEydTL.title_2"
                                  );
                                  const template = getState(
                                    "currentRow_atgEydTL.template_code_2"
                                  );
                                  const id = getState(
                                    "currentRow_atgEydTL.additional_param_2"
                                  );
                                  var sysnoticeparam = JSON.parse(id);
                                  if (template == "SYS_NOTICE") {
                                    (_b2 = (_a3 = platform_action_default) == null ? void 0 : _a3.openPage) == null ? void 0 : _b2.call(
                                      _a3,
                                      {
                                        url: "",
                                        openType: "openModal",
                                        link: value,
                                        pageArea: "pageInApp",
                                        pageNameCn: title,
                                        params: [sysnoticeparam],
                                        onCancel: () => __async(this, null, function* () {
                                        }),
                                        onClosePageInCancel: () => __async(this, null, function* () {
                                        })
                                      },
                                      pageCtx
                                    );
                                  } else {
                                    (_d = (_c = platform_action_default) == null ? void 0 : _c.openPage) == null ? void 0 : _d.call(
                                      _c,
                                      {
                                        url: "",
                                        openType: "openModal",
                                        link: value,
                                        pageArea: "pageInApp",
                                        pageNameCn: title,
                                        params: [sysnoticeparam],
                                        onCancel: () => __async(this, null, function* () {
                                        }),
                                        onClosePageInCancel: () => __async(this, null, function* () {
                                        })
                                      },
                                      pageCtx
                                    );
                                  }
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "atgEydTL",
                                      path: ["currentRow", "id_2", "saveValV2"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1675687825300926465",
                                  input: [
                                    {
                                      "__root.msgId": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "atgEydTL",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "currentRow",
                                            "id_2",
                                            "saveValV2"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: {
                          objectBehavior: "\u67E5\u770B\u672A\u8BFB\u6D88\u606F\u5F39\u7A97,\u624B\u52A8\u63A8\u9001\u5DF2\u8BFB\u6D88\u606F"
                        }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            AxaTTayT: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "kLvlPJjA",
                                      path: ["lastSelectedRow", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1466676114599587840",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { height: null, width: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "InsfDSRo",
                                  pageNameCn: "\u67E5\u770B\u516C\u544A",
                                  params: [
                                    {
                                      var_pageInput_2_LnvVQzBw: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kLvlPJjA",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRow", "id"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u516C\u544A\u8BE6\u60C5\u5F39\u7A97" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            RviIgglS: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.codeSnippet) == null ? void 0 : _b.call(_a2, () => __async(this, null, function* () {
                                function main(platformCtx) {
                                  var _a3, _b2;
                                  const {
                                    setState,
                                    getState,
                                    widgetEventCtx
                                  } = platformCtx;
                                  const value = getState(
                                    "currentRow_PosSPuEk.url_1"
                                  );
                                  const title = getState(
                                    "currentRow_PosSPuEk.title_1"
                                  );
                                  const template = getState(
                                    "currentRow_PosSPuEk.template_code_1"
                                  );
                                  const id = getState(
                                    "currentRow_PosSPuEk.additional_param_1"
                                  );
                                  var sysnoticeparam = JSON.parse(id);
                                  (_b2 = (_a3 = platform_action_default) == null ? void 0 : _a3.openPage) == null ? void 0 : _b2.call(
                                    _a3,
                                    {
                                      url: "",
                                      openType: "openModal",
                                      link: value,
                                      pageArea: "pageInApp",
                                      pageNameCn: title,
                                      params: [sysnoticeparam],
                                      onCancel: () => __async(this, null, function* () {
                                      }),
                                      onClosePageInCancel: () => __async(this, null, function* () {
                                      })
                                    },
                                    pageCtx
                                  );
                                }
                                try {
                                  yield main(pageCtx);
                                } catch (e) {
                                  console.error("\u627E\u4E0D\u5230 main \u65B9\u6CD5\uFF0C\u8BF7\u68C0\u67E5\u4EE3\u7801");
                                  console.error(e);
                                }
                              }), pageCtx);
                            })
                          }
                        ],
                        log: { objectBehavior: "\u67E5\u770B\u6D41\u7A0B\u6D88\u606F\u5F39\u7A97" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "QwfSUnXN",
                  children: [
                    {
                      id: "DixOLDEP",
                      children: [
                        {
                          id: "iVEeUFME",
                          children: [
                            { id: "OphghLDV", children: [] },
                            {
                              id: "iVEeUFME_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "WHjJxoUZ",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "iVEeUFME_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "XIsRZzQw",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "WtjAnnOd",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "iVEeUFME_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "cuSXRqsK",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "kBLCfDOz",
                      children: [
                        {
                          id: "atgEydTL",
                          children: [
                            { id: "XAZppEZT", children: [] },
                            {
                              id: "atgEydTL_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "FHVlNSHZ",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "atgEydTL_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "MWVlkmgF",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "kqhFsqST",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "atgEydTL_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "JFlcefnI",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "lorCPnoZ",
                      children: [
                        {
                          id: "kLvlPJjA",
                          children: [
                            { id: "AEKjqGVe", children: [] },
                            {
                              id: "kLvlPJjA_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "FciAdokF",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "kLvlPJjA_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "pRMDBTit",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "AxaTTayT",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "kLvlPJjA_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "sLBfrBTj",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "dxIhnVxr",
                      children: [
                        {
                          id: "PosSPuEk",
                          children: [
                            { id: "SPQnVcTo", children: [] },
                            {
                              id: "PosSPuEk_headerBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "eTbkOwrz",
                                  parentToChild: "1:1",
                                  type: "node",
                                  children: []
                                }
                              ]
                            },
                            {
                              id: "PosSPuEk_inlineBtns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "FwqWHPLR",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: [
                                    {
                                      id: "RviIgglS",
                                      parentToChild: "1:1",
                                      type: "node"
                                    }
                                  ]
                                }
                              ]
                            },
                            {
                              id: "PosSPuEk_columns",
                              type: "renderProp",
                              children: [
                                {
                                  id: "mWHRONGa",
                                  parentToChild: "1:n",
                                  type: "node",
                                  children: []
                                }
                              ]
                            }
                          ],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {},
          // 表达式初始化信息
          monitor: { widget: {} },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$QwfSUnXN`,
            key: `PC$$QwfSUnXN`,
            pageCtx,
            widgetRef: "TabContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$QwfSUnXN$$DixOLDEP`,
              key: `PC$$QwfSUnXN$$DixOLDEP`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME`,
                key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$WHjJxoUZ`,
                      key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$WHjJxoUZ`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromiVEeUFME, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$XIsRZzQw`,
                    key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$XIsRZzQw`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$XIsRZzQw$$WtjAnnOd`,
                      key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$XIsRZzQw$$WtjAnnOd`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromiVEeUFME }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$cuSXRqsK`,
                      key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$%${indexFromiVEeUFME}%$$cuSXRqsK`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$OphghLDV`,
                  key: `PC$$QwfSUnXN$$DixOLDEP$$iVEeUFME$$OphghLDV`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                }
              )
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$QwfSUnXN$$kBLCfDOz`,
              key: `PC$$QwfSUnXN$$kBLCfDOz`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL`,
                key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$FHVlNSHZ`,
                      key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$FHVlNSHZ`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromatgEydTL, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$MWVlkmgF`,
                    key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$MWVlkmgF`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$MWVlkmgF$$kqhFsqST`,
                      key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$MWVlkmgF$$kqhFsqST`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromatgEydTL }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$JFlcefnI`,
                      key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$%${indexFromatgEydTL}%$$JFlcefnI`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$XAZppEZT`,
                  key: `PC$$QwfSUnXN$$kBLCfDOz$$atgEydTL$$XAZppEZT`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                }
              )
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$QwfSUnXN$$lorCPnoZ`,
              key: `PC$$QwfSUnXN$$lorCPnoZ`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA`,
                key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$FciAdokF`,
                      key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$FciAdokF`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromkLvlPJjA, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$pRMDBTit`,
                    key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$pRMDBTit`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$pRMDBTit$$AxaTTayT`,
                      key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$pRMDBTit$$AxaTTayT`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromkLvlPJjA }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$sLBfrBTj`,
                      key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$%${indexFromkLvlPJjA}%$$sLBfrBTj`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$AEKjqGVe`,
                  key: `PC$$QwfSUnXN$$lorCPnoZ$$kLvlPJjA$$AEKjqGVe`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                }
              )
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$QwfSUnXN$$dxIhnVxr`,
              key: `PC$$QwfSUnXN$$dxIhnVxr`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk`,
                key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk`,
                pageCtx,
                widgetRef: "NormalTable",
                headerBtnsRenderer: () => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$eTbkOwrz`,
                      key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$eTbkOwrz`,
                      pageCtx,
                      widgetRef: "FormButtonGroup"
                    }
                  )
                ],
                inlineBtnsRenderer: ({ index: indexFromPosSPuEk, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$FwqWHPLR`,
                    key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$FwqWHPLR`,
                    pageCtx,
                    widgetRef: "FormButtonGroup"
                  },
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$FwqWHPLR$$RviIgglS`,
                      key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$FwqWHPLR$$RviIgglS`,
                      pageCtx,
                      widgetRef: "FormButton"
                    }
                  )
                )),
                columnsRenderer: ({ index: indexFromPosSPuEk }) => [
                  /* @__PURE__ */ react_default.createElement(
                    COMPCONTROL.CompEntry,
                    {
                      path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$mWHRONGa`,
                      key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$%${indexFromPosSPuEk}%$$mWHRONGa`,
                      pageCtx,
                      widgetRef: "FormInput"
                    }
                  )
                ]
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$SPQnVcTo`,
                  key: `PC$$QwfSUnXN$$dxIhnVxr$$PosSPuEk$$SPQnVcTo`,
                  pageCtx,
                  widgetRef: "GridLayoutSearch"
                }
              )
            )
          )
        )
      );
    }
  };
  __publicField(Page1466663224475791360, "pageName", "\u6D88\u606F\u4E2D\u5FC3");
  __publicField(Page1466663224475791360, "$pageKey", "yljdWlHw");
  __publicField(Page1466663224475791360, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
