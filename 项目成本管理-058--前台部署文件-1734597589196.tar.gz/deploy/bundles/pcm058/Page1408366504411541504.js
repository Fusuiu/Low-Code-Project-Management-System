var Page1408366504411541504 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1408366504411541504: () => Page1408366504411541504
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1408366504411541504 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1408366504411541504",
            pageName: "\u7528\u6237\u8868\u5355",
            apiMeta: {
              "1333649712808603648_detail_1620293835389": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_system_recode": {
                    title: "\u7CFB\u7EDF\u8BB0\u5F55",
                    __key: "is_system_recode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.pwd_status": {
                    title: "\u5BC6\u7801\u72B6\u60011\u91CD\u7F6E\u72B6\u6001\u5176\u4ED6\u6B63\u5E38\u72B6\u6001",
                    __key: "pwd_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.password": {
                    title: "\u5BC6\u7801",
                    __key: "password",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.user_account_name": {
                    title: "\u8D26\u53F7\u540D",
                    __key: "user_account_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.username": {
                    title: "\u7528\u6237\u540D",
                    __key: "username",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1333649712808603648_insert_1620293835259": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.pwd_status": {
                    title: "\u5BC6\u7801\u72B6\u60011\u91CD\u7F6E\u72B6\u6001\u5176\u4ED6\u6B63\u5E38\u72B6\u6001",
                    __key: "pwd_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.password": {
                    title: "\u5BC6\u7801",
                    __key: "password",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.is_system_recode": {
                    title: "\u7CFB\u7EDF\u8BB0\u5F55",
                    __key: "is_system_recode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.user_account_name": {
                    title: "\u8D26\u53F7\u540D",
                    __key: "user_account_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.username": {
                    title: "\u7528\u6237\u540D",
                    __key: "username",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              "1333649712808603648_update_1620293835324": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.data": {
                    title: "\u8868\u6570\u636E",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.data.pwd_status": {
                    title: "\u5BC6\u7801\u72B6\u60011\u91CD\u7F6E\u72B6\u6001\u5176\u4ED6\u6B63\u5E38\u72B6\u6001",
                    __key: "pwd_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.password": {
                    title: "\u5BC6\u7801",
                    __key: "password",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.is_system_recode": {
                    title: "\u7CFB\u7EDF\u8BB0\u5F55",
                    __key: "is_system_recode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.user_account_name": {
                    title: "\u8D26\u53F7\u540D",
                    __key: "user_account_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.data.username": {
                    title: "\u7528\u6237\u540D",
                    __key: "username",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.data"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {}
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              title: "\u7528\u6237\u8868\u5355",
              dss: ["1333649712808603648_detail_1620293835389"],
              requests: {
                "1333649712808603648_detail_1620293835389": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              },
              showBottomBar: true
            },
            megdWgai: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "megdWgai",
              contentAlign: "right",
              style: { height: "60px" },
              widgetCode: "FloatBar$7"
            },
            pWafameW: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "pWafameW",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              widgetCode: "FormButton$5",
              eventTypesWithTags: [],
              iconType: ""
            },
            iagogofg: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "iagogofg",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              eventTypesWithTags: [],
              widgetCode: "FormButton$1"
            },
            piWimial: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "piWimial",
              title: "\u7528\u6237\u540D",
              visible: true,
              required: true,
              style: {},
              field: "username",
              fieldInfo: {
                ds: "1333649712808603648_detail_1620293835389",
                path: "__root.result.data.username"
              },
              readOnly: false,
              widgetCode: "FormInput$7",
              stringLength: 32
            },
            igWtilra: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "igWtilra",
              title: "\u8D26\u53F7\u540D",
              visible: true,
              required: true,
              style: {},
              titleAlign: "left",
              field: "user_account_name",
              fieldInfo: {
                ds: "1333649712808603648_detail_1620293835389",
                path: "__root.result.data.user_account_name"
              },
              readOnly: false,
              widgetCode: "FormInput$1",
              stringLength: 32
            },
            ltadlpit: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" },
                checkVal: { type: "string" }
              },
              widgetRef: "FormInputPassword",
              eventAttr: ["onChange", "onChangeCheckVal", "onBlur"],
              group: "formInput",
              id: "ltadlpit",
              title: "\u5BC6\u7801",
              titleAlign: "left",
              visible: true,
              readOnly: false,
              required: false,
              checkPasswordRule: "",
              style: {},
              hasCheck: false,
              formatMode: { type: "passwordEncryption" },
              formatMethod: ["formatString", "passwordEncryption"],
              formatParam: [],
              widgetCode: "FormInputPassword$1",
              field: "password",
              fieldInfo: {
                ds: "1333649712808603648_detail_1620293835389",
                path: "__root.result.data.password"
              },
              stringLength: 128
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1333649712808603648_detail_1620293835389",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1333649712808603648_detail_1620293835389",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            pWafameW: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: true
                                },
                                {},
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.insertDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1333649712808603648_insert_1620293835259",
                                  insertType: "submitWholeForm",
                                  input: [],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u65B0\u589E\u7528\u6237\u6570\u636E" }
                      },
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "update",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [],
                                  operateForm: true
                                },
                                {},
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.updateDataByAPI) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "1333649712808603648_update_1620293835324",
                                  updateType: "submitWholeForm",
                                  input: [],
                                  conditionBasis: [
                                    {
                                      "__root.id": pageCtx.getDataByPath({
                                        target: "pageInput",
                                        path: "var_pageInput_1_id"
                                      })
                                    }
                                  ],
                                  apiTip: void 0,
                                  allFormInput: []
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u66F4\u65B0\u7528\u6237\u6570\u636E" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            iagogofg: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "megdWgai",
                  children: [
                    {
                      id: "pWafameW",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "iagogofg",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "piWimial",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "igWtilra",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "ltadlpit",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_fmaaEopo: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  pWafameW: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "pWafameW",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_milmrigl: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  piWimial: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "piWimial",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_tdlWiedm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  igWtilra: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "igWtilra",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_oWpiaerm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ltadlpit: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ltadlpit",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ptpmprol: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "insert";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ltadlpit: [
                    {
                      path: "required",
                      defaultValue: false,
                      id: "ltadlpit",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_fmaaEopo", type: "exp" },
                { id: "exp_milmrigl", type: "exp" },
                { id: "exp_tdlWiedm", type: "exp" },
                { id: "exp_oWpiaerm", type: "exp" },
                { id: "exp_ptpmprol", type: "exp" }
              ]
            },
            widget: {}
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$megdWgai`,
            key: `PC$$megdWgai`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$megdWgai$$pWafameW`,
              key: `PC$$megdWgai$$pWafameW`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$megdWgai$$iagogofg`,
              key: `PC$$megdWgai$$iagogofg`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$piWimial`,
            key: `PC$$piWimial`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$igWtilra`,
            key: `PC$$igWtilra`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$ltadlpit`,
            key: `PC$$ltadlpit`,
            pageCtx,
            widgetRef: "FormInputPassword"
          }
        )
      );
    }
  };
  __publicField(Page1408366504411541504, "pageName", "\u7528\u6237\u8868\u5355");
  __publicField(Page1408366504411541504, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
