var Page1466676114599587840 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1466676114599587840: () => Page1466676114599587840
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1466676114599587840 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1466676114599587840",
            pageName: "\u516C\u544A\u8BE6\u60C5\u5F39\u7A97",
            apiMeta: {
              bis_api_1638424729922: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u6570\u636E\u96C6",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.content": {
                    title: "\u6D88\u606F\u5185\u5BB9",
                    __key: "content",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.read_num": {
                    title: "\u5DF2\u8BFB\u6570\u91CF",
                    __key: "read_num",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.msg_instance_id": {
                    title: "\u6D88\u606F\u4E3B\u952E",
                    __key: "msg_instance_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_type": {
                    title: "\u63A8\u9001\u65B9\u5F0F",
                    __key: "push_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._push_type_json": {
                    title: "\u63A8\u9001\u65B9\u5F0F\u663E\u793A\u503C",
                    __key: "_push_type_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_status": {
                    title: "\u63A8\u9001\u72B6\u6001",
                    __key: "push_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.push_time": {
                    title: "\u63A8\u9001\u65F6\u95F4",
                    __key: "push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.time_push": {
                    title: "\u662F\u5426\u5B9A\u65F6\u63A8\u9001",
                    __key: "time_push",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.on_time_push_time": {
                    title: "\u5B9A\u65F6\u63A8\u9001\u65F6\u95F4",
                    __key: "on_time_push_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_id": {
                    title: "\u5B9A\u65F6\u4EFB\u52A1\u4E3B\u952E",
                    __key: "task_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.title": {
                    title: "\u6807\u9898",
                    __key: "title",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.priority": {
                    title: "\u4F18\u5148\u7EA7",
                    __key: "priority",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priority_json": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C",
                    __key: "_priority_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._push_typename": {
                    title: "\u63A8\u9001\u65B9\u5F0F\u663E\u793A\u503C",
                    __key: "_push_typename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._priorityname": {
                    title: "\u4F18\u5148\u7EA7\u663E\u793A\u503C",
                    __key: "_priorityname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sys_notice_user": {
                    title: "\u9644\u5C5E\u8868_sys_notice_user",
                    __key: "sys_notice_user",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sys_notice_user.is_read": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB",
                    __key: "is_read",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._is_read_json": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C",
                    __key: "_is_read_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u7528\u6237\u4E3B\u952E",
                    __key: "user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.fid": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u5916\u952E",
                    __key: "fid",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._fid_json": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u5916\u952E\u663E\u793A\u503C",
                    __key: "_fid_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_time": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.sequence": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_time": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.create_user_name": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.data_version": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6570\u636E\u7248\u672C",
                    __key: "data_version",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_user_id": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user.last_update_user_name": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  },
                  "__root.result.data.sys_notice_user._is_readname": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E0E\u7528\u6237\u5173\u8054\u8868_\u662F\u5426\u5DF2\u8BFB\u663E\u793A\u503C",
                    __key: "_is_readname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data.sys_notice_user"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              },
              bis_api_1637315201300: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root.sys_notice": {
                    title: "\u7CFB\u7EDF\u516C\u544A\u4E3B\u952E",
                    __key: "sys_notice",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {}
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, {
            var_pageInput_0_mode: "insert",
            var_pageInput_1_id: "",
            var_pageInput_2_LnvVQzBw: null
          }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              title: "\u516C\u544A\u8BE6\u60C5\u5F39\u7A97",
              sockets: null,
              dss: ["bis_api_1638424729922"],
              requests: {
                bis_api_1638424729922: [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              }
            },
            KUSlJqmy: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              id: "KUSlJqmy",
              labelList: [""],
              style: {},
              showValColor: "#f68686",
              fontWeight: 600,
              fontSize: 22,
              titleWeight: 600,
              vGutter: 2,
              titleAlign: "center",
              iconType: "",
              visible: true,
              title: "",
              widgetCode: "TextLabel$1",
              field: "title",
              fieldInfo: {
                ds: "bis_api_1638424729922",
                path: "__root.result.data.title"
              },
              fieldSearch: null
            },
            MhpcnYzk: {
              varMap: {},
              widgetRef: "FormDivider",
              group: "actionControl",
              id: "MhpcnYzk",
              title: "\u516C\u544A\u5185\u5BB9",
              visible: true,
              lineType: "solid",
              lineWidth: 2,
              type: "horizontalTitleInline",
              titleAlign: "left",
              showValColor: "#f68686",
              style: { width: "100%" },
              widgetCode: "FormDivider$1",
              note: ""
            },
            zZijRiEZ: {
              group: "formInput",
              parseInReadOnly: true,
              varMap: { saveValV2: { type: "string" }, text: { type: "string" } },
              widgetRef: "RichEditor",
              eventAttr: ["onChange", "onFocus", "onBlur"],
              id: "zZijRiEZ",
              title: "",
              required: false,
              visible: true,
              height: 500,
              titleAlign: "left",
              style: {},
              readOnly: true,
              widgetCode: "RichEditor$2"
            },
            NYlCyPLb: {
              varMap: {},
              widgetRef: "FlexLayoutContainer",
              id: "NYlCyPLb",
              grid: [{ span: "16" }, { span: "6" }, { span: "2" }],
              hGutter: 0,
              vGutter: 0,
              style: { width: "100%", border: "0px", padding: "8px" },
              visible: true,
              widgetCode: "FlexLayoutContainer$1",
              title: "\u6805\u683C\u5E03\u5C401"
            },
            SRtqrEoO: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "SRtqrEoO",
              span: "16",
              title: "\u6805\u683C1",
              style: { height: "auto", border: "0px" },
              visible: true,
              widgetCode: "FlexLayout$1"
            },
            eeNZyuED: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "eeNZyuED",
              span: "6",
              visible: true,
              style: {},
              title: "\u6805\u683C2"
            },
            yTvZjfEb: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              id: "yTvZjfEb",
              labelList: [""],
              style: {},
              fontWeight: "400",
              fontSize: 16,
              titleSize: 14,
              titleWeight: 400,
              vGutter: 2,
              titleAlign: "center",
              iconType: "",
              visible: true,
              title: "\u53D1\u5E03\u65F6\u95F4",
              widgetCode: "TextLabel$9"
            },
            GfnxnTVT: {
              varMap: {},
              widgetRef: "FlexLayout",
              eventAttr: ["onCurPanelClick", "onCurTabChange", "onCurTabClick"],
              group: "container",
              isContainer: true,
              acceptChildStrategy: { strategy: "blackList", blackList: [] },
              id: "GfnxnTVT",
              span: "2",
              visible: true,
              style: {},
              title: "\u6805\u683C3",
              widgetCode: "FlexLayout$1"
            },
            OeIgQmJw: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "TextLabel",
              eventAttr: ["onClick"],
              group: "formInput",
              id: "OeIgQmJw",
              labelList: [""],
              style: {},
              fontWeight: "400",
              fontSize: 16,
              titleSize: 14,
              titleWeight: 400,
              vGutter: 2,
              titleAlign: "center",
              iconType: "",
              visible: true,
              title: "\u5DF2\u8BFB",
              widgetCode: "TextLabel$8"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_WXJavsuA" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1638424729922",
                                  input: [
                                    {
                                      "__root.id": yield pageCtx.getExpResult({
                                        id: "exp_WXJavsuA",
                                        source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                      })
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.content",
                                      widgetId: "zZijRiEZ",
                                      propPath: ["saveValV2"]
                                    },
                                    {
                                      field: "__root.result.data.read_num",
                                      widgetId: "OeIgQmJw",
                                      propPath: ["saveValV2"]
                                    },
                                    {
                                      field: "__root.result.data.title",
                                      widgetId: "KUSlJqmy",
                                      propPath: ["saveValV2"]
                                    },
                                    {
                                      field: "__root.result.data.push_time",
                                      widgetId: "yTvZjfEb",
                                      propPath: ["saveValV2"]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [],
                                  exps: [{ expId: "exp_IzUGhiJC" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1637315201300",
                                  input: [
                                    {
                                      "__root.sys_notice": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_IzUGhiJC",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u67E5\u8BE2\u516C\u544A\u8BE6\u60C5,\u516C\u544A\u5DF2\u8BFB" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "KUSlJqmy",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "MhpcnYzk",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "zZijRiEZ",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "NYlCyPLb",
                  children: [
                    {
                      id: "SRtqrEoO",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "eeNZyuED",
                      children: [
                        {
                          id: "yTvZjfEb",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "GfnxnTVT",
                      children: [
                        {
                          id: "OeIgQmJw",
                          children: [],
                          parentToChild: "1:1",
                          type: "node"
                        }
                      ],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_WXJavsuA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {
                pageInput: { var_pageInput_2_LnvVQzBw: { paramKey: "$0" } }
              }
            },
            exp_IzUGhiJC: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "PC" }] },
              dependentVar: {
                pageInput: { var_pageInput_2_LnvVQzBw: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: { widget: {} },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$KUSlJqmy`,
            key: `PC$$KUSlJqmy`,
            pageCtx,
            widgetRef: "TextLabel"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$MhpcnYzk`,
            key: `PC$$MhpcnYzk`,
            pageCtx,
            widgetRef: "FormDivider"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$zZijRiEZ`,
            key: `PC$$zZijRiEZ`,
            pageCtx,
            widgetRef: "RichEditor"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$NYlCyPLb`,
            key: `PC$$NYlCyPLb`,
            pageCtx,
            widgetRef: "FlexLayoutContainer"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$NYlCyPLb$$SRtqrEoO`,
              key: `PC$$NYlCyPLb$$SRtqrEoO`,
              pageCtx,
              widgetRef: "FlexLayout"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$NYlCyPLb$$eeNZyuED`,
              key: `PC$$NYlCyPLb$$eeNZyuED`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$NYlCyPLb$$eeNZyuED$$yTvZjfEb`,
                key: `PC$$NYlCyPLb$$eeNZyuED$$yTvZjfEb`,
                pageCtx,
                widgetRef: "TextLabel"
              }
            )
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$NYlCyPLb$$GfnxnTVT`,
              key: `PC$$NYlCyPLb$$GfnxnTVT`,
              pageCtx,
              widgetRef: "FlexLayout"
            },
            /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$NYlCyPLb$$GfnxnTVT$$OeIgQmJw`,
                key: `PC$$NYlCyPLb$$GfnxnTVT$$OeIgQmJw`,
                pageCtx,
                widgetRef: "TextLabel"
              }
            )
          )
        )
      );
    }
  };
  __publicField(Page1466676114599587840, "pageName", "\u516C\u544A\u8BE6\u60C5\u5F39\u7A97");
  __publicField(Page1466676114599587840, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
