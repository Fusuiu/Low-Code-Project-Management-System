var Page1551754708077654016 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1551754708077654016: () => Page1551754708077654016
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1551754708077654016 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1551754708077654016",
            pageName: "\u6A21\u677F\u7BA1\u7406",
            apiMeta: {
              "1551381265012371456_list_1658713163772": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.json": {
                    title: "\u9644\u4EF6\u5185\u5BB9json",
                    __key: "json",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.system_type": {
                    title: "\u7CFB\u7EDF\u7C7B\u578B",
                    __key: "system_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._system_type_json": {
                    title: "\u7CFB\u7EDF\u7C7B\u578B\u663E\u793A\u503C_json",
                    __key: "_system_type_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._system_type_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._system_type_json"
                  },
                  "__root.result.data._system_type_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._system_type_json"
                  },
                  "__root.result.data.model_url": {
                    title: "\u6A21\u677F\u5B9E\u9645\u8DEF\u5F84",
                    __key: "model_url",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.model_file_name": {
                    title: "\u6A21\u677F",
                    __key: "model_file_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.model_status": {
                    title: "\u6A21\u677F\u72B6\u6001",
                    __key: "model_status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._model_status_json": {
                    title: "\u6A21\u677F\u72B6\u6001\u663E\u793A\u503C_json",
                    __key: "_model_status_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._model_status_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._model_status_json"
                  },
                  "__root.result.data._model_status_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._model_status_json"
                  },
                  "__root.result.data.business_type": {
                    title: "\u4E1A\u52A1\u7C7B\u578B",
                    __key: "business_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._business_type_json": {
                    title: "\u4E1A\u52A1\u7C7B\u578B\u663E\u793A\u503C_json",
                    __key: "_business_type_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._business_type_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._business_type_json"
                  },
                  "__root.result.data._business_type_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._business_type_json"
                  },
                  "__root.result.data.model_name": {
                    title: "\u6A21\u677F\u540D\u79F0",
                    __key: "model_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._system_typename": {
                    title: "system_type\u663E\u793A\u503C",
                    __key: "_system_typename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._business_typename": {
                    title: "business_type\u663E\u793A\u503C",
                    __key: "_business_typename",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._model_statusname": {
                    title: "model_status\u663E\u793A\u503C",
                    __key: "_model_statusname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {
                  json: {
                    title: "\u9644\u4EF6\u5185\u5BB9json"
                  },
                  system_type: {
                    title: "\u7CFB\u7EDF\u7C7B\u578B"
                  },
                  model_url: {
                    title: "\u6A21\u677F\u5B9E\u9645\u8DEF\u5F84"
                  },
                  model_file_name: {
                    title: "\u6A21\u677F"
                  },
                  model_status: {
                    title: "\u6A21\u677F\u72B6\u6001"
                  },
                  business_type: {
                    title: "\u4E1A\u52A1\u7C7B\u578B"
                  },
                  model_name: {
                    title: "\u6A21\u677F\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  _system_typename: {
                    title: "system_type\u663E\u793A\u503C"
                  },
                  _business_typename: {
                    title: "business_type\u663E\u793A\u503C"
                  },
                  _model_statusname: {
                    title: "model_status\u663E\u793A\u503C"
                  }
                }
              },
              "1551381265012371456_del_1658713162209": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E\u96C6\u5408",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {},
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              title: "\u6A21\u677F\u7BA1\u7406"
            },
            UuGuuyQd: {
              varMap: {
                current: { type: "number" },
                pageSize: { type: "number" },
                total: { type: "number" },
                searchRange: { type: "object" },
                currentRow: { type: "object" },
                currentRowKey: { type: "string" },
                selectedRows: { type: "objectArray" },
                selectedRowKeys: { type: "stringArray" },
                lastSelectedRow: { type: "object" },
                lastSelectedRowKey: { type: "string" },
                dataSource: { type: "objectArray" },
                pagination: { type: "object" },
                rowClicked: { type: "boolean" },
                usedSortFields: { type: "array" }
              },
              widgetRef: "NormalTable",
              eventAttr: [
                "onInitialized",
                "onQuery",
                "onRowSelect",
                "onRowDbClick",
                "onRowClick",
                "onSelectAllRowClick"
              ],
              group: "listDisplay",
              reloadEvents: ["onQuery"],
              normalTablePlus: true,
              id: "UuGuuyQd",
              title: "",
              titleAlign: "left",
              showHeader: true,
              pagination: { pageSize: 10, current: 1 },
              showOrderColumn: false,
              wordWrap: false,
              rowSelection: { type: "radio", checkedStyle: "activeRow" },
              queryType: { typical: { queryStyle: "asForm", columnNum: 3 } },
              visible: true,
              showTitleEffective: true,
              style: { height: "100%" },
              headerBtns: [{ title: "\u65B0\u589E", btnType: "create" }],
              headerBtnsConfig: [{ title: "\u65B0\u589E", widgetId: "xDecdUuw" }],
              inlineBtnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "NCVHKLJN",
                  show: "visible",
                  type: "detail",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "IvBzniLk",
                  show: "visible",
                  type: "update",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "qqsbQdeq",
                  show: "visible",
                  type: "delete",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u52A8\u6001\u6807\u7B7E",
                  amIFold: false,
                  widgetId: "hvzQzFEt",
                  show: "visible",
                  type: "custom_tImEsPqA",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u8BBE\u7F6E",
                  widgetId: "KgiHfAhD",
                  show: "visible",
                  type: "custom_lTYoYnSm",
                  groupId: "KbilqoKT"
                }
              ],
              widgetCode: "NormalTable$1",
              searchColumns: [],
              columns: [
                {
                  dataIndex: "model_name",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  title: "\u6A21\u677F\u540D\u79F0",
                  widgetId: "nIKRpghL",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "system_type",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  title: "\u6A21\u677F\u7C7B\u578B",
                  widgetId: "nNEUpowD",
                  widgetRef: "DropdownSelector",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "model_status",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "showVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  title: "\u6A21\u677F\u72B6\u6001",
                  widgetId: "wXIyLkQk",
                  widgetRef: "DropdownSelector",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "json",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  title: "\u9644\u4EF6\u5185\u5BB9json",
                  widgetId: "LFwDsHGm",
                  widgetRef: "FormInput",
                  renderType: "defaultRender",
                  configShow: true
                },
                {
                  dataIndex: "model_url",
                  width: "150px",
                  align: "left",
                  editable: false,
                  fieldShowType: "realVal",
                  show: true,
                  sortEditable: true,
                  editType: "0",
                  showSortBtn: true,
                  widgetId: "jaJdxVLE",
                  widgetRef: "FormInput",
                  title: "\u6A21\u677F\u5B9E\u9645\u8DEF\u5F84",
                  renderType: "defaultRender",
                  configShow: true
                }
              ],
              sortInfo: [
                { fieldID: "create_time", title: "\u521B\u5EFA\u65F6\u95F4", sort: "desc" }
              ],
              tagKey: "",
              keyshow: false,
              ds: "1551381265012371456_list_1658713163772",
              rowKey: "id",
              socket: null,
              tableSortFieldList: [
                "json",
                "system_type",
                "model_url",
                "model_file_name",
                "model_status",
                "business_type",
                "model_name",
                "create_user_id",
                "last_update_time",
                "sequence",
                "create_time",
                "create_user_name",
                "id",
                "last_update_user_id",
                "last_update_user_name",
                "_system_typename",
                "_business_typename",
                "_model_statusname"
              ]
            },
            GLydfVnk: {
              varMap: {},
              widgetRef: "GridLayoutSearch",
              deleteable: false,
              isContainer: true,
              id: "GLydfVnk",
              title: "\u641C\u7D22\u533A\u57DF",
              colCounts: 4,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              alignType: "aligned",
              style: {
                width: "100%",
                border: "0px",
                padding: "8px 8px 8px 8px",
                borderBottomColor: "#e2e8f0",
                borderBottomWidth: "1px"
              },
              widgetCode: "GridLayoutSearch$1",
              colsPackUp: false,
              colsKeys: [],
              bodyInfo: []
            },
            LQUBxbWK: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "LQUBxbWK",
              visible: true,
              customId: "UuGuuyQd_headerBtns",
              btnsConfig: [{ title: "\u65B0\u589E", widgetId: "xDecdUuw" }],
              title: "\u8868\u5934\u6309\u94AE\u533A\u57DF",
              style: { padding: "4px 15px 4px 15px" },
              size: "middle"
            },
            xDecdUuw: {
              title: "\u65B0\u589E",
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "xDecdUuw",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px", marginLeft: "7px" },
              size: "middle",
              type: "primary"
            },
            KbilqoKT: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "KbilqoKT",
              visible: true,
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              customId: "UuGuuyQd_inlineBtns",
              btnsConfig: [
                {
                  title: "\u67E5\u770B",
                  widgetId: "NCVHKLJN",
                  show: "visible",
                  type: "detail",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u4FEE\u6539",
                  widgetId: "IvBzniLk",
                  show: "visible",
                  type: "update",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u5220\u9664",
                  widgetId: "qqsbQdeq",
                  show: "visible",
                  type: "delete",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u52A8\u6001\u6807\u7B7E",
                  amIFold: false,
                  widgetId: "hvzQzFEt",
                  show: "visible",
                  type: "custom_tImEsPqA",
                  groupId: "KbilqoKT"
                },
                {
                  title: "\u8BBE\u7F6E",
                  widgetId: "KgiHfAhD",
                  show: "visible",
                  type: "custom_lTYoYnSm",
                  groupId: "KbilqoKT"
                }
              ],
              style: { padding: "4px 15px 4px 15px" },
              size: "small"
            },
            NCVHKLJN: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "NCVHKLJN",
              title: "\u67E5\u770B",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            IvBzniLk: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "IvBzniLk",
              title: "\u4FEE\u6539",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            qqsbQdeq: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "qqsbQdeq",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              $lazyload: false,
              type: "link"
            },
            hvzQzFEt: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "hvzQzFEt",
              title: "\u52A8\u6001\u6807\u7B7E",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            KgiHfAhD: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "KgiHfAhD",
              title: "\u8BBE\u7F6E",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "2px 4px" },
              size: "small",
              widgetCode: "FormButton$1",
              eventTypesWithTags: [],
              $lazyload: false,
              type: "link"
            },
            nIKRpghL: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "nIKRpghL",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "model_name",
              fieldColumn: { field: "model_name", title: "model_name" },
              widgetCode: "FormInput$1",
              $lazyload: false,
              columnName: "model_name"
            },
            nNEUpowD: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "nNEUpowD",
              options: { 1: "\u9759\u6001\u6807\u7B7E(\u7CFB\u7EDF\u6807\u7B7E)", 2: "\u52A8\u6001\u6807\u7B7E" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1549276768903507968_1658211340788"
                }
              },
              dictMeta: {
                dictBusiCode: "1549276768903507968_1658211340788",
                type: "dict"
              },
              field: "system_type",
              fieldColumn: { field: "system_type", title: "system_type" },
              widgetCode: "DropdownSelector$1",
              $lazyload: false,
              bodyContainer: true,
              columnName: "system_type"
            },
            wXIyLkQk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "wXIyLkQk",
              options: { 1: "\u6B63\u5E38", 2: "\u505C\u7528", 3: "\u65E0\u6548" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              listHeight: "120",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1551384352997388288_1658713828043"
                }
              },
              dictMeta: {
                dictBusiCode: "1551384352997388288_1658713828043",
                type: "dict"
              },
              field: "model_status",
              fieldColumn: { field: "model_status", title: "model_status" },
              widgetCode: "DropdownSelector$1",
              $lazyload: false,
              bodyContainer: true,
              columnName: "model_status"
            },
            LFwDsHGm: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "LFwDsHGm",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "json",
              fieldColumn: { field: "json", title: "\u9644\u4EF6\u5185\u5BB9json" },
              widgetCode: "FormInput$1",
              fieldInfo: null,
              fieldSearch: null,
              $lazyload: false,
              columnName: "model_url"
            },
            jaJdxVLE: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "jaJdxVLE",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              field: "model_url",
              fieldColumn: { field: "model_url", title: "\u6A21\u677F\u5B9E\u9645\u8DEF\u5F84" },
              $lazyload: false,
              columnName: "model_url"
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: []
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            xDecdUuw: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "fzZtVdEq",
                                  pageNameCn: "\u65B0\u589E\u6A21\u677F",
                                  params: [{ var_pageInput_0_mode: "insert" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "xDecdUuw"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "fzZtVdEq",
                                  pageNameCn: "\u65B0\u589E\u6A21\u677F",
                                  params: [{ var_pageInput_0_mode: "insert" }],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "xDecdUuw"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            hvzQzFEt: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["currentRow", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1552167150083518464",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: "currentApp",
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "TsSCqXtE",
                                  pageNameCn: "\u52A8\u6001\u6807\u7B7E\u7BA1\u7406",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["currentRow", "id"]
                                        }
                                      )
                                    }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u52A8\u6001\u6807\u7B7E\u7BA1\u7406" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            KgiHfAhD: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRow", "id"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1552176626396180480",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: "currentApp",
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "oveSkxxI",
                                  pageNameCn: "\u6807\u4E66\u8BBE\u7F6E",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRow", "id"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u6807\u4E66\u5236\u4F5C" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            NCVHKLJN: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "SzihNNSu",
                                  pageNameCn: "\u67E5\u770B\u6A21\u677F",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "SzihNNSu",
                                  pageNameCn: "\u67E5\u770B\u6A21\u677F",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "detail" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            IvBzniLk: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "EudgxJzC",
                                  pageNameCn: "\u4FEE\u6539\u6A21\u677F",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "IvBzniLk"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDbClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                { selectRowCheckBool: true },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.openPage) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  url: "",
                                  openType: "openModal",
                                  link: "1551754962705461248",
                                  pageArea: "pageInApp",
                                  adsorbPosition: "undefined",
                                  adsorbOffset: void 0,
                                  appType: void 0,
                                  popupMode: void 0,
                                  isMask: void 0,
                                  closePopup: void 0,
                                  slidePlacement: "undefined",
                                  mini: void 0,
                                  fullscreen: void 0,
                                  Drag: void 0,
                                  extraprops: { width: "70vw", height: null },
                                  showCloseIcon: void 0,
                                  showTopBar: void 0,
                                  id: "EudgxJzC",
                                  pageNameCn: "\u4FEE\u6539\u6A21\u677F",
                                  params: [
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "UuGuuyQd",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["lastSelectedRowKey"]
                                        }
                                      )
                                    },
                                    { var_pageInput_0_mode: "update" }
                                  ],
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "IvBzniLk"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  onClosePageInCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  appCode: null
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u6A21\u677F\u7BA1\u7406\u8868\u5355" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            qqsbQdeq: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a, _b;
                const { eventParam } = pageCtx;
                (_a = eventParam == null ? void 0 : eventParam.event) == null ? void 0 : _a.stopPropagation();
                return yield (_b = platform_action_default) == null ? void 0 : _b.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "UuGuuyQd",
                                      path: ["lastSelectedRowKey"]
                                    }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  selectRowCheckBool: true,
                                  askText: "\u786E\u5B9A\u5220\u9664\uFF1F"
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b2;
                              return yield (_b2 = (_a2 = platform_action_default) == null ? void 0 : _a2.deleteDataByAPI) == null ? void 0 : _b2.call(
                                _a2,
                                {
                                  api: "1551381265012371456_del_1658713162209",
                                  successCallback: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: [
                                              {
                                                action: () => __async(this, null, function* () {
                                                  var _a4, _b3;
                                                  return yield (_b3 = (_a4 = platform_action_default) == null ? void 0 : _a4.pageDataReload) == null ? void 0 : _b3.call(
                                                    _a4,
                                                    {
                                                      sourceWidgetId: "qqsbQdeq"
                                                    },
                                                    pageCtx
                                                  );
                                                })
                                              }
                                            ]
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  deleteDataWidgetId: "UuGuuyQd",
                                  input: [
                                    {
                                      "__root.id": [
                                        pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                          {
                                            id: "UuGuuyQd",
                                            fromPaths: pageCtx.fromPaths,
                                            propPath: ["lastSelectedRowKey"]
                                          }
                                        )
                                      ]
                                    }
                                  ],
                                  apiTip: void 0
                                },
                                pageCtx
                              );
                            }),
                            log: { objectBehavior: "\u5220\u9664[\u6A21\u677F\u7BA1\u7406\u8868]\u8868\u4FE1\u606F" }
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "UuGuuyQd",
                  children: [
                    { id: "GLydfVnk", children: [] },
                    {
                      id: "UuGuuyQd_headerBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "LQUBxbWK",
                          parentToChild: "1:1",
                          type: "node",
                          children: [
                            {
                              id: "xDecdUuw",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "UuGuuyQd_inlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "KbilqoKT",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "NCVHKLJN",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "IvBzniLk",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "qqsbQdeq",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "hvzQzFEt",
                              parentToChild: "1:1",
                              type: "node"
                            },
                            {
                              id: "KgiHfAhD",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "UuGuuyQd_columns",
                      type: "renderProp",
                      children: [
                        {
                          id: "nIKRpghL",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "nNEUpowD",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "wXIyLkQk",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "LFwDsHGm",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "jaJdxVLE",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {},
          // 表达式初始化信息
          monitor: { widget: {} },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$UuGuuyQd`,
            key: `PC$$UuGuuyQd`,
            pageCtx,
            widgetRef: "NormalTable",
            headerBtnsRenderer: () => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$LQUBxbWK`,
                  key: `PC$$UuGuuyQd$$LQUBxbWK`,
                  pageCtx,
                  widgetRef: "FormButtonGroup"
                },
                /* @__PURE__ */ react_default.createElement(
                  COMPCONTROL.CompEntry,
                  {
                    path: `PC$$UuGuuyQd$$LQUBxbWK$$xDecdUuw`,
                    key: `PC$$UuGuuyQd$$LQUBxbWK$$xDecdUuw`,
                    pageCtx,
                    widgetRef: "FormButton"
                  }
                )
              )
            ],
            inlineBtnsRenderer: ({ index: indexFromUuGuuyQd, record }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT`,
                key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$NCVHKLJN`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$NCVHKLJN`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$IvBzniLk`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$IvBzniLk`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$qqsbQdeq`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$qqsbQdeq`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$hvzQzFEt`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$hvzQzFEt`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$KgiHfAhD`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$KbilqoKT$$KgiHfAhD`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            columnsRenderer: ({ index: indexFromUuGuuyQd }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$nIKRpghL`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$nIKRpghL`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$nNEUpowD`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$nNEUpowD`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$wXIyLkQk`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$wXIyLkQk`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$LFwDsHGm`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$LFwDsHGm`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$jaJdxVLE`,
                  key: `PC$$UuGuuyQd$$%${indexFromUuGuuyQd}%$$jaJdxVLE`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              )
            ]
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$UuGuuyQd$$GLydfVnk`,
              key: `PC$$UuGuuyQd$$GLydfVnk`,
              pageCtx,
              widgetRef: "GridLayoutSearch"
            }
          )
        )
      );
    }
  };
  __publicField(Page1551754708077654016, "pageName", "\u6A21\u677F\u7BA1\u7406");
  __publicField(Page1551754708077654016, "$pageKey", "TAfzmZBL");
  __publicField(Page1551754708077654016, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
