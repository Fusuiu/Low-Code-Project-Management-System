var Page1564919086897573888 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1564919086897573888: () => Page1564919086897573888
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1564919086897573888 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1564919086897573888",
            pageName: "\u52A8\u6001\u5B57\u6BB5\u6761\u4EF6\u663E\u793A",
            apiMeta: {
              bis_api_1662035073920: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "JSON\u5B57\u6BB5\u6761\u4EF6",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.table_id": {
                    title: "\u6240\u5C5E\u8868\u4E3B\u952E",
                    __key: "table_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u6761\u4EF6\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.conditionMeta": {
                    title: "JSON\u6761\u4EF6",
                    __key: "conditionMeta",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root.result"
                  },
                  "__root.result.conditionMeta.express": {
                    title: "\u6761\u4EF6\u8868\u8FBE\u5F0F",
                    __key: "express",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta"
                  },
                  "__root.result.conditionMeta.columns": {
                    title: "\u8FC7\u6EE4\u6761\u4EF6",
                    __key: "columns",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.conditionMeta"
                  },
                  "__root.result.conditionMeta.columns.columnCode": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "columnCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.condition": {
                    title: "\u6761\u4EF6",
                    __key: "condition",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.showValue": {
                    title: "\u5C55\u793A\u503C",
                    __key: "showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.tableCode": {
                    title: "\u8868\u7F16\u53F7",
                    __key: "tableCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.value": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.valueType": {
                    title: "\u503C\u7C7B\u578B",
                    __key: "valueType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.dataType": {
                    title: "\u5B57\u6BB5\u6570\u636E\u7C7B\u578B",
                    __key: "dataType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.conditionMeta.columns.dictTableId": {
                    title: "\u5B57\u5178\u8868\u4E3B\u952E",
                    __key: "dictTableId",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.conditionMeta.columns"
                  },
                  "__root.result.selectShowField": {
                    title: "\u9009\u62E9\u663E\u793A\u5B57\u6BB5",
                    __key: "selectShowField",
                    _remoteType: void 0,
                    _type: "numberArray",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u4E3B\u952E",
                    __key: "json_clips_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {}
              },
              bis_api_1565156327095939073: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.id": {
                    title: "\u5B57\u6BB5\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.fieldCode": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "fieldCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.fieldName": {
                    title: "\u5B57\u6BB5\u540D\u79F0",
                    __key: "fieldName",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.tableCode": {
                    title: "\u8868\u7F16\u53F7",
                    __key: "tableCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.tableType": {
                    title: "\u8868\u7C7B\u578B",
                    __key: "tableType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.table_id": {
                    title: "\u8868\u4E3B\u952E",
                    __key: "table_id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  }
                },
                cond: {
                  code: {
                    title: "\u5B57\u6BB5\u7F16\u53F7"
                  },
                  name: {
                    title: "\u5B57\u6BB5\u540D\u79F0"
                  }
                }
              },
              "1526530979349540864_list_1652789031354": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.is_search": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2",
                    __key: "is_search",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_search_json": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C_json",
                    __key: "_is_search_json",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_search_json._saveValue": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "_saveValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_search_json"
                  },
                  "__root.result.data._is_search_json._showValue": {
                    title: "\u663E\u793A\u503C",
                    __key: "_showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data._is_search_json"
                  },
                  "__root.result.data.field_type_name": {
                    title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0",
                    __key: "field_type_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_system_name": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5\u540D\u79F0",
                    __key: "is_system_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_system": {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5",
                    __key: "is_system",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u8868Id",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_code": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "field_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_unique": {
                    title: "\u662F\u5426\u552F\u4E00",
                    __key: "is_unique",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_edit": {
                    title: "\u662F\u5426\u53EF\u7F16\u8F91",
                    __key: "is_edit",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_show": {
                    title: "\u662F\u5426\u663E\u793A",
                    __key: "is_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_name": {
                    title: "\u5B57\u6BB5\u540D\u79F0",
                    __key: "field_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.sequence": {
                    title: "\u6392\u5E8F\u5E8F\u53F7",
                    __key: "sequence",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_form_show": {
                    title: "\u662F\u5426\u8868\u5355\u663E\u793A",
                    __key: "is_form_show",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.is_required": {
                    title: "\u662F\u5426\u5FC5\u586B",
                    __key: "is_required",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_remark": {
                    title: "\u5B57\u6BB5\u5907\u6CE8",
                    __key: "field_remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.check_box_type": {
                    title: "\u9009\u9879\u6846\u7C7B\u578B",
                    __key: "check_box_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.field_type": {
                    title: "\u5B57\u6BB5\u7C7B\u578B",
                    __key: "field_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data._is_searchname": {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C",
                    __key: "_is_searchname",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {
                  is_search: {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2"
                  },
                  field_type_name: {
                    title: "\u5B57\u6BB5\u7C7B\u578B\u540D\u79F0"
                  },
                  is_system_name: {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5\u540D\u79F0"
                  },
                  create_user_id: {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E"
                  },
                  is_system: {
                    title: "\u662F\u5426\u7CFB\u7EDF\u5B57\u6BB5"
                  },
                  json_clips_id: {
                    title: "JSON\u7247\u6BB5\u8868Id"
                  },
                  create_time: {
                    title: "\u521B\u5EFA\u65F6\u95F4"
                  },
                  create_user_name: {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0"
                  },
                  field_code: {
                    title: "\u5B57\u6BB5\u7F16\u53F7"
                  },
                  is_unique: {
                    title: "\u662F\u5426\u552F\u4E00"
                  },
                  is_edit: {
                    title: "\u662F\u5426\u53EF\u7F16\u8F91"
                  },
                  last_update_user_id: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E"
                  },
                  is_show: {
                    title: "\u662F\u5426\u663E\u793A"
                  },
                  field_name: {
                    title: "\u5B57\u6BB5\u540D\u79F0"
                  },
                  last_update_time: {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4"
                  },
                  sequence: {
                    title: "\u6392\u5E8F\u5E8F\u53F7"
                  },
                  is_form_show: {
                    title: "\u662F\u5426\u8868\u5355\u663E\u793A"
                  },
                  is_required: {
                    title: "\u662F\u5426\u5FC5\u586B"
                  },
                  field_remark: {
                    title: "\u5B57\u6BB5\u5907\u6CE8"
                  },
                  check_box_type: {
                    title: "\u9009\u9879\u6846\u7C7B\u578B"
                  },
                  id: {
                    title: "\u4E3B\u952E"
                  },
                  field_type: {
                    title: "\u5B57\u6BB5\u7C7B\u578B"
                  },
                  last_update_user_name: {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0"
                  },
                  _is_searchname: {
                    title: "\u662F\u5426\u652F\u6301\u67E5\u8BE2\u663E\u793A\u503C"
                  }
                }
              },
              bis_api_1662122786519: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.": {
                    title: void 0,
                    __key: "",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u4E3B\u952E",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.conditionMeta": {
                    title: "JSON\u6761\u4EF6",
                    __key: "conditionMeta",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.conditionMeta.express": {
                    title: "\u6761\u4EF6\u8868\u8FBE\u5F0F",
                    __key: "express",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta"
                  },
                  "__root.conditionMeta.columns": {
                    title: "\u8FC7\u6EE4\u6761\u4EF6",
                    __key: "columns",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.conditionMeta"
                  },
                  "__root.conditionMeta.columns.arrayValueCondition": {
                    title: "\u6761\u4EF6\u503C\u662F\u5426\u662F\u6570\u7EC4",
                    __key: "arrayValueCondition",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.columnCode": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "columnCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.condition": {
                    title: "\u6761\u4EF6",
                    __key: "condition",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.showValue": {
                    title: "\u5C55\u793A\u503C",
                    __key: "showValue",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.tableCode": {
                    title: "\u8868\u7F16\u53F7",
                    __key: "tableCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.value": {
                    title: "\u5B9E\u9645\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.conditionMeta.columns.valueType": {
                    title: "\u503C\u7C7B\u578B",
                    __key: "valueType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.conditionMeta.columns"
                  },
                  "__root.selectShowField": {
                    title: "\u9009\u62E9\u663E\u793A\u5B57\u6BB5",
                    __key: "selectShowField",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root"
                  },
                  "__root.conditionId": {
                    title: "JSON\u6761\u4EF6\u4E3B\u952E",
                    __key: "conditionId",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1662123180580: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.": {
                    title: void 0,
                    __key: "",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.json_clips_id": {
                    title: "JSON\u7247\u6BB5\u4E3B\u952E",
                    __key: "json_clips_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.conditionId": {
                    title: "JSON\u6761\u4EF6\u4E3B\u952E",
                    __key: "conditionId",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              },
              bis_api_1669610726047756289: {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.dataType": {
                    title: "\u5B57\u6BB5\u6570\u636E\u7C7B\u578B",
                    __key: "dataType",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.refTableId": {
                    title: "\u5B57\u6BB5\u5173\u8054\u8868\u4E3B\u952E",
                    __key: "refTableId",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.fieldCode": {
                    title: "\u5B57\u6BB5\u7F16\u53F7",
                    __key: "fieldCode",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root.tableId": {
                    title: "\u8868\u4E3B\u952E",
                    __key: "tableId",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              showBottomBar: true,
              style: { backgroundColor: "transparent" },
              title: "\u52A8\u6001\u5B57\u6BB5\u6761\u4EF6\u663E\u793A",
              sockets: null,
              dss: ["bis_api_1662035073920"],
              requests: {
                bis_api_1662035073920: [
                  {
                    field: "json_clips_id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              },
              activeToken: false
            },
            kCIeoINc: {
              varMap: {
                dataVal: { type: "array" },
                actualVal: { type: "array" },
                colsVal: { type: "array" },
                displayVal: { type: "array" },
                curRow: { type: "object" },
                checkedRows: { type: "array" }
              },
              widgetRef: "SubformContainer",
              eventAttr: [
                "onRowAdd",
                "onRowDel",
                "onRowCopy",
                "onRowCopyEnd",
                "onRowInsertEnd",
                "onRowBatchDel",
                "onRowSort"
              ],
              isContainer: true,
              parseInReadOnly: true,
              acceptChildStrategy: {
                strategy: "blackList",
                addSelf: false,
                blackList: ["NormalTable", "FormButton", "FormDivider"]
              },
              id: "kCIeoINc",
              title: "\u8FC7\u6EE4\u6761\u4EF6",
              titleAlign: "left",
              visible: true,
              showTitleEffective: true,
              rowDirection: "horizonal",
              style: { height: "auto", padding: "0px 0px 8px 0px" },
              readOnly: false,
              widgetCode: "SubformContainer$1",
              field: "columns",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns"
              },
              fieldSearch: null,
              fieldColumn: null,
              type: "object",
              __key: "columns",
              _type: "objectArray",
              __parent: "__root.result.conditionMeta",
              key: "conditionMeta.columns",
              children: [
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u5B57\u6BB5\u7F16\u53F7",
                  __key: "columnCode",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.columnCode",
                  children: []
                },
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u6761\u4EF6",
                  __key: "condition",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.condition",
                  children: []
                },
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u5C55\u793A\u503C",
                  __key: "showValue",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.showValue",
                  children: []
                },
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u8868\u7F16\u53F7",
                  __key: "tableCode",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.tableCode",
                  children: []
                },
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u5B9E\u9645\u503C",
                  __key: "value",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.value",
                  children: []
                },
                {
                  _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
                  type: "string",
                  _type: "string",
                  title: "\u503C\u7C7B\u578B",
                  __key: "valueType",
                  __parent: "__root.result.conditionMeta.columns",
                  key: "conditionMeta.columns.valueType",
                  children: []
                }
              ],
              inlineBtnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "DfVTRtZZ",
                  btnType: "delete",
                  groupId: "mfDuvzNG"
                }
              ],
              rowBtn: [],
              btnsGroups: [
                { title: "\u66F4\u591A", id: "mfDuvzNG", type: "headerBtns" },
                { title: "\u66F4\u591A", id: "BWgXdqQa", type: "inlineBtns" }
              ],
              bodyHeaders: [
                {
                  title: "\u5B57\u6BB5\u540D\u79F0",
                  id: "MwvvMlsc",
                  titleAlign: "left",
                  field: "columnCode"
                },
                {
                  title: "\u5B57\u6BB5\u6570\u636E\u7C7B\u578B",
                  id: "cBdQAEVV",
                  titleAlign: "left",
                  field: "dataType"
                },
                {
                  title: "\u5B57\u5178\u8868\u4E3B\u952E",
                  id: "kwcQnRJG",
                  titleAlign: "left",
                  field: "dictTableId"
                },
                {
                  title: "\u6761\u4EF6",
                  id: "sfKNFlLb",
                  titleAlign: "left",
                  field: "condition"
                },
                {
                  title: "\u503C\u7C7B\u578B",
                  id: "qiMdPNGi",
                  titleAlign: "left",
                  field: "valueType"
                },
                {
                  title: "\u5B9E\u9645\u503C",
                  id: "vGkjqrKz",
                  titleAlign: "left",
                  field: "value"
                },
                {
                  title: "\u8868\u7F16\u53F7",
                  id: "tYoxamuL",
                  titleAlign: "left",
                  field: "tableCode"
                },
                {
                  title: "\u5C55\u793A\u503C",
                  id: "ALrmlojf",
                  titleAlign: "left",
                  field: "showValue"
                },
                { title: "\u503C", id: "YLaFwqht", titleAlign: "left" }
              ],
              childMap: {
                MwvvMlsc: { id: "MwvvMlsc" },
                cBdQAEVV: { id: "cBdQAEVV" },
                kwcQnRJG: { id: "kwcQnRJG" },
                sfKNFlLb: { id: "sfKNFlLb" },
                qiMdPNGi: { id: "qiMdPNGi" },
                vGkjqrKz: { id: "vGkjqrKz" },
                tYoxamuL: { id: "tYoxamuL" },
                ALrmlojf: { id: "ALrmlojf" },
                YLaFwqht: { id: "YLaFwqht" }
              },
              bodyFields: {
                MwvvMlsc: "columnCode",
                cBdQAEVV: "dataType",
                kwcQnRJG: "dictTableId",
                sfKNFlLb: "condition",
                qiMdPNGi: "valueType",
                vGkjqrKz: "value",
                tYoxamuL: "tableCode",
                ALrmlojf: "showValue"
              },
              bodyPaths: {
                columnCode: ["MwvvMlsc"],
                dataType: ["cBdQAEVV"],
                dictTableId: ["kwcQnRJG"],
                condition: ["sfKNFlLb"],
                valueType: ["qiMdPNGi"],
                value: ["vGkjqrKz"],
                tableCode: ["tYoxamuL"],
                showValue: ["ALrmlojf"]
              },
              visibleCols: [
                true,
                false,
                false,
                true,
                true,
                false,
                false,
                false,
                true
              ]
            },
            MwvvMlsc: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "MwvvMlsc",
              title: "\u5B57\u6BB5\u540D\u79F0",
              options: { 0: "\u9009\u98790" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$1",
              propOptions: {
                type: "api",
                apiOptsConfig: {
                  apiMetaId: "bis_api_1565156327095939073",
                  realValKey: "fieldCode",
                  showValKey: "fieldName",
                  rangeConditions: {
                    conditions: [],
                    formula: "",
                    nextVarAlias: 1
                  },
                  sortInfo: []
                }
              },
              customParams: [{ field: "__root.table_id" }],
              autoComplete: {
                queryFields: ["fieldCode", "fieldName"],
                listShowFields: [],
                splitMark: ",",
                customSplitMark: ""
              },
              field: "columnCode",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.columnCode"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "columnCode",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.columnCode",
              children: [],
              linkage: null,
              eventTypesWithTags: [],
              _props: { title: "\u5B57\u6BB5\u540D\u79F0" }
            },
            cBdQAEVV: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "cBdQAEVV",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u5B57\u6BB5\u6570\u636E\u7C7B\u578B",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              widgetCode: "FormInput$15",
              field: "dataType",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.dataType"
              },
              readOnly: false,
              eventTypesWithTags: [],
              fieldSearch: null,
              fieldColumn: null,
              treeNodePath: [0, 0, 1],
              _props: { title: "\u5B57\u6BB5\u6570\u636E\u7C7B\u578B" }
            },
            kwcQnRJG: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "kwcQnRJG",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u5B57\u5178\u8868\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$16",
              field: "dictTableId",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.dictTableId"
              },
              fieldSearch: null,
              fieldColumn: null,
              _props: { title: "\u5B57\u5178\u8868\u4E3B\u952E" }
            },
            sfKNFlLb: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "sfKNFlLb",
              title: "\u6761\u4EF6",
              options: {
                equ: "\u7B49\u4E8E",
                notEqu: "\u4E0D\u7B49\u4E8E",
                greater: "\u5927\u4E8E",
                greaterEqu: "\u5927\u4E8E\u7B49\u4E8E",
                less: "\u5C0F\u4E8E",
                lessEqu: "\u5C0F\u4E8E\u7B49\u4E8E",
                like: "\u5305\u542B",
                notLike: "\u4E0D\u5305\u542B",
                startWith: "\u5F00\u5934\u662F",
                startNotWith: "\u5F00\u5934\u4E0D\u662F",
                endWith: "\u7ED3\u5C3E\u4E0D\u662F",
                empty: "\u4E3A\u7A7A",
                notEmpty: "\u4E0D\u4E3A\u7A7A",
                notIn: "\u4E0D\u5C5E\u4E8E",
                in: "\u5C5E\u4E8E"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$2",
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1565171338971328512_1662000901758"
                }
              },
              dictMeta: {
                dictBusiCode: "1565171338971328512_1662000901758",
                type: "dict"
              },
              autoComplete: {
                queryFields: ["name"],
                listShowFields: [],
                splitMark: ",",
                customSplitMark: ""
              },
              field: "condition",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.condition"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "condition",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.condition",
              children: [],
              linkage: null,
              _props: { title: "\u6761\u4EF6" }
            },
            qiMdPNGi: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "qiMdPNGi",
              title: "\u503C\u7C7B\u578B",
              options: { constant: "\u5E38\u91CF" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$3",
              propOptions: {
                type: "custom",
                optionsConfig: [{ showVal: "\u5E38\u91CF", realVal: "constant" }]
              },
              defRealVal: "constant",
              linkage: null,
              field: "valueType",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.valueType"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "valueType",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.valueType",
              children: [],
              _props: { title: "\u503C\u7C7B\u578B" }
            },
            vGkjqrKz: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "vGkjqrKz",
              title: "\u5B9E\u9645\u503C",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              readOnly: false,
              widgetCode: "DropdownSelector$4",
              field: "value",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.value"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "value",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.value",
              children: [],
              eventTypesWithTags: [],
              linkage: null,
              _props: { title: "\u5B9E\u9645\u503C" }
            },
            tYoxamuL: {
              style: {},
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "tYoxamuL",
              title: "\u8868\u7F16\u53F7",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$5",
              field: "tableCode",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.tableCode"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "tableCode",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.tableCode",
              children: [],
              linkage: null,
              _props: { title: "\u8868\u7F16\u53F7" }
            },
            ALrmlojf: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "ALrmlojf",
              title: "\u5C55\u793A\u503C",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$6",
              field: "showValue",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.columns.showValue"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "showValue",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.showValue",
              children: [],
              linkage: null,
              _props: { title: "\u5C55\u793A\u503C" }
            },
            YLaFwqht: {
              style: { padding: "0px 0px 0px 0px" },
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "YLaFwqht",
              title: "\u503C",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$20",
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "value",
              __parent: "__root.result.conditionMeta.columns",
              key: "conditionMeta.columns.value",
              children: [],
              eventTypesWithTags: [],
              linkage: null,
              _props: { title: "\u503C" }
            },
            BWgXdqQa: {
              varMap: {},
              widgetRef: "FormButtonGroup",
              eventAttr: [],
              id: "BWgXdqQa",
              title: "\u884C\u5185\u6309\u94AE\u533A\u57DF",
              visible: true,
              customId: "kCIeoINc_subFormInlineBtns",
              btnsConfig: [
                {
                  title: "\u5220\u9664",
                  amIFold: false,
                  widgetId: "DfVTRtZZ",
                  btnType: "delete",
                  groupId: "mfDuvzNG"
                }
              ]
            },
            DfVTRtZZ: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "DfVTRtZZ",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: {
                padding: "0px 4px 0px 4px",
                cursor: "pointer",
                borderRadius: "6px",
                height: "28px",
                lineHeight: "28px",
                fontSize: "12px",
                color: "#096dd9"
              },
              size: "middle",
              $lazyload: false,
              type: "link",
              groupBtnId: "mfDuvzNG"
            },
            sIISQzau: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "sIISQzau",
              title: "\u6761\u4EF6\u8868\u8FBE\u5F0F",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$3",
              placeholder: "\u914D\u7F6E\u6761\u4EF6\u516C\u5F0F\uFF08\u4E0D\u540C\u5B57\u6BB5\u9ED8\u8BA4\u4E3A\u201Cand\u201D\uFF0C\u76F8\u540C\u5B57\u6BB5\u9ED8\u8BA4\u4E3A\u201Cor\u201D\uFF09",
              note: "\u914D\u7F6E\u6761\u4EF6\u516C\u5F0F\uFF08\u4E0D\u540C\u5B57\u6BB5\u9ED8\u8BA4\u4E3A\u201Cand\u201D\uFF0C\u76F8\u540C\u5B57\u6BB5\u9ED8\u8BA4\u4E3A\u201Cor\u201D\uFF09",
              field: "express",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.conditionMeta.express"
              },
              fieldSearch: null,
              fieldColumn: null,
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              type: "string",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "express",
              __parent: "__root.result.conditionMeta",
              key: "conditionMeta.express",
              children: []
            },
            GajUDSNO: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "GajUDSNO",
              title: "\u9009\u62E9\u663E\u793A\u5B57\u6BB52",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$4",
              linkage: null,
              field: "selectShowField",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.selectShowField"
              },
              fieldSearch: null,
              fieldColumn: null,
              _decimalSize: 0,
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              type: "array",
              items: { _type: "NUMBER", type: "number", title: "\u9009\u62E9\u663E\u793A\u5B57\u6BB5" },
              _type: "numberArray",
              multipleOf: null,
              minimum: null,
              maximum: null,
              exclusiveMaximum: null,
              exclusiveMinimum: null,
              __parent: "__root.result",
              __key: "selectShowField",
              key: "selectShowField",
              children: [],
              stringLength: 3e3
            },
            aooWtato: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "aooWtato",
              contentAlign: "right",
              style: { padding: "16px 0px 0px 0px" },
              widgetCode: "FloatBar$1"
            },
            raWWgWWr: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "raWWgWWr",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              widgetCode: "FormButton$1",
              eventTypesWithTags: []
            },
            tgirWemt: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "tgirWemt",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              eventTypesWithTags: [],
              widgetCode: "FormButton$2"
            },
            emgKBeVV: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "emgKBeVV",
              title: "\u5220\u9664",
              visible: true,
              disabled: false,
              iconType: "",
              style: { padding: "4px 15px 4px 15px" },
              widgetCode: "FormButton$3",
              eventTypesWithTags: []
            },
            hleRdMaP: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              reloadEvents: ["getOptions"],
              id: "hleRdMaP",
              title: "\u9009\u62E9\u663E\u793A\u5B57\u6BB5",
              options: { 0: "\u9009\u98790" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$5",
              propOptions: {
                type: "api",
                apiOptsConfig: {
                  apiMetaId: "1526530979349540864_list_1652789031354",
                  realValKey: "id",
                  showValKey: "field_name",
                  sortInfo: []
                }
              },
              conditions: [
                {
                  varAlias: 1,
                  field: "json_clips_id",
                  paramAmount: 1,
                  method: "equ"
                }
              ],
              formula: "1",
              autoComplete: {
                queryFields: ["field_code", "field_name"],
                listShowFields: [],
                splitMark: ",",
                customSplitMark: ""
              },
              mode: "multi",
              field: null,
              fieldInfo: null,
              fieldSearch: null,
              fieldColumn: null,
              type: "string",
              __key: "dynamic_field_id",
              _type: "string",
              __parent: "__root.result.selectShowField",
              key: "selectShowField.dynamic_field_id",
              children: [],
              _dateEngineFieldType: "INT",
              _fieldSize: 20,
              _species: "SYS",
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              _dateEngineFieldDataType: "NORMAL",
              _decimalSize: 0,
              _remoteType: "string_number",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              linkage: null
            },
            VMZXgHHM: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "VMZXgHHM",
              title: "\u6240\u5C5E\u8868\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              stringLength: 20,
              widgetCode: "FormInput$2",
              field: "table_id",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.data.table_id"
              },
              readOnly: false,
              fieldSearch: null,
              fieldColumn: null,
              _dateEngineFieldType: "INT",
              _fieldSize: 20,
              _species: "SYS",
              _errorValidMsgRule: ["\u5B57\u7B26\u4E32"],
              _dateEngineFieldDataType: "NORMAL",
              _decimalSize: 0,
              type: "string",
              _remoteType: "string_number",
              _type: "string",
              minLength: null,
              maxLength: null,
              pattern: null,
              patternErrorMsg: null,
              formatMethod: [],
              formatParam: [],
              _required: null,
              enum: null,
              __key: "table_id",
              __parent: "__root.result.data",
              key: "data.table_id",
              children: [],
              treeNodePath: [0, 4]
            },
            FdEyKqfT: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              id: "FdEyKqfT",
              title: "\u6761\u4EF6\u4E3B\u952E",
              checkByExp: [],
              visible: false,
              isDataWidget: true,
              showTitleEffective: true,
              required: false,
              style: {},
              titleAlign: "left",
              widgetCode: "FormInput$12",
              field: "id",
              fieldInfo: {
                ds: "bis_api_1662035073920",
                path: "__root.result.data.id"
              },
              readOnly: false
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1662035073920",
                                      method: "post",
                                      range: [
                                        {
                                          json_clips_id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "bis_api_1662035073920",
                                      method: "post",
                                      range: [
                                        {
                                          json_clips_id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            MwvvMlsc: {
              onChange: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "kCIeoINc",
                                      path: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_MwvvMlsc"
                                      ]
                                    },
                                    { widgetId: "VMZXgHHM", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1669610726047756289",
                                  input: [
                                    {
                                      "__root.fieldCode": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "curRow",
                                            "colsVal",
                                            "saveValV2_MwvvMlsc"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.tableId": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "VMZXgHHM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      field: "__root.result.data.dataType",
                                      widgetId: "kCIeoINc",
                                      propPath: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_cBdQAEVV"
                                      ]
                                    },
                                    {
                                      field: "__root.result.data.refTableId",
                                      widgetId: "kCIeoINc",
                                      propPath: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_kwcQnRJG"
                                      ]
                                    }
                                  ],
                                  apiTip: false,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            vGkjqrKz: {
              onChange: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: []
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            YLaFwqht: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond1",
                            pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths({
                              id: "kCIeoINc",
                              fromPaths: pageCtx.fromPaths,
                              propPath: [
                                "curRow",
                                "colsVal",
                                "saveValV2_cBdQAEVV"
                              ]
                            }),
                            "DICT",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    {
                                      widgetId: "lvpyPmEM",
                                      path: ["selectedRows", "code", "saveValV2"]
                                    },
                                    {
                                      widgetId: "lvpyPmEM",
                                      path: ["selectedRows", "name", "saveValV2"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_kwcQnRJG"
                                      ]
                                    }
                                  ],
                                  exps: [{ expId: "exp_VJWGYGFn" }],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: "",
                                  actionBeforeCheckTip: {}
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.popUpDataSelect) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  link: "1669612498325745664",
                                  appType: "currentApp",
                                  showCloseIcon: true,
                                  popupMode: "openModal",
                                  isMask: true,
                                  openType: "openModal",
                                  adsorbPosition: "topLeft",
                                  adsorbOffset: {
                                    horizontal: "8px",
                                    vertical: "8px"
                                  },
                                  closePopup: false,
                                  showTopBar: true,
                                  slidePlacement: "right",
                                  mini: false,
                                  fullscreen: true,
                                  Drag: false,
                                  pageNameCn: "\u52A8\u6001\u5B57\u6BB5\u9009\u62E9\u5B57\u5178\u503C",
                                  extraprops: {
                                    width: "56vw",
                                    height: "undefined"
                                  },
                                  inputParams: [
                                    { var_pageInput_0_mode: "detail" },
                                    {
                                      var_pageInput_1_id: pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "curRow",
                                            "colsVal",
                                            "saveValV2_kwcQnRJG"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      var_pageInput_2_JsAmEgzJ: yield pageCtx.getExpResult(
                                        {
                                          id: "exp_VJWGYGFn",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [
                                    {
                                      key: "curRow_kCIeoINc.colsVal.saveValV2_vGkjqrKz",
                                      widgetId: "kCIeoINc",
                                      propPath: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_vGkjqrKz"
                                      ],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "lvpyPmEM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "selectedRows",
                                            "code",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    },
                                    {
                                      key: "curRow_kCIeoINc.colsVal.saveValV2_ALrmlojf",
                                      widgetId: "kCIeoINc",
                                      propPath: [
                                        "curRow",
                                        "colsVal",
                                        "saveValV2_ALrmlojf"
                                      ],
                                      value: {
                                        type: "getWidgetDataByOriginalPropsWithFromPaths",
                                        param: {
                                          id: "lvpyPmEM",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "selectedRows",
                                            "name",
                                            "saveValV2"
                                          ]
                                        }
                                      }
                                    }
                                  ],
                                  monitorFormOutSide: {},
                                  onCancel: () => __async(this, null, function* () {
                                    var _a3;
                                    return yield (_a3 = platform_action_default) == null ? void 0 : _a3.eventExecute(
                                      {
                                        events: [
                                          {
                                            actionList: []
                                          }
                                        ],
                                        eventMode: "serial"
                                      },
                                      pageCtx
                                    );
                                  }),
                                  dataLinkage: "none",
                                  inputExpMap: {},
                                  id: "forJZuKO"
                                },
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u6253\u5F00\u9875\u9762:\u52A8\u6001\u5B57\u6BB5\u9009\u62E9\u5B57\u5178\u503C" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            raWWgWWr: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "sIISQzau", path: ["saveValV2"] },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_MwvvMlsc"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_sfKNFlLb"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_ALrmlojf"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_tYoxamuL"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_vGkjqrKz"]
                                    },
                                    {
                                      widgetId: "kCIeoINc",
                                      path: ["colsVal", "saveValV2_qiMdPNGi"]
                                    }
                                  ],
                                  exps: [
                                    { expId: "exp_BvluPZfy" },
                                    { expId: "exp_CVUsBVag" }
                                  ],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "",
                                  checkRule: null,
                                  checkTip: ""
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1662122786519",
                                  input: [
                                    {
                                      "__root.json_clips_id": pageCtx.getDataByPath(
                                        {
                                          target: "pageInput",
                                          path: "var_pageInput_1_id"
                                        }
                                      )
                                    },
                                    {
                                      "__root.selectShowField": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_BvluPZfy",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionId": yield pageCtx.getExpResult(
                                        {
                                          id: "exp_CVUsBVag",
                                          source: pageCtx.fromPaths ? { fromPaths: pageCtx.fromPaths } : {}
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.express": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "sIISQzau",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.arrayValueCondition": "false"
                                    },
                                    {
                                      "__root.conditionMeta.columns.columnCode": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_MwvvMlsc"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.condition": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_sfKNFlLb"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.showValue": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_ALrmlojf"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.tableCode": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_tYoxamuL"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.value": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_vGkjqrKz"
                                          ]
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionMeta.columns.valueType": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "kCIeoINc",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: [
                                            "colsVal",
                                            "saveValV2_qiMdPNGi"
                                          ]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: true,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u4FEE\u6539[JSON\u5B57\u6BB5\u6761\u4EF6\u8868]\u8868\u4FE1\u606F" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            tgirWemt: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            emgKBeVV: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            actionCheck: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.actionBeforeCheck) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  variables: [
                                    { widgetId: "FdEyKqfT", path: ["saveValV2"] }
                                  ],
                                  exps: [],
                                  operateForm: false
                                },
                                {
                                  formCheckBool: true,
                                  selectRowCheckBool: true,
                                  askText: "\u786E\u8BA4\u5220\u9664\uFF1F"
                                },
                                pageCtx
                              );
                            }),
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.apiCall) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  api: "bis_api_1662123180580",
                                  input: [
                                    {
                                      "__root.json_clips_id": pageCtx.getDataByPath(
                                        {
                                          target: "pageInput",
                                          path: "var_pageInput_1_id"
                                        }
                                      )
                                    },
                                    {
                                      "__root.conditionId": pageCtx == null ? void 0 : pageCtx.getWidgetDataByOriginalPropsWithFromPaths(
                                        {
                                          id: "FdEyKqfT",
                                          fromPaths: pageCtx.fromPaths,
                                          propPath: ["saveValV2"]
                                        }
                                      )
                                    }
                                  ],
                                  outputParams: [],
                                  apiTip: true,
                                  socket: null,
                                  requestType: "sync",
                                  asyncTaskTip: void 0
                                },
                                pageCtx
                              );
                            })
                          },
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.finishNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ],
                        log: { objectBehavior: "\u5220\u9664[JSON\u7247\u6BB5\u8868]\u8868\u4FE1\u606F" }
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "kCIeoINc",
                  children: [
                    {
                      id: "kCIeoINc_subFormInlineBtns",
                      type: "renderProp",
                      children: [
                        {
                          id: "BWgXdqQa",
                          parentToChild: "1:n",
                          type: "node",
                          children: [
                            {
                              id: "DfVTRtZZ",
                              parentToChild: "1:1",
                              type: "node"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "kCIeoINc_subFormBody",
                      type: "renderProp",
                      children: [
                        {
                          id: "MwvvMlsc",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "cBdQAEVV",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "kwcQnRJG",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "sfKNFlLb",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "qiMdPNGi",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "vGkjqrKz",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "tYoxamuL",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "ALrmlojf",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        },
                        {
                          id: "YLaFwqht",
                          parentToChild: "1:n",
                          type: "node",
                          children: []
                        }
                      ]
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "sIISQzau",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "GajUDSNO",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "aooWtato",
                  children: [
                    {
                      id: "raWWgWWr",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "tgirWemt",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "emgKBeVV",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "hleRdMaP",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "VMZXgHHM",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "FdEyKqfT",
                  children: [],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_QrXFfvOO: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  kCIeoINc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "kCIeoINc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ThEhRFxN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  MwvvMlsc: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "MwvvMlsc",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_YjSiRebx: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  cBdQAEVV: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "cBdQAEVV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_QClcmaYe: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  kwcQnRJG: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "kwcQnRJG",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_OdMZQAeG: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  sfKNFlLb: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "sfKNFlLb",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_NeqzTeUc: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  qiMdPNGi: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "qiMdPNGi",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ajvmirLl: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vGkjqrKz: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "vGkjqrKz",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_kuZzChoV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == "DICT" ? param == null ? void 0 : param.$1 : param == null ? void 0 : param.$2;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  vGkjqrKz: [
                    { path: "saveValV2", id: "vGkjqrKz", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  kCIeoINc: {
                    "curRow.colsVal.saveValV2_cBdQAEVV": { paramKey: "$0" },
                    "curRow.colsVal.saveValV2_vGkjqrKz": { paramKey: "$1" },
                    "curRow.colsVal.saveValV2_YLaFwqht": { paramKey: "$2" }
                  }
                }
              }
            },
            exp_OyFsicOH: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  tYoxamuL: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "tYoxamuL",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_UbTieaeK: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  tYoxamuL: [
                    { path: "saveValV2", id: "tYoxamuL", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  kCIeoINc: {
                    "curRow.colsVal.saveValV2_MwvvMlsc": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_gYtmUYkM: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ALrmlojf: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "ALrmlojf",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_QXOBMuVA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) == "DICT" ? param == null ? void 0 : param.$1 : param == null ? void 0 : param.$2;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  ALrmlojf: [
                    { path: "saveValV2", id: "ALrmlojf", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  kCIeoINc: {
                    "curRow.colsVal.saveValV2_cBdQAEVV": { paramKey: "$0" },
                    "curRow.colsVal.saveValV2_ALrmlojf": { paramKey: "$1" },
                    "curRow.colsVal.saveValV2_YLaFwqht": { paramKey: "$2" }
                  }
                }
              }
            },
            exp_yRsYCDvi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  YLaFwqht: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "YLaFwqht",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_VJWGYGFn: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "" }] },
              dependentVar: {
                widget: {
                  kCIeoINc: {
                    "curRow.colsVal.saveValV2_vGkjqrKz": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_GOxFtuzV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) != null ? param == null ? void 0 : param.$0 : NULL;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  YLaFwqht: [
                    { path: "saveValV2", id: "YLaFwqht", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: {
                  kCIeoINc: {
                    "curRow.colsVal.saveValV2_ALrmlojf": { paramKey: "$0" }
                  }
                }
              }
            },
            exp_uQCfKOdz: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  sIISQzau: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "sIISQzau",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_mzDMSxPi: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  GajUDSNO: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "GajUDSNO",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_mlgolegl: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  raWWgWWr: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "raWWgWWr",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_BvluPZfy: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.Split(param == null ? void 0 : param.$0, ",");
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: { action: [{ path: "", id: "raWWgWWr" }] },
              dependentVar: {
                widget: { hleRdMaP: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_CVUsBVag: {
              method: (param, pageCtx) => __async(this, null, function* () {
                let _expRes = void 0;
                try {
                  _expRes = platform_exp_default.IsEmpty(param == null ? void 0 : param.$0) ? yield platform_exp_default.UUID(pageCtx) : param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              }),
              effect: { action: [{ path: "", id: "raWWgWWr" }] },
              dependentVar: {
                widget: { FdEyKqfT: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_JWIkyyCu: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  emgKBeVV: [
                    {
                      path: "disabled",
                      defaultValue: true,
                      id: "emgKBeVV",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_YYVbqTAE: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hleRdMaP: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "hleRdMaP",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_ydWNKZqG: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = param == null ? void 0 : param.$0;
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hleRdMaP: [
                    { path: "saveValV2", id: "hleRdMaP", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { GajUDSNO: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_pqOhchwp: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VMZXgHHM: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "VMZXgHHM",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_LqNqMGjR: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FdEyKqfT: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "FdEyKqfT",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_QrXFfvOO", type: "exp" },
                { id: "exp_ThEhRFxN", type: "exp" },
                { id: "exp_YjSiRebx", type: "exp" },
                { id: "exp_QClcmaYe", type: "exp" },
                { id: "exp_OdMZQAeG", type: "exp" },
                { id: "exp_NeqzTeUc", type: "exp" },
                { id: "exp_ajvmirLl", type: "exp" },
                { id: "exp_OyFsicOH", type: "exp" },
                { id: "exp_gYtmUYkM", type: "exp" },
                { id: "exp_yRsYCDvi", type: "exp" },
                { id: "exp_uQCfKOdz", type: "exp" },
                { id: "exp_mzDMSxPi", type: "exp" },
                { id: "exp_mlgolegl", type: "exp" },
                { id: "exp_JWIkyyCu", type: "exp" },
                { id: "exp_YYVbqTAE", type: "exp" },
                { id: "exp_pqOhchwp", type: "exp" },
                { id: "exp_LqNqMGjR", type: "exp" }
              ],
              var_pageInput_1_id: [
                {
                  id: "hleRdMaP",
                  type: "widget",
                  path: "conditions.0.value",
                  action: "changeConditions"
                }
              ]
            },
            widget: {
              VMZXgHHM: {
                saveValV2: [
                  {
                    id: "MwvvMlsc",
                    type: "widget",
                    path: "customParams.0.value",
                    action: "changeConditions"
                  }
                ]
              },
              kCIeoINc: {
                "curRow.colsVal.saveValV2_cBdQAEVV": [
                  { id: "exp_kuZzChoV", type: "exp" },
                  { id: "exp_QXOBMuVA", type: "exp" }
                ],
                "curRow.colsVal.saveValV2_vGkjqrKz": [
                  { id: "exp_kuZzChoV", type: "exp" }
                ],
                "curRow.colsVal.saveValV2_YLaFwqht": [
                  { id: "exp_kuZzChoV", type: "exp" },
                  { id: "exp_QXOBMuVA", type: "exp" }
                ],
                "curRow.colsVal.saveValV2_MwvvMlsc": [
                  { id: "exp_UbTieaeK", type: "exp" }
                ],
                "curRow.colsVal.saveValV2_ALrmlojf": [
                  { id: "exp_QXOBMuVA", type: "exp" },
                  { id: "exp_GOxFtuzV", type: "exp" }
                ]
              },
              GajUDSNO: { saveValV2: [{ id: "exp_ydWNKZqG", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$kCIeoINc`,
            key: `PC$$kCIeoINc`,
            pageCtx,
            widgetRef: "SubformContainer",
            inlineBtnsRenderer: ({
              index: kCIeoINc_indexFromSubform,
              rowIndex: kCIeoINc_rowIndexFromSubform
            }) => /* @__PURE__ */ react_default.createElement(react_default.Fragment, null, /* @__PURE__ */ react_default.createElement(
              COMPCONTROL.CompEntry,
              {
                path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$BWgXdqQa`,
                key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$BWgXdqQa`,
                pageCtx,
                widgetRef: "FormButtonGroup"
              },
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$BWgXdqQa$$DfVTRtZZ`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$BWgXdqQa$$DfVTRtZZ`,
                  pageCtx,
                  widgetRef: "FormButton"
                }
              )
            )),
            bodyRenderer: ({
              index: kCIeoINc_indexFromSubform,
              rowIndex: kCIeoINc_rowIndexFromSubform
            }) => [
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$MwvvMlsc`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$MwvvMlsc`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$cBdQAEVV`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$cBdQAEVV`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$kwcQnRJG`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$kwcQnRJG`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$sfKNFlLb`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$sfKNFlLb`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$qiMdPNGi`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$qiMdPNGi`,
                  pageCtx,
                  widgetRef: "DropdownSelector"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$vGkjqrKz`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$vGkjqrKz`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$tYoxamuL`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$tYoxamuL`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$ALrmlojf`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$ALrmlojf`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              ),
              /* @__PURE__ */ react_default.createElement(
                COMPCONTROL.CompEntry,
                {
                  path: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$YLaFwqht`,
                  key: `PC$$kCIeoINc$$%${kCIeoINc_rowIndexFromSubform}%$$YLaFwqht`,
                  pageCtx,
                  widgetRef: "FormInput"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$sIISQzau`,
            key: `PC$$sIISQzau`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$GajUDSNO`,
            key: `PC$$GajUDSNO`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$aooWtato`,
            key: `PC$$aooWtato`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$aooWtato$$raWWgWWr`,
              key: `PC$$aooWtato$$raWWgWWr`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$aooWtato$$tgirWemt`,
              key: `PC$$aooWtato$$tgirWemt`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$aooWtato$$emgKBeVV`,
              key: `PC$$aooWtato$$emgKBeVV`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$hleRdMaP`,
            key: `PC$$hleRdMaP`,
            pageCtx,
            widgetRef: "DropdownSelector"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$VMZXgHHM`,
            key: `PC$$VMZXgHHM`,
            pageCtx,
            widgetRef: "FormInput"
          }
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$FdEyKqfT`,
            key: `PC$$FdEyKqfT`,
            pageCtx,
            widgetRef: "FormInput"
          }
        )
      );
    }
  };
  __publicField(Page1564919086897573888, "pageName", "\u52A8\u6001\u5B57\u6BB5\u6761\u4EF6\u663E\u793A");
  __publicField(Page1564919086897573888, "$pageKey", "qobFyVzQ");
  __publicField(Page1564919086897573888, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
