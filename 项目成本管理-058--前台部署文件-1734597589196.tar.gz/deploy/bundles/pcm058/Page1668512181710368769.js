var Page1668512181710368769 = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => {
    __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
    return value;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    Page1668512181710368769: () => Page1668512181710368769
  });

  // global-externals:react
  var react_default = HYCCORE.React;

  // global-externals:@hyc/platform-ui
  var platform_ui_default = HYCPC;

  // global-externals:@hyc/platform-exp
  var platform_exp_default = HYCEXP;

  // global-externals:@hyc/platform-common-api
  var platform_common_api_default = HYCCAPI;

  // global-externals:@hyc/platform-utils
  var platform_utils_default = HYCUTILS;

  // global-externals:@hyc/platform-comp-control
  var platform_comp_control_default = HYCCOMPCONTROL;

  // global-externals:@hyc/platform-action
  var platform_action_default = HYCACTION;

  // global-externals:antd
  var antd_default = HYCCORE.antd;

  // <stdin>
  var Page1668512181710368769 = class extends platform_comp_control_default.PageInApp {
    constructor(props) {
      super(props);
    }
    componentDidMount() {
      this.init({
        data: {
          pageInfo: {
            pageId: "1668512181710368769",
            pageName: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355",
            apiMeta: {
              "1669609463667109888_detail_1686900952959": {
                method: "post",
                resSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root.msg": {
                    title: "\u63D0\u793A\u6D88\u606F",
                    __key: "msg",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.code": {
                    title: "\u8FD4\u56DE\u7801",
                    __key: "code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.timestamp": {
                    title: "\u65F6\u95F4\u6233",
                    __key: "timestamp",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root.result": {
                    title: "\u8FD4\u56DE\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root.result.data": {
                    title: "\u8FD4\u56DE\u6570\u636E\u96C6\u5408",
                    __key: "data",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root.result"
                  },
                  "__root.result.data.remark": {
                    title: "\u5907\u6CE8\u63CF\u8FF0",
                    __key: "remark",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.output_file_param": {
                    title: "\u51FA\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "output_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.input_file_param": {
                    title: "\u8BF7\u6C42\u5165\u53C2\u6587\u4EF6\u5730\u5740\u4FE1\u606F",
                    __key: "input_file_param",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.progress": {
                    title: "\u8FDB\u5EA6",
                    __key: "progress",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.result": {
                    title: "\u7ED3\u679C",
                    __key: "result",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.end_exec_time": {
                    title: "\u6267\u884C\u7ED3\u675F\u4E8B\u4EF6",
                    __key: "end_exec_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.exec_cost_time": {
                    title: "\u6267\u884C\u82B1\u8D39\u65F6\u957F",
                    __key: "exec_cost_time",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.start_exec_time": {
                    title: "\u5F00\u59CB\u6267\u884C\u65F6\u95F4",
                    __key: "start_exec_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status_des": {
                    title: "\u72B6\u6001\u63CF\u8FF0",
                    __key: "status_des",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.status": {
                    title: "\u4EFB\u52A1\u72B6\u6001",
                    __key: "status",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_name": {
                    title: "\u4E1A\u52A1\u4E2D\u6587\u540D\u79F0",
                    __key: "business_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.business_code": {
                    title: "\u4E1A\u52A1\u7F16\u7801",
                    __key: "business_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_name": {
                    title: "\u4EFB\u52A1\u540D\u79F0",
                    __key: "task_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.task_type": {
                    title: "\u4EFB\u52A1\u7C7B\u578B",
                    __key: "task_type",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.app_code": {
                    title: "\u5E94\u7528\u53F7",
                    __key: "app_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.less_code": {
                    title: "\u79DF\u6237\u53F7",
                    __key: "less_code",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_time": {
                    title: "\u6700\u540E\u4FEE\u6539\u65F6\u95F4",
                    __key: "last_update_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_name": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u540D\u79F0",
                    __key: "last_update_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.last_update_user_id": {
                    title: "\u6700\u540E\u4FEE\u6539\u4EBA\u4E3B\u952E",
                    __key: "last_update_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_time": {
                    title: "\u521B\u5EFA\u65F6\u95F4",
                    __key: "create_time",
                    _remoteType: void 0,
                    _type: "datetime",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_name": {
                    title: "\u521B\u5EFA\u4EBA\u540D\u79F0",
                    __key: "create_user_name",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.create_user_id": {
                    title: "\u521B\u5EFA\u4EBA\u4E3B\u952E",
                    __key: "create_user_id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.data.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: "string_number",
                    _type: "string",
                    __parent: "__root.result.data"
                  },
                  "__root.result.totalCount": {
                    title: "\u603B\u8BB0\u5F55\u6570",
                    __key: "totalCount",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root.result"
                  }
                },
                asyncResSchema: {},
                reqSchema: {
                  __root: {
                    title: void 0,
                    __key: "__root",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: ""
                  },
                  "__root._page": {
                    title: "\u5206\u9875\u53C2\u6570",
                    __key: "_page",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._page.size": {
                    title: "\u8BF7\u6C42\u6570\u91CF",
                    __key: "size",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._page.from": {
                    title: "\u8D77\u59CB\u4F4D\u79FB",
                    __key: "from",
                    _remoteType: void 0,
                    _type: "number",
                    __parent: "__root._page"
                  },
                  "__root._needTotal": {
                    title: "\u662F\u5426\u8FD4\u56DE\u603B\u6570",
                    __key: "_needTotal",
                    _remoteType: void 0,
                    _type: "boolean",
                    __parent: "__root"
                  },
                  "__root._searchCondRel": {
                    title: "\u5168\u6587\u68C0\u7D22\u5173\u8054\u5173\u7CFB",
                    __key: "_searchCondRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._condRel": {
                    title: "\u6761\u4EF6\u5173\u8054\u5173\u7CFB",
                    __key: "_condRel",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  },
                  "__root._cond": {
                    title: "\u6761\u4EF6\u53C2\u6570",
                    __key: "_cond",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._cond.field": {
                    title: "\u6761\u4EF6\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.method": {
                    title: "\u6761\u4EF6\u64CD\u4F5C\u7B26",
                    __key: "method",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._cond"
                  },
                  "__root._cond.value": {
                    title: "\u6761\u4EF6\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "stringArray",
                    __parent: "__root._cond"
                  },
                  "__root._search": {
                    title: "\u5168\u6587\u68C0\u7D22\u53C2\u6570",
                    __key: "_search",
                    _remoteType: void 0,
                    _type: "object",
                    __parent: "__root"
                  },
                  "__root._search.value": {
                    title: "\u5168\u6587\u68C0\u7D22\u503C",
                    __key: "value",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search"
                  },
                  "__root._search.fields": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5\u5217\u8868",
                    __key: "fields",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root._search"
                  },
                  "__root._search.fields.field": {
                    title: "\u5168\u6587\u68C0\u7D22\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._search.fields"
                  },
                  "__root._sort": {
                    title: "\u6392\u5E8F\u53C2\u6570",
                    __key: "_sort",
                    _remoteType: void 0,
                    _type: "objectArray",
                    __parent: "__root"
                  },
                  "__root._sort.field": {
                    title: "\u6392\u5E8F\u5B57\u6BB5",
                    __key: "field",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root._sort.order": {
                    title: "\u6392\u5E8F\u7C7B\u578B",
                    __key: "order",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root._sort"
                  },
                  "__root.id": {
                    title: "\u4E3B\u952E",
                    __key: "id",
                    _remoteType: void 0,
                    _type: "string",
                    __parent: "__root"
                  }
                },
                cond: {}
              }
            },
            // 页面ApiMeta收集
            pageInputMapping: {
              var_pageInput_0_mode: "var_pageInput_0_mode",
              var_pageInput_1_id: "var_pageInput_1_id"
            },
            condMeta: {
              NUMBER_ARRAY: [],
              STRING_ARRAY: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              DATE: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              NULL: [],
              DATETIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING_NUMBER: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              STRING: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "like", description: "\u6A21\u7CCA\u7B49\u4E8E", paramAmount: 1 },
                { name: "notLike", description: "\u4E0D\u5305\u542B", paramAmount: 1 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 },
                { name: "startWith", description: "\u5F00\u5934\u662F", paramAmount: 1 },
                { name: "startNotWith", description: "\u5F00\u5934\u4E0D\u662F", paramAmount: 1 },
                { name: "endWith", description: "\u7ED3\u5C3E\u662F", paramAmount: 1 },
                { name: "endNotWith", description: "\u7ED3\u5C3E\u4E0D\u662F", paramAmount: 1 }
              ],
              TIME: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 },
                { name: "equOrEmpty", description: "\u7B49\u4E8E\u6216\u4E3A\u7A7A", paramAmount: 1 },
                {
                  name: "notEquOrNotEmpty",
                  description: "\u4E0D\u7B49\u4E8E\u6216\u4E0D\u4E3A\u7A7A",
                  paramAmount: 1
                },
                { name: "greater", description: "\u5927\u4E8E", paramAmount: 1 },
                { name: "less", description: "\u5C0F\u4E8E", paramAmount: 1 },
                { name: "greaterEqu", description: "\u5927\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "lessEqu", description: "\u5C0F\u4E8E\u7B49\u4E8E", paramAmount: 1 },
                { name: "between", description: "\u4ECB\u4E8E", paramAmount: 2 },
                { name: "notBetween", description: "\u4E0D\u4ECB\u4E8E", paramAmount: 2 },
                { name: "in", description: "\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "notIn", description: "\u4E0D\u5728\u8303\u56F4\u5185", paramAmount: 1 },
                { name: "empty", description: "\u4E3A\u7A7A", paramAmount: 0 },
                { name: "notEmpty", description: "\u4E0D\u4E3A\u7A7A", paramAmount: 0 }
              ],
              OBJECT: [],
              OBJECT_ARRAY: [],
              BOOLEAN: [
                { name: "equ", description: "\u7B49\u4E8E", paramAmount: 1 },
                { name: "notEqu", description: "\u4E0D\u7B49\u4E8E", paramAmount: 1 }
              ]
            }
            // 页面condMeta收集
          },
          // 页面信息
          pageInput: __spreadValues(__spreadValues({}, { var_pageInput_0_mode: "insert", var_pageInput_1_id: "" }), this.props),
          // 页面入参
          pageUtils: {
            $A,
            $A_R,
            PUI: platform_ui_default,
            UTILS: platform_utils_default,
            ACTION: platform_action_default,
            COMMONAPI: platform_common_api_default,
            COMPCONTROL: platform_comp_control_default,
            EXP: platform_exp_default,
            PLUGINS: { ANTD: antd_default }
          },
          // 页面工具类
          widgetInfo: {
            PC: {
              varMap: {},
              widgetRef: "PageContainer",
              eventAttr: ["onPageLoad", "onPageDestroy", "onPageResize"],
              isContainer: true,
              reloadEvents: ["onPageLoad"],
              id: "PC",
              eventTypesWithTags: [],
              widgetCode: "PageContainer0",
              style: { backgroundColor: "transparent" },
              pageLog: true,
              showCommonButtonArea: false,
              internalshare: false,
              externalshare: false,
              title: "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355",
              showBottomBar: true,
              sockets: null,
              dss: ["1669609463667109888_detail_1686900952959"],
              requests: {
                "1669609463667109888_detail_1686900952959": [
                  {
                    field: "id",
                    variable: "var_pageInput_1_id",
                    type: "pageInput"
                  }
                ]
              }
            },
            OEiNfmsJ: {
              varMap: {},
              widgetRef: "GridLayout",
              group: "container",
              isContainer: true,
              id: "OEiNfmsJ",
              title: "\u5217\u5E03\u5C40",
              colCounts: 2,
              hGutter: 16,
              vGutter: 0,
              visible: true,
              style: { width: "100%", height: "100%" },
              alignType: "aligned",
              widgetCode: "GridLayout$1",
              bodyInfo: [
                { id: "uLOdSMWS", visible: true, widgetRef: "FormInput" },
                { id: "NVyIOGYF", visible: true, widgetRef: "DropdownSelector" },
                { id: "qHcIpOgD", visible: true, widgetRef: "DropdownSelector" },
                { id: "CYPHVoqA", visible: true, widgetRef: "FormInput" },
                { id: "HVfPRTff", visible: true, widgetRef: "FormInput" },
                { id: "hYoWoOGS", visible: true, widgetRef: "FormInput" },
                { id: "VCyNeOfx", visible: true, widgetRef: "FormInput" },
                {
                  id: "tarsSMFk",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                {
                  id: "PxgssYGQ",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                {
                  id: "kTQIGBIv",
                  visible: true,
                  widgetRef: "FormDateTimePicker"
                },
                {
                  id: "FeMruCMX",
                  visible: false,
                  widgetRef: "File",
                  expId: "exp_MzPjzmhm"
                },
                {
                  id: "BzDumncU",
                  visible: false,
                  widgetRef: "File",
                  expId: "exp_remfzWAL"
                }
              ]
            },
            uLOdSMWS: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "uLOdSMWS",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u540D\u79F0",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$1",
              field: "task_name",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.task_name"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 512
            },
            NVyIOGYF: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "NVyIOGYF",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u7C7B\u578B",
              options: { 1: "\u5F02\u6B65", 2: "\u5B9A\u65F6" },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$1",
              field: "task_type",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.task_type"
              },
              fieldSearch: null,
              fieldColumn: null,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636740939788288_1687861068583"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636740939788288_1687861068583",
                type: "dict"
              }
            },
            qHcIpOgD: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "DropdownSelector",
              eventAttr: [
                "onChange",
                "onLoadOptions",
                "onFocus",
                "onBlur",
                "onMouseEnter",
                "onMouseLeave",
                "onClear"
              ],
              group: "formInput",
              widgetType: "form",
              reloadEvents: ["getOptions"],
              id: "qHcIpOgD",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u72B6\u6001",
              options: {
                0: "\u961F\u5217\u4E2D",
                1: "\u8FDB\u884C\u4E2D",
                3: "\u90E8\u5206\u5931\u8D25",
                4: "\u6210\u529F",
                5: "\u5931\u8D25",
                6: "\u5DF2\u7EC8\u6B62",
                7: "\u8C03\u5EA6\u4E2D",
                8: "\u5DF2\u8D85\u65F6"
              },
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              titleAlign: "left",
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              listHeight: "120",
              readOnly: false,
              widgetCode: "DropdownSelector$2",
              field: "status",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.status"
              },
              fieldSearch: null,
              fieldColumn: null,
              propOptions: {
                type: "dict",
                distOptsConfig: {
                  dictBusinessCode: "1673636741996752896_1687861068761"
                }
              },
              dictMeta: {
                dictBusiCode: "1673636741996752896_1687861068761",
                type: "dict"
              }
            },
            CYPHVoqA: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "CYPHVoqA",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u8FDB\u5EA6",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$3",
              field: "progress",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.progress"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 128
            },
            HVfPRTff: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "HVfPRTff",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u4EFB\u52A1\u6267\u884C\u7ED3\u679C",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$4",
              field: "result",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.result"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 65535,
              linkage: null
            },
            hYoWoOGS: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "hYoWoOGS",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u7ED3\u679C\u8017\u65F6",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$5",
              field: "exec_cost_time",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.exec_cost_time"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 128
            },
            VCyNeOfx: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormInput",
              eventAttr: ["onChange", "onClick", "onFocus", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "VCyNeOfx",
              titleWeight: 400,
              labelColor: "#272727",
              fontStyle: { color: "#272727" },
              title: "\u64CD\u4F5C\u4EBA",
              checkByExp: [],
              visible: true,
              showTitleEffective: true,
              required: false,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              titleAlign: "left",
              readOnly: false,
              widgetCode: "FormInput$6",
              field: "create_user_name",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.create_user_name"
              },
              fieldSearch: null,
              fieldColumn: null,
              stringLength: 32
            },
            tarsSMFk: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "tarsSMFk",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u63D0\u4EA4\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$1",
              field: "create_time",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.create_time"
              },
              fieldSearch: null,
              fieldColumn: null
            },
            PxgssYGQ: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "PxgssYGQ",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u5F00\u59CB\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$2",
              field: "start_exec_time",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.start_exec_time"
              },
              fieldSearch: null,
              fieldColumn: null
            },
            kTQIGBIv: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" }
              },
              widgetRef: "FormDateTimePicker",
              eventAttr: ["onChange", "onOk", "onBlur"],
              group: "formInput",
              widgetType: "form",
              id: "kTQIGBIv",
              titleWeight: 400,
              labelColor: "#272727",
              title: "\u5F00\u59CB\u65F6\u95F4",
              titleAlign: "left",
              checkByExp: [],
              timeMode: "datetime",
              timeType: "string",
              required: false,
              visible: true,
              showTitleEffective: true,
              style: {},
              readOnlyStyle: {
                borderTop: "0px",
                borderRight: "0px",
                borderBottom: "0px solid #e8e8e8",
                borderLeft: "0px",
                backgroundColor: "rgba(232,232,232,1)"
              },
              fontStyle: { color: "#272727" },
              readOnly: false,
              widgetCode: "FormDateTimePicker$3",
              field: "end_exec_time",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.end_exec_time"
              },
              fieldSearch: null,
              fieldColumn: null
            },
            FeMruCMX: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" },
                fileName: { type: "stringArray" },
                fileIdentifier: { type: "stringArray" },
                fileSize: { type: "stringArray" },
                fileType: { type: "stringArray" },
                filePath: { type: "stringArray" },
                checkedItems: { type: "objectArray" },
                currentItem: { type: "object" }
              },
              widgetRef: "File",
              eventAttr: [
                "onFileUpload",
                "onChange",
                "onDrop",
                "onDownload",
                "onPreview",
                "onRead",
                "onRemove",
                "onChangeCheckedItems"
              ],
              group: "formInput",
              widgetType: "form",
              parseInReadOnly: true,
              reloadEvents: [],
              id: "FeMruCMX",
              title: "\u6E90\u6587\u4EF6",
              visible: false,
              showTitleEffective: true,
              required: false,
              multiple: false,
              onlinePreview: false,
              uploadChunk: false,
              fileCheckMode: "notChecked",
              fileDefaultCheck: "",
              defaultChecked: false,
              changeDefaultChecked: false,
              titleWeight: 400,
              labelColor: "#272727",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              acceptLimit: {
                txt: "text/plain",
                pdf: "application/pdf",
                zip: "application/x-zip-compressed",
                doc: "application/msword",
                docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                xls: "application/vnd.ms-excel",
                xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                png: "image/png",
                jpg: "image/jpeg",
                jpeg: "image/jpeg",
                ppt: "application/vnd.ms-powerpoint",
                pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                rar: "application/x-rar-compressed",
                html: "text/html",
                rm: "application/vnd.rn-realmedia",
                avi: "video/x-msvideo",
                mid: "audio/midi,audio/x-midi",
                wav: "audio/wav",
                mp3: "audio/mpeg",
                bmp: "image/bmp",
                iso: "application/octet-stream",
                wps: "application/vnd.ms-works",
                mp4: "video/mp4",
                mov: "video/quicktime",
                flv: "video/x-flv",
                dwg: "application/x-autocad",
                psd: "application/octet-stream",
                eps: "application/postscript",
                ai: "application/postscript"
              },
              limitSize: "20M",
              maxCount: 10,
              readOnly: false,
              preview: true,
              edit: false,
              download: true,
              remove: false,
              widgetCode: "File$1",
              field: "input_file_param",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.input_file_param"
              },
              fieldSearch: null,
              fieldColumn: null
            },
            BzDumncU: {
              varMap: {
                saveValV2: { type: "string" },
                realValV2: { type: "string" },
                fileName: { type: "stringArray" },
                fileIdentifier: { type: "stringArray" },
                fileSize: { type: "stringArray" },
                fileType: { type: "stringArray" },
                filePath: { type: "stringArray" },
                checkedItems: { type: "objectArray" },
                currentItem: { type: "object" }
              },
              widgetRef: "File",
              eventAttr: [
                "onFileUpload",
                "onChange",
                "onDrop",
                "onDownload",
                "onPreview",
                "onRead",
                "onRemove",
                "onChangeCheckedItems"
              ],
              group: "formInput",
              widgetType: "form",
              parseInReadOnly: true,
              reloadEvents: [],
              id: "BzDumncU",
              title: "\u7ED3\u679C\u6587\u4EF6",
              visible: false,
              showTitleEffective: true,
              required: false,
              multiple: false,
              onlinePreview: false,
              uploadChunk: false,
              fileCheckMode: "notChecked",
              fileDefaultCheck: "",
              defaultChecked: false,
              changeDefaultChecked: false,
              titleWeight: 400,
              labelColor: "#272727",
              style: {},
              readOnlyStyle: {
                borderBottomWidth: "1px",
                borderBottomStyle: "solid",
                borderBottomColor: "#e8e8e8",
                borderTopWidth: "0px",
                borderLeftWidth: "0px",
                borderRightWidth: "0px"
              },
              acceptLimit: {
                txt: "text/plain",
                pdf: "application/pdf",
                zip: "application/x-zip-compressed",
                doc: "application/msword",
                docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                xls: "application/vnd.ms-excel",
                xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                png: "image/png",
                jpg: "image/jpeg",
                jpeg: "image/jpeg",
                ppt: "application/vnd.ms-powerpoint",
                pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                rar: "application/x-rar-compressed",
                html: "text/html",
                rm: "application/vnd.rn-realmedia",
                avi: "video/x-msvideo",
                mid: "audio/midi,audio/x-midi",
                wav: "audio/wav",
                mp3: "audio/mpeg",
                bmp: "image/bmp",
                iso: "application/octet-stream",
                wps: "application/vnd.ms-works",
                mp4: "video/mp4",
                mov: "video/quicktime",
                flv: "video/x-flv",
                dwg: "application/x-autocad",
                psd: "application/octet-stream",
                eps: "application/postscript",
                ai: "application/postscript"
              },
              limitSize: "20M",
              maxCount: 10,
              readOnly: false,
              preview: true,
              edit: false,
              download: true,
              remove: false,
              widgetCode: "File$2",
              field: "output_file_param",
              fieldInfo: {
                ds: "1669609463667109888_detail_1686900952959",
                path: "__root.result.data.output_file_param"
              },
              fieldSearch: null,
              fieldColumn: null
            },
            rEzfgcWi: {
              varMap: {},
              widgetRef: "FloatBar",
              group: "formInput",
              isContainer: true,
              id: "rEzfgcWi",
              contentAlign: "right",
              style: {}
            },
            uYGbwWKN: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "uYGbwWKN",
              title: "\u786E\u5B9A",
              visible: false,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 }
            },
            KUNCassl: {
              varMap: {},
              widgetRef: "FormButton",
              eventAttr: ["onClick", "onDbClick", "onMouseIn", "onMouseOut"],
              group: "actionControl",
              id: "KUNCassl",
              title: "\u53D6\u6D88",
              visible: true,
              disabled: false,
              iconType: "",
              style: { width: "auto" },
              fontStyle: { fontWeight: 400 },
              type: "default",
              eventTypesWithTags: []
            }
          },
          // 组件配置信息
          widgetEvent: {
            PC: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1669609463667109888_detail_1686900952959",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            },
            PageInApp: {
              onPageLoad: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        eventCheck: () => __async(this, null, function* () {
                          var _a2, _b;
                          const $1$ = ((_b = (_a2 = platform_utils_default).executeCond) == null ? void 0 : _b.call(
                            _a2,
                            "cond2",
                            pageCtx.getDataByPath({
                              target: "pageInput",
                              path: "var_pageInput_0_mode"
                            }),
                            "insert",
                            void 0
                          )) || false;
                          return $1$;
                        }),
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.pageDataLoad) == null ? void 0 : _b.call(
                                _a2,
                                {
                                  requests: [
                                    {
                                      ds: "1669609463667109888_detail_1686900952959",
                                      method: "post",
                                      range: [
                                        {
                                          id: pageCtx.getDataByPath({
                                            target: "pageInput",
                                            path: "var_pageInput_1_id"
                                          })
                                        }
                                      ]
                                    }
                                  ]
                                },
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              }),
              onDictInit: (pageCtx) => __async(this, null, function* () {
                yield pageCtx == null ? void 0 : pageCtx.onTrigger({
                  type: "getDictsWithDictBusiCode"
                });
              })
            },
            KUNCassl: {
              onClick: (pageCtx) => __async(this, null, function* () {
                var _a;
                return yield (_a = platform_action_default) == null ? void 0 : _a.eventExecute(
                  {
                    events: [
                      {
                        actionList: [
                          {
                            action: () => __async(this, null, function* () {
                              var _a2, _b;
                              return yield (_b = (_a2 = platform_action_default) == null ? void 0 : _a2.cancelNClosePage) == null ? void 0 : _b.call(
                                _a2,
                                void 0,
                                pageCtx
                              );
                            })
                          }
                        ]
                      }
                    ],
                    eventMode: "serial"
                  },
                  pageCtx
                );
              })
            }
          },
          // 组件事件
          renderInfo: [
            {
              id: "PC",
              children: [
                {
                  id: "OEiNfmsJ",
                  children: [
                    {
                      id: "uLOdSMWS",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "NVyIOGYF",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "qHcIpOgD",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "CYPHVoqA",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "HVfPRTff",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "hYoWoOGS",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "VCyNeOfx",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "tarsSMFk",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "PxgssYGQ",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "kTQIGBIv",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "FeMruCMX",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "BzDumncU",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                },
                {
                  id: "rEzfgcWi",
                  children: [
                    {
                      id: "uYGbwWKN",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    },
                    {
                      id: "KUNCassl",
                      children: [],
                      parentToChild: "1:1",
                      type: "node"
                    }
                  ],
                  parentToChild: "1:1",
                  type: "node"
                }
              ]
            }
          ],
          // 页面组件嵌套数据
          expInfo: {
            exp_LqMIVGnK: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uLOdSMWS: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "uLOdSMWS",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_KFgzAScb: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  NVyIOGYF: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "NVyIOGYF",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_NQoexHmJ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  qHcIpOgD: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "qHcIpOgD",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_wFPDCPOJ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  CYPHVoqA: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "CYPHVoqA",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_FZaNfnTV: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  HVfPRTff: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "HVfPRTff",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_kjCZkMsu: {
              method: (param, pageCtx) => {
                var _a;
                let _expRes = void 0;
                try {
                  _expRes = (_a = param == null ? void 0 : param.$0) == null ? void 0 : _a.replace(
                    /^业务引擎执行异常:java.lang.IllegalArgumentException:(\s)?/,
                    ""
                  );
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  HVfPRTff: [
                    { path: "saveValV2", id: "HVfPRTff", type: "widget" }
                  ]
                }
              },
              dependentVar: {
                widget: { HVfPRTff: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_zrXMsQHT: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  hYoWoOGS: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "hYoWoOGS",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_XMyFZGIA: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  VCyNeOfx: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "VCyNeOfx",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_RrstkUtv: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  tarsSMFk: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "tarsSMFk",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_WpkmuObJ: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  PxgssYGQ: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "PxgssYGQ",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_eVZVxQNy: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  kTQIGBIv: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "kTQIGBIv",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_MzPjzmhm: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !platform_exp_default.HasEmpty(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FeMruCMX: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "FeMruCMX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { FeMruCMX: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_tOqyCoOj: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FeMruCMX: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "FeMruCMX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_VLKOtOwk: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FeMruCMX: [
                    {
                      path: "edit",
                      defaultValue: false,
                      id: "FeMruCMX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_InqSFChb: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  FeMruCMX: [
                    {
                      path: "remove",
                      defaultValue: false,
                      id: "FeMruCMX",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_remfzWAL: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = !platform_exp_default.HasEmpty(param == null ? void 0 : param.$0);
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  BzDumncU: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "BzDumncU",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                widget: { BzDumncU: { saveValV2: { paramKey: "$0" } } }
              }
            },
            exp_ZbtkjlSN: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  BzDumncU: [
                    {
                      path: "readOnly",
                      defaultValue: false,
                      id: "BzDumncU",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_LjwELtKf: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  BzDumncU: [
                    {
                      path: "edit",
                      defaultValue: false,
                      id: "BzDumncU",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_yGxKATSU: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  BzDumncU: [
                    {
                      path: "remove",
                      defaultValue: false,
                      id: "BzDumncU",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_TYqbgCst: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) !== "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uYGbwWKN: [
                    {
                      path: "visible",
                      defaultValue: false,
                      id: "uYGbwWKN",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            },
            exp_zRVAxriz: {
              method: (param, pageCtx) => {
                let _expRes = void 0;
                try {
                  _expRes = (param == null ? void 0 : param.$0) === "detail";
                } catch (e) {
                  console.log("\u8868\u8FBE\u5F0F\u62A5\u9519\uFF1A", e);
                }
                return _expRes;
              },
              effect: {
                widget: {
                  uYGbwWKN: [
                    {
                      path: "disabled",
                      defaultValue: true,
                      id: "uYGbwWKN",
                      type: "widget"
                    }
                  ]
                }
              },
              dependentVar: {
                pageInput: { var_pageInput_0_mode: { paramKey: "$0" } }
              }
            }
          },
          // 表达式初始化信息
          monitor: {
            pageInput: {
              var_pageInput_0_mode: [
                { id: "exp_LqMIVGnK", type: "exp" },
                { id: "exp_KFgzAScb", type: "exp" },
                { id: "exp_NQoexHmJ", type: "exp" },
                { id: "exp_wFPDCPOJ", type: "exp" },
                { id: "exp_FZaNfnTV", type: "exp" },
                { id: "exp_zrXMsQHT", type: "exp" },
                { id: "exp_XMyFZGIA", type: "exp" },
                { id: "exp_RrstkUtv", type: "exp" },
                { id: "exp_WpkmuObJ", type: "exp" },
                { id: "exp_eVZVxQNy", type: "exp" },
                { id: "exp_tOqyCoOj", type: "exp" },
                { id: "exp_VLKOtOwk", type: "exp" },
                { id: "exp_InqSFChb", type: "exp" },
                { id: "exp_ZbtkjlSN", type: "exp" },
                { id: "exp_LjwELtKf", type: "exp" },
                { id: "exp_yGxKATSU", type: "exp" },
                { id: "exp_TYqbgCst", type: "exp" },
                { id: "exp_zRVAxriz", type: "exp" }
              ]
            },
            widget: {
              HVfPRTff: { saveValV2: [{ id: "exp_kjCZkMsu", type: "exp" }] },
              FeMruCMX: { saveValV2: [{ id: "exp_MzPjzmhm", type: "exp" }] },
              BzDumncU: { saveValV2: [{ id: "exp_remfzWAL", type: "exp" }] }
            }
          },
          // 表达式监听器信息
          customedVar: {},
          // 自定义变量
          sockets: []
          // socket信息
        }
      });
    }
    childrenRender(COMPCONTROL) {
      const { pageCtx } = this;
      return /* @__PURE__ */ react_default.createElement(
        COMPCONTROL.CompEntry,
        {
          path: `PC`,
          key: `PC`,
          pageCtx,
          widgetRef: "PageContainer"
        },
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$OEiNfmsJ`,
            key: `PC$$OEiNfmsJ`,
            pageCtx,
            widgetRef: "GridLayout"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$uLOdSMWS`,
              key: `PC$$OEiNfmsJ$$uLOdSMWS`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$NVyIOGYF`,
              key: `PC$$OEiNfmsJ$$NVyIOGYF`,
              pageCtx,
              widgetRef: "DropdownSelector"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$qHcIpOgD`,
              key: `PC$$OEiNfmsJ$$qHcIpOgD`,
              pageCtx,
              widgetRef: "DropdownSelector"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$CYPHVoqA`,
              key: `PC$$OEiNfmsJ$$CYPHVoqA`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$HVfPRTff`,
              key: `PC$$OEiNfmsJ$$HVfPRTff`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$hYoWoOGS`,
              key: `PC$$OEiNfmsJ$$hYoWoOGS`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$VCyNeOfx`,
              key: `PC$$OEiNfmsJ$$VCyNeOfx`,
              pageCtx,
              widgetRef: "FormInput"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$tarsSMFk`,
              key: `PC$$OEiNfmsJ$$tarsSMFk`,
              pageCtx,
              widgetRef: "FormDateTimePicker"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$PxgssYGQ`,
              key: `PC$$OEiNfmsJ$$PxgssYGQ`,
              pageCtx,
              widgetRef: "FormDateTimePicker"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$kTQIGBIv`,
              key: `PC$$OEiNfmsJ$$kTQIGBIv`,
              pageCtx,
              widgetRef: "FormDateTimePicker"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$FeMruCMX`,
              key: `PC$$OEiNfmsJ$$FeMruCMX`,
              pageCtx,
              widgetRef: "File"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$OEiNfmsJ$$BzDumncU`,
              key: `PC$$OEiNfmsJ$$BzDumncU`,
              pageCtx,
              widgetRef: "File"
            }
          )
        ),
        /* @__PURE__ */ react_default.createElement(
          COMPCONTROL.CompEntry,
          {
            path: `PC$$rEzfgcWi`,
            key: `PC$$rEzfgcWi`,
            pageCtx,
            widgetRef: "FloatBar"
          },
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$rEzfgcWi$$uYGbwWKN`,
              key: `PC$$rEzfgcWi$$uYGbwWKN`,
              pageCtx,
              widgetRef: "FormButton"
            }
          ),
          /* @__PURE__ */ react_default.createElement(
            COMPCONTROL.CompEntry,
            {
              path: `PC$$rEzfgcWi$$KUNCassl`,
              key: `PC$$rEzfgcWi$$KUNCassl`,
              pageCtx,
              widgetRef: "FormButton"
            }
          )
        )
      );
    }
  };
  __publicField(Page1668512181710368769, "pageName", "\u79DF\u6237\u7EA7\u4EFB\u52A1\u8868\u5355");
  __publicField(Page1668512181710368769, "$pageKey", "kOHSilQn");
  __publicField(Page1668512181710368769, "$compileVer", "1.0");
  return __toCommonJS(stdin_exports);
})();
